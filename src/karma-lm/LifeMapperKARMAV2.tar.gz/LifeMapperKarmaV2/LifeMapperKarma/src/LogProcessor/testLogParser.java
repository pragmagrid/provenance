package LogProcessor;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Scanner;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.Namespace;
import org.jdom2.input.SAXBuilder;

import Util.ConfigManager;

public class testLogParser {
	private FileInputStream log = null;
	private String log_output = null;

	// Two Readers are used. One for general scanning and one for specific zone
	// scanning;
	public testLogParser(String loginput, String logoutput) {
		try {
			log_output = logoutput;
			log = new FileInputStream(new File(loginput));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void maxEntParse() {
		BufferedReader reader = new BufferedReader(new InputStreamReader(log));

		File parsed_maxent_log = new File(log_output + "/parsed_maxent_log.txt");
		if (!parsed_maxent_log.exists()) {
			try {
				parsed_maxent_log.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(
					new FileWriter(parsed_maxent_log, false));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		String line;
		String[] tokens = null;
		int worker_num = 1;
		try {
			line = reader.readLine();
			while (line != null) {
				// Workflow Information
				if (line.contains("CDT 2013")) {
					writer.write(line);
					line = reader.readLine();
					if (line.contains("MaxEnt")) {
						writer.write("-" + line);
					}
					writer.newLine();
				}

				// Phase 1: Converting Layout File

				if (line.startsWith("Converting file")) {
					String converting_time = null;
					String input_file = "";
					String pixels = "";
					String grid_info = "";
					String output_file = "";
					while (!line.startsWith("Writing file")) {
						// Input layer file+size+memory
						if (line.startsWith("Converting file")) {
							tokens = line.split(" ");
							input_file = tokens[2] + "," + tokens[4]+tokens[8];
						}
						if (line.contains("pixels with data")) {
							pixels = line;
						}
						if (line.startsWith("readGrid")) {
							tokens = line.split(":");
							grid_info = tokens[1].trim();
						}
						if (line.startsWith("Time since start")) {
							tokens = line.split(":");
							converting_time = tokens[1].trim();
						}
						line = reader.readLine();
					}
					if (line.startsWith("Writing file")) {
						tokens = line.split(" ");
						output_file = tokens[2].trim();
					}

					writer.write("layer;"+input_file + ";"+ pixels + ";" + output_file+";"+grid_info+";"+converting_time);
					writer.newLine();
				}

				// Phase 2: Extracting random background and sample data
				if (line.startsWith("Extracting random background and sample data")) {
					writer.write("Phase 2 begins");
					writer.newLine();
					writer.write("Extracting random background and sample data");
					writer.newLine();

					String warnings = "warning:";
					String time_cost = "";
					String sample_points = "";
					while (!line
							.startsWith("Adding samples to background in feature space")) {

						if (line.startsWith("Warning")) {
							tokens = line.split(":");
							warnings = warnings + tokens[1].trim() + ";";
						}

						if (line.startsWith("Time since start")) {
							tokens = line.split(":");
							time_cost = "time:" + tokens[1].trim();
						}

						if (line.contains("with values for all grids")) {
							tokens = line.split(" ");
							sample_points = "samples:" + tokens[0].trim();
						}
						line = reader.readLine();
					}

					writer.write(warnings);
					writer.newLine();
					writer.write(time_cost);
					writer.newLine();
					writer.write(sample_points);
					writer.newLine();
					writer.write("Adding samples to background in feature space");
					writer.newLine();
					writer.write("Phase 2 ends");
					writer.newLine();
				}

				// Phase 3: Command Line execution & parameters

				if (line.startsWith("Command line used")) {
					writer.write("Phase 3 begins");
					writer.newLine();

					while (!line.startsWith("getSamples")) {

						writer.write(line.trim());
						writer.newLine();
						line = reader.readLine();
					}
					writer.write("Phase 3 ends");
					writer.newLine();
				}

				// Phase 4: Get Samples
				if (line.startsWith("getSamples")) {
					writer.write("Phase 4 begins");
					writer.newLine();
					writer.write(line);
					writer.newLine();
					writer.write("Phase 4 ends");
					writer.newLine();
				}

				// Phase 5: make features from input data
				if (line.startsWith("makeFeatures")) {
					writer.write("Phase 5 begins");
					writer.newLine();
					writer.write(line);
					writer.newLine();

					while (!line.startsWith("Resulting gain")) {
						if (line.startsWith("Regularization")) {
							writer.write(line);
							writer.newLine();
						}
						if (line.startsWith("Density")) {
							writer.write(line);
							writer.newLine();
						}
						if (line.startsWith("linearPredictor")) {
							writer.write(line);
							writer.newLine();
						}
						if (line.startsWith("FeaturedSpace")) {
							writer.write(line);
							writer.newLine();
						}
						if (line.startsWith("Sequential")) {
							writer.write(line);
							writer.newLine();
						}
						if (line.startsWith("Initial loss")) {
							writer.write(line);
							writer.newLine();
						}
						if (line.startsWith("Time since start")) {
							writer.write(line);
							writer.newLine();
						}
						line = reader.readLine();
					}
					writer.write(line);
					writer.newLine();
					writer.write("Phase 5 ends");
					writer.newLine();

				}

				// Phase 6: Projecting -- Last Phase
				// Format: Projecting: file,time cost;file,time cost;...

				if (line.startsWith("Projecting")) {
					writer.write("Phase 6 begins");
					writer.newLine();
					String projection_files = "Projecting:";
					while (!line.contains("Ending")) {
						if (line.startsWith("Writing file")) {
							tokens = line.split(" ");
							projection_files += tokens[2].trim();
							line = reader.readLine();
							if (line.startsWith("Time since start")) {
								tokens = line.split(":");
								projection_files += "," + tokens[1].trim();
							}
							projection_files += ";";
						}
						if (line.startsWith("Writing")) {
							tokens = line.split(" ");
							projection_files += tokens[1].trim();
							line = reader.readLine();
							if (line.startsWith("Time since start")) {
								tokens = line.split(":");
								projection_files += "," + tokens[1].trim();
							}
							projection_files += ";";
						}
						line = reader.readLine();
					}
					writer.write(projection_files);
					writer.newLine();
					writer.write("Phase 6 ends");
					writer.newLine();
				}

				line = reader.readLine();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				reader.close();
				writer.close();
				log.close();
			} catch (IOException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}

		System.out.println("Maxent Logs Parsing Complete!");
	}

	public String projectionParser(String experiment_url) {
		URL url = null;
		Scanner s = null;
		try {
			url = new URL(experiment_url + "/eml");
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		try {
			s = new Scanner(url.openStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		File eml_log = new File(log_output + "/eml.xml");
		if (!eml_log.exists()) {
			try {
				eml_log.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		BufferedWriter init_writer = null;
		try {
			init_writer = new BufferedWriter(new FileWriter(eml_log, false));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		File parsed_eml_log = new File(log_output + "/eml_log.txt");
		if (!parsed_eml_log.exists()) {
			try {
				parsed_eml_log.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(parsed_eml_log, false));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		String line = null;
		while (s.hasNextLine()) {
			line = s.nextLine();
			try {
				init_writer.write(line);
				init_writer.newLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// System.out.println(line);
		}
		try {
			init_writer.flush();
			init_writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			SAXBuilder builder = new SAXBuilder();
			String xmlFileName = log_output + "/eml.xml";
			Document doc = builder.build(xmlFileName);

			Element root = doc.getRootElement();
			Element dataset = root.getChild("dataset");

			Element otherentity = dataset.getChild("otherEntity");
			Element methods = otherentity.getChild("methods");
			List<Element> methodSteps = methods.getChildren("methodStep");
			
			String species_name="";
			
			for (Element methodstep : methodSteps) {
				Element para = methodstep.getChild("description")
						.getChild("section").getChild("para");

				if (para.getValue().contains("Occurrence set")) {
					String[] tokens = para.getValue().trim().split(" ");
					writer.write("occurrence id:"+tokens[2]);
					writer.newLine();
					writer.write("timestamp:"+tokens[tokens.length - 2] + " "
							+ tokens[tokens.length - 1]);
					writer.newLine();
				}
				if (para.getValue().contains("Projection")) {
					String[] tokens = para.getValue().trim().split(" ");
					String projectionID = tokens[1];
					String scenarioID = tokens[tokens.length - 1];
					if (projectionID != "" && scenarioID != "") {

						File projection_log = new File(log_output + "/projection.xml");
						if (!projection_log.exists()) {
							try {
								projection_log.createNewFile();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						BufferedWriter projection_writer = null;
						try {
							projection_writer = new BufferedWriter(
									new FileWriter(projection_log, false));
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}

						String projection_name = "";
						String scenario_code = "";
						String scenario_metadata = "";
						String bounding_box = "";
						
						String metadata_url = new ConfigManager().getProperty("LifeMapper_Projection_URI")
								+ "/"+ projectionID;
						// System.out.print(new
						// ConfigManager().getProperty("LifeMapper_Projection_URI")+"/"+projectionID+"/eml");
						URL projection_url = null;
						Scanner projection_s = null;
						try {
							projection_url = new URL(metadata_url);
						} catch (MalformedURLException e) {
							// TODO Auto-generated catch block
							System.out.println(e);
						}
						try {
							projection_s = new Scanner(
									projection_url.openStream());

							String projection_line;
							while (projection_s.hasNextLine()) {
								projection_line = projection_s.nextLine();
								try {
									projection_writer.write(projection_line);
									projection_writer.newLine();
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} finally {
							projection_writer.flush();
							projection_writer.close();
							projection_s.close();
						}
						String LM_NS="http://lifemapper.org";
						SAXBuilder new_builder = new SAXBuilder();
						String new_xmlFileName = log_output + "/projection.xml";
						Document new_doc = new_builder.build(new_xmlFileName);

						Element new_root = new_doc.getRootElement();
						Element new_projection = new_root.getChild("projection",Namespace.getNamespace(LM_NS));
						Element new_title = new_root.getChild("title",Namespace.getNamespace(LM_NS));

						projection_name = new_title.getValue().trim();

						Element bbox=new_projection.getChild("bbox",Namespace.getNamespace(LM_NS));
						bounding_box = bbox.getValue().trim();
						
						Element scenario=new_projection.getChild("scenarioCode",Namespace.getNamespace(LM_NS));
						scenario_code = scenario.getValue().trim();
					
						Element user=new_root.getChild("user",Namespace.getNamespace(LM_NS));
						scenario_metadata="http://lifemapper.org/services/"+user.getValue().trim()+"/scenarios"+scenarioID+"/eml";
						
						Element species=new_projection.getChild("speciesName",Namespace.getNamespace(LM_NS));
						species_name=species.getValue().trim();

						
						writer.write("scenario "+scenarioID + "!" + scenario_code + "!"
								+ scenario_metadata + ";" + projectionID + "!"
								+ projection_name + "!" + bounding_box + "!"
								+ metadata_url);
						writer.newLine();
					}
				}
			}
			writer.write("species name:"+species_name);
			writer.newLine();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (JDOMException e1)
		{
			System.out.print(e1);
		}
		finally {
			try {
				writer.flush();
				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return line;
	}

	public void openmodellerParser() {
		BufferedReader reader = new BufferedReader(new InputStreamReader(log));

		File parsed_openmodeller_log = new File(log_output
				+ "/parsed_openmodeller_log.txt");
		if (!parsed_openmodeller_log.exists()) {
			try {
				parsed_openmodeller_log.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(parsed_openmodeller_log,
					false));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		/*
		 * File om_middleware_log = new File(
		 * ConfigManager.getProperty("om_middleware_log")); if
		 * (!om_middleware_log.exists()) { try {
		 * om_middleware_log.createNewFile(); } catch (IOException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); } } BufferedWriter
		 * om_middleware_writer = null; try { om_middleware_writer = new
		 * BufferedWriter(new FileWriter( om_middleware_log, false)); } catch
		 * (IOException e1) { // TODO Auto-generated catch block
		 * e1.printStackTrace(); } //
		 * System.out.println("Reading File line by line using BufferedReader");
		 */

		String line;
		String[] tokens = null;
		try {
			line = reader.readLine();
			while (line != null) {
				// Workflow Information
				if (line.startsWith("[Debug]") && line.contains("Loading")) {
					while (!line.contains("XML Parser at start of document")) {
						if (line.startsWith("[Debug]")
								&& line.contains("Loading")) {
							writer.write(line);
							writer.newLine();
						}

						line = reader.readLine();
					}
				}

				if (line.startsWith("[Debug] Creating sampler")) {
					writer.write("Creating Model");
					writer.newLine();
					while (!line.startsWith("[Info] Finished creating model")) {
						if (line.contains("Loaded")) {
							writer.write(line);
							writer.newLine();
						}

						if (line.contains("Algorithm id")) {
							writer.write(line);
							writer.newLine();
						}
						if (line.startsWith("[Info]")) {
							writer.write(line);
							writer.newLine();
						}
						if (line.startsWith("[Warn]"))
						{
							writer.write(line);
							writer.newLine();
						}
						line = reader.readLine();
					}
					writer.write("Finished creating model");
					writer.newLine();
				}
				line = reader.readLine();
			}
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			try {
				writer.flush();
				writer.close();
				// om_middleware_writer.flush();
				// om_middleware_writer.close();
				reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
