package LogProcessor;

public class SGEParser {

}
