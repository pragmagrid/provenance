package LogProcessor;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.util.Arrays;

import org.apache.log4j.Logger;

import Util.timeParser;

public class LogParser {
	
	/* Logging Mechanism */
	static final Logger logger = Logger.getLogger("LogProcessor.LogParser");
	
	public static void modparse(String log_input, String log_output) {
		FileInputStream log;
		try {
			log = new FileInputStream(new File(log_input));

			BufferedReader reader = new BufferedReader(new InputStreamReader(
					log));

			File parsed_log = new File(log_output);
			if (!parsed_log.exists()) {
				try {
					parsed_log.createNewFile();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					logger.warn(e.getMessage());
				}
			}

			BufferedWriter writer = null;
			try {
				writer = new BufferedWriter(new FileWriter(parsed_log, false));
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				logger.warn(e1.getMessage());
			}

			String line;
			String[] tokens = null;
			try {
				line = reader.readLine();
				while (line != null) {
					// Workflow Information
					if (line.startsWith("[Debug]") && line.contains("Loading")) {
						while (!line
								.contains("XML Parser at start of document")) {
							if (line.startsWith("[Debug]")
									&& line.contains("Loading")) {
								writer.write(line);
								writer.newLine();
							}

							line = reader.readLine();
						}
					}

					if (line.startsWith("[Debug] Creating sampler")) {
						writer.write("Creating Model");
						writer.newLine();
						while (!line
								.startsWith("[Info] Finished creating model")) {
							if (line.contains("Loaded")) {
								writer.write(line);
								writer.newLine();
							}

							if (line.contains("Algorithm id")) {
								writer.write(line);
								writer.newLine();
							}
							if (line.startsWith("[Info]")) {
								writer.write(line);
								writer.newLine();
							}
							if (line.startsWith("[Warn]")) {
								writer.write(line);
								writer.newLine();
							}
							line = reader.readLine();
						}
						writer.write("Finished creating model");
						writer.newLine();
					}
					line = reader.readLine();
				}
			} catch (Exception e) {
				// TODO: handle exception
				logger.warn(e.getMessage());
			} finally {
				try {
					writer.flush();
					writer.close();
					// om_middleware_writer.flush();
					// om_middleware_writer.close();
					reader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					logger.warn(e.getMessage());
				}
			}
		} catch (FileNotFoundException e2) {
			// TODO Auto-generated catch block
			logger.warn(e2.getMessage()+";"+log_input);
		}
	}
	
	public static String jobparse(String log_input)
	{
		String output="";
		
		FileInputStream log;
		try {
			log = new FileInputStream(new File(log_input));

			BufferedReader reader = new BufferedReader(new InputStreamReader(
					log));
			
			String line;
			String[] tokens = null;
			
			String start_timestamp="";
			String job_ID="";
			String process_ID="";
			String end_timestamp="";
			try {
				line = reader.readLine();
				if(line.contains("DEBUG"))
				{
					tokens=line.split("\\s+");
					String raw_time=tokens[0]+" "+tokens[1]+" "+tokens[2]+" "+tokens[3];
					start_timestamp=timeParser.jobLogdateParser(raw_time);
				}
				while (!line.startsWith("---")&&line.contains("DEBUG")) {
					if (line.contains("Job Id"))
					{
						tokens=line.split("\\s+");
						int index=Arrays.asList(tokens).indexOf("Id:")+1;
						job_ID=tokens[index];
					}
					else if (line.contains("Process Id"))
					{
						tokens=line.split("\\s+");
						int index=Arrays.asList(tokens).indexOf("Id:")+1;
						process_ID=tokens[index];
					}
					else
					{
						tokens=line.trim().split("DEBUG");
						if(tokens.length==1)
						{
							String raw_time=tokens[0].trim();
							end_timestamp=timeParser.jobLogdateParser(raw_time);
						}
					}
					line = reader.readLine();
				}

				output=start_timestamp+";"+job_ID+";"+process_ID+";"+end_timestamp;
				logger.info("Job Information:"+output);
			} catch (Exception e) {
				output=start_timestamp+";"+job_ID+";"+process_ID+";"+end_timestamp;
				logger.info("Job Information:"+output);
				logger.warn(e.getMessage());
				// TODO: handle exception
			} finally {
				try {
					reader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					logger.warn(e.getMessage());
				}
			}
		} catch (FileNotFoundException e2) {
			// TODO Auto-generated catch block
			logger.warn(e2.getMessage()+";"+log_input);
		}
		return output;
	}
	
	public static String projparse(String log_input, String log_output)
	{
		String proj_url="";
		
		FileInputStream log;
		try {
			log = new FileInputStream(new File(log_input));

			BufferedReader reader = new BufferedReader(new InputStreamReader(
					log));

			File parsed_log = new File(log_output);
			if (!parsed_log.exists()) {
				try {
					parsed_log.createNewFile();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					logger.warn(e.getMessage());
				}
			}

			BufferedWriter writer = null;
			try {
				writer = new BufferedWriter(new FileWriter(parsed_log, false));
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				logger.warn(e1.getMessage());
			}

			String line;
			String[] tokens = null;
			try {
				line = reader.readLine();
				while (line != null) {
					// Workflow Information
					if (line.startsWith("[Debug]") && line.contains("Loading")) {
						while (!line
								.contains("XML Parser at start of document")) {
							if (line.startsWith("[Debug]")
									&& line.contains("Loading")) {
								writer.write(line);
								writer.newLine();
							}

							line = reader.readLine();
						}
					}

					if (line.startsWith("[Debug] Setting projection configuration")) {
						writer.write("Creating Projection");
						writer.newLine();
						while (!line.startsWith("[Info] Finished projecting model")) {

							if (line.contains("Algorithm id")) {
								writer.write(line);
								writer.newLine();
							}
							if (line.startsWith("[Info]")) {
								writer.write(line);
								writer.newLine();
							}
							if (line.startsWith("[Warn]")) {
								writer.write(line);
								writer.newLine();
							}
							if(line.contains("output file type"))
							{
								writer.write(line);
								writer.newLine();
							}
							line = reader.readLine();
						}
						writer.write("Finished creating model");
						writer.newLine();
					}
					line = reader.readLine();
				}
			} catch (Exception e) {
				// TODO: handle exception
				logger.warn(e.getMessage());
			} finally {
				try {
					writer.flush();
					writer.close();
					// om_middleware_writer.flush();
					// om_middleware_writer.close();
					reader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					logger.warn(e.getMessage());
				}
			}
		} catch (FileNotFoundException e2) {
			// TODO Auto-generated catch block
			logger.warn(e2.getMessage()+";"+log_input);
		}
		
		return proj_url;
	}
	
	public static void main(String[] args)
	{
		//jobparse("/home/quanzhou/java/karma/job-1-519347/jobLog-519347.log","/home/quanzhou/java/karma/test.txt");
	}
}
