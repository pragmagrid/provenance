package LogProcessor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.Namespace;
import org.jdom2.input.SAXBuilder;

import Util.ConfigManager;
import Util.mapping;

public class experimentParser {
	
	/* Logging Mechanism */
	static final Logger logger = Logger.getLogger("LogProcessor.experimentParser");
	
	public static String parse(String experiment_id, String log_output) {
		String experiment_url=mapping.exp_id2url(experiment_id);
		
		URL url = null;
		Scanner s = null;
		try {
			url = new URL(experiment_url + "/eml");
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			logger.warn(e.getMessage());
		}
		try {
			s = new Scanner(url.openStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.warn(e.getMessage());
		}

		File eml_log = new File(log_output + "/eml.xml");
		if (!eml_log.exists()) {
			try {
				eml_log.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				logger.warn(e.getMessage());
			}
		}

		BufferedWriter init_writer = null;
		try {
			init_writer = new BufferedWriter(new FileWriter(eml_log, false));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			logger.warn(e1.getMessage());
		}

		File parsed_eml_log = new File(log_output + "/eml_log.txt");
		if (!parsed_eml_log.exists()) {
			try {
				parsed_eml_log.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				logger.warn(e.getMessage());
			}
		}

		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(parsed_eml_log, false));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			logger.warn(e1.getMessage());
		}

		String line = null;
		while (s.hasNextLine()) {
			line = s.nextLine();
			try {
				init_writer.write(line);
				init_writer.newLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				logger.warn(e.getMessage());
			}
			// System.out.println(line);
		}
		try {
			init_writer.flush();
			init_writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.warn(e.getMessage());
		}

		try {
			SAXBuilder builder = new SAXBuilder();
			String xmlFileName = log_output + "/eml.xml";
			Document doc = builder.build(xmlFileName);

			Element root = doc.getRootElement();
			Element dataset = root.getChild("dataset");

			Element otherentity = dataset.getChild("otherEntity");
			Element methods = otherentity.getChild("methods");
			List<Element> methodSteps = methods.getChildren("methodStep");
			
			String species_name="";
			
			for (Element methodstep : methodSteps) {
				Element para = methodstep.getChild("description")
						.getChild("section").getChild("para");

				if (para.getValue().contains("Occurrence set")) {
					String[] tokens = para.getValue().trim().split(" ");
					writer.write("occurrence id:"+tokens[2]);
					writer.newLine();
					writer.write("timestamp:"+tokens[tokens.length - 2] + " "
							+ tokens[tokens.length - 1]);
					writer.newLine();
				}
				if (para.getValue().contains("Projection")) {
					String[] tokens = para.getValue().trim().split(" ");
					String projectionID = tokens[1];
					String scenarioID = tokens[tokens.length - 1];
					if (projectionID != "" && scenarioID != "") {

						File projection_log = new File(log_output + "/projection.xml");
						if (!projection_log.exists()) {
							try {
								projection_log.createNewFile();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								logger.warn(e.toString());
							}
						}
						BufferedWriter projection_writer = null;
						try {
							projection_writer = new BufferedWriter(
									new FileWriter(projection_log, false));
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							logger.warn(e1.getMessage());
						}

						String projection_name = "";
						String scenario_code = "";
						String scenario_metadata = "";
						String bounding_box = "";
						
						String metadata_url = mapping.pro_id2url(projectionID);
						// System.out.print(new
						// ConfigManager().getProperty("LifeMapper_Projection_URI")+"/"+projectionID+"/eml");
						URL projection_url = null;
						Scanner projection_s = null;
						try {
							projection_url = new URL(metadata_url);
						} catch (MalformedURLException e) {
							// TODO Auto-generated catch block
							logger.warn(e.getMessage());
						}
						try {
							projection_s = new Scanner(
									projection_url.openStream());

							String projection_line;
							while (projection_s.hasNextLine()) {
								projection_line = projection_s.nextLine();
								try {
									projection_writer.write(projection_line);
									projection_writer.newLine();
								} catch (IOException e) {
									// TODO Auto-generated catch block
									logger.warn(e.getMessage());
								}
							}
						} catch (IOException e) {
							// TODO Auto-generated catch block
							logger.warn(e.getMessage());
						} finally {
							projection_writer.flush();
							projection_writer.close();
							projection_s.close();
						}
						
						String LM_NS="http://lifemapper.org";
						SAXBuilder new_builder = new SAXBuilder();
						String new_xmlFileName = log_output + "/projection.xml";
						Document new_doc = new_builder.build(new_xmlFileName);

						Element new_root = new_doc.getRootElement();
						Element new_projection = new_root.getChild("projection",Namespace.getNamespace(LM_NS));
						Element new_title = new_root.getChild("title",Namespace.getNamespace(LM_NS));

						projection_name = new_title.getValue().trim();

						Element bbox=new_projection.getChild("bbox",Namespace.getNamespace(LM_NS));
						bounding_box = bbox.getValue().trim();
						
						Element scenario=new_projection.getChild("scenarioCode",Namespace.getNamespace(LM_NS));
						scenario_code = scenario.getValue().trim();
					
						Element user=new_root.getChild("user",Namespace.getNamespace(LM_NS));
						scenario_metadata=mapping.sci_id2url(user.getValue().trim(), scenarioID);
						
						Element species=new_projection.getChild("speciesName",Namespace.getNamespace(LM_NS));
						species_name=species.getValue().trim();

						
						writer.write("scenario "+scenarioID + "!" + scenario_code + "!"
								+ scenario_metadata + ";" + projectionID + "!"
								+ projection_name + "!" + bounding_box + "!"
								+scenario_code+"!"+species_name+"!"+metadata_url);
						writer.newLine();
					}
				}
			}
			writer.write("species name:"+species_name);
			writer.newLine();
		} catch (IOException e) {
			logger.warn(e.getMessage());
		} catch (JDOMException e1)
		{
			logger.warn(e1.getMessage());
		}
		finally {
			try {
				writer.flush();
				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				logger.warn(e.getMessage());
			}

		}

		return line;
	}
	
	public static String projParse(String proj_id, String log_output)
	{
		String output="";
		
		File projection_log = new File(log_output + "/projection.xml");
		if (!projection_log.exists()) {
			try {
				projection_log.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		BufferedWriter projection_writer = null;
		try {
			projection_writer = new BufferedWriter(
					new FileWriter(projection_log, false));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		String projection_name = "";
		String scenario_code = "";
		String bounding_box = "";
		String species_name="";
		
		String metadata_url = mapping.pro_id2url(proj_id);
		// System.out.print(new
		// ConfigManager().getProperty("LifeMapper_Projection_URI")+"/"+projectionID+"/eml");
		URL projection_url = null;
		Scanner projection_s = null;
		try {
			projection_url = new URL(metadata_url);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		try {
			projection_s = new Scanner(
					projection_url.openStream());

			String projection_line;
			while (projection_s.hasNextLine()) {
				projection_line = projection_s.nextLine();
				try {
					projection_writer.write(projection_line);
					projection_writer.newLine();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				projection_writer.flush();
				projection_writer.close();
				projection_s.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		String LM_NS="http://lifemapper.org";
		SAXBuilder new_builder = new SAXBuilder();
		String new_xmlFileName = log_output + "/projection.xml";
		Document new_doc;
		try {
			new_doc = new_builder.build(new_xmlFileName);
			Element new_root = new_doc.getRootElement();
			Element new_projection = new_root.getChild("projection",Namespace.getNamespace(LM_NS));
			Element new_title = new_root.getChild("title",Namespace.getNamespace(LM_NS));

			projection_name = new_title.getValue().trim();

			Element bbox=new_projection.getChild("bbox",Namespace.getNamespace(LM_NS));
			bounding_box = bbox.getValue().trim();
			
			Element scenario=new_projection.getChild("scenarioCode",Namespace.getNamespace(LM_NS));
			scenario_code = scenario.getValue().trim();
			
			Element species=new_projection.getChild("speciesName",Namespace.getNamespace(LM_NS));
			species_name=species.getValue().trim();
		} catch (JDOMException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		output=projection_name + "!" + bounding_box + "!"+ scenario_code+"!"+species_name+"!"+metadata_url;
		
		return output;
	}

}
