package Util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class timeParser {
	private static String timeZone=ConfigManager.getProperty("timeZone");
	
	public timeParser()
	{
		
	}

	public static String dateParser(Date time)
	{
		String temp =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(time);
		
		String[] tokens= temp.split(" ");
		
		String result=tokens[0]+"T"+tokens[1]+timeZone;
		
		return result;
	}
	
	public static String simpledateParser(String time) {
		String result = null;
		String[] tokens = null;
		tokens = time.split(" ");

		result=tokens[0]+"T"+tokens[1]+timeZone;
		return result;
	}

	public static String dateParser(String time) {
		String result = null;
		String[] tokens = null;
		tokens = time.split(" ");

		Date date = null;
		try {
			date = new SimpleDateFormat("MMM", Locale.ENGLISH).parse(tokens[1]);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int month = cal.get(Calendar.MONTH)+1;
		String month_string=null;
		if(month<10)
		{
			month_string="0"+Integer.toString(month);
		}
		else
		{
			month_string=Integer.toString(month);
		}
		result = tokens[5] + "-" + month_string + "-" + tokens[2] + "T"
				+ tokens[3] + timeZone;

		return result;
	}
	
	public static String epochParser(Long epochtime)
	{
		Date date=new Date(epochtime*1000);
		String result=dateParser(date);
		return result;
	}
	
	public static long timeDifference(String time1, String time2)
	{
		long time_diff=0;

		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
		Date date1;
		Date date2;
		
		try {
			date1 = format.parse(time1);
			date2 = format.parse(time2);
			time_diff= date2.getTime() - date1.getTime(); 
			return Math.abs(time_diff);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			System.out.println(e.toString());
			return -1;
		}
	}
	
	public static String jobLogdateParser(String time) {
		String result = null;
		String[] tokens = null;
		tokens = time.split(" ");

		Date date = null;
		try {
			date = new SimpleDateFormat("MMM", Locale.ENGLISH).parse(tokens[1]);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int month = cal.get(Calendar.MONTH)+1;
		String month_string=null;
		if(month<10)
		{
			month_string="0"+Integer.toString(month);
		}
		else
		{
			month_string=Integer.toString(month);
		}
		
		//Output Format: 2013-09-12T22:15:14-04:00
		result = tokens[2] + "-" + month_string + "-" + tokens[0] + "T"
				+ tokens[3]+":00" + timeZone;

		return result;
	}
}
