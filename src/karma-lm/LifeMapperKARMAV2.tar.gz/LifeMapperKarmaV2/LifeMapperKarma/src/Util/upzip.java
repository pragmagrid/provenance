package Util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class upzip {
	public static final void copyInputStream(InputStream in, OutputStream out)
			throws IOException {
		byte[] buffer = new byte[1024];
		int len;

		while ((len = in.read(buffer)) >= 0)
			out.write(buffer, 0, len);

		in.close();
		out.close();
	}

	public static final String unzip(String zip_file, String output_folder) {
		Enumeration entries;
		ZipFile zipFile;
		String log_info="";
		
		File _output=new File(output_folder);
		if(!_output.isDirectory())
		{
			_output.mkdir();
		}
		
		try {
			zipFile = new ZipFile(zip_file);

			entries = zipFile.entries();

			while (entries.hasMoreElements()) {
				ZipEntry entry = (ZipEntry) entries.nextElement();
				File new_entry=new File(output_folder+"/"+entry.getName());
				if(entry.getName().endsWith(".png"))
				{
					continue;
				}
				if (entry.isDirectory()) {
					// Assume directories are stored parents first then
					// children.
					System.err.println("Extracting directory: "
							+ entry.getName());
					log_info += "Extracting directory: " + entry.getName()
							+ "\n";
					// This is not robust, just for demonstration purposes.
					if(!new_entry.exists())
						new_entry.mkdirs();
				} else {
					if (!new_entry.exists())
						new_entry.createNewFile();
					System.err.println("Extracting file: " + entry.getName());
					log_info += "Extracting file: " + entry.getName() + "\n";
					copyInputStream(zipFile.getInputStream(entry),
							new BufferedOutputStream(new FileOutputStream(
									output_folder + "/" + entry.getName())));
				}
			}

			zipFile.close();
		} catch (IOException ioe) {
			System.err.println("Unhandled exception:");
			ioe.printStackTrace();
			log_info+="[Warning]:"+ioe.toString()+"\n";
			return log_info;
		}
		
		return log_info;
	}
}
