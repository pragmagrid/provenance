package Util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.Namespace;
import org.jdom2.input.SAXBuilder;
import org.jsoup.select.Elements;

public class experimentList {
	private String exps_file;
	private String currentTime;
	
	public experimentList(String exps_url, String exps_file, String current_time)
	{
		this.exps_file=exps_file;
		this.currentTime=current_time;
		File _file = new File(exps_file);
		if (!_file.exists()) {
			try {
				_file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.print(e.toString());
			}
		}
		BufferedWriter exps_writer = null;
		try {
			exps_writer = new BufferedWriter(
					new FileWriter(_file, false));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			System.out.print(e1.toString());
		}
		
		URL _url = null;
		Scanner exps_s = null;
		try {
			_url = new URL(exps_url);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		try {
			exps_s = new Scanner(_url.openStream());

			String exps_line;
			while (exps_s.hasNextLine()) {
				exps_line = exps_s.nextLine();
				try {
					exps_writer.write(exps_line);
					exps_writer.newLine();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				exps_writer.flush();
				exps_writer.close();
				exps_s.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.print(e.toString());
			}
		}
	}
	
	public ArrayList<String> list(int time_interval)
	{
		ArrayList<String> exps_list=new ArrayList<String>();
		
		String LM_NS="http://lifemapper.org";
		SAXBuilder builder = new SAXBuilder();
		
		Document doc;
		try {
			doc = builder.build(exps_file);
			Element root = doc.getRootElement();
			Element items = root.getChild("items",Namespace.getNamespace(LM_NS));
			List<Element> item_list = items.getChildren("item",Namespace.getNamespace(LM_NS));
			
			for(Element item: item_list)
			{
				String experimentID="";
				String experiment_url="";
				String timestamp="";
				
				Element ID=item.getChild("id",Namespace.getNamespace(LM_NS));
				experimentID=ID.getValue().trim();
				
				Element url=item.getChild("url",Namespace.getNamespace(LM_NS));
				experiment_url=url.getValue().trim();
				
				Element modTime=item.getChild("modTime",Namespace.getNamespace(LM_NS));
				timestamp=modTime.getValue().trim();
				String[] timestamp_tokens=timestamp.split(" ");
				String experiment_time=timestamp_tokens[1];
				
				long time_diff=timeParser.timeDifference(experiment_time, currentTime);
				
				if(time_diff<900000)
				{
					exps_list.add(experiment_url+";"+experimentID);
					System.out.println(experiment_url+";"+experimentID);
				}
				
			}
		} catch (JDOMException e1) {
			// TODO Auto-generated catch block
			System.out.println(e1.toString());
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			System.out.println(e2.toString());
		}
		
		return exps_list;
	}
	
	public static void main(String[] args)
	{
	new experimentList("http://lifemapper.org/services/sdm/experiments/?page=0&perPage=100&status=300&fullObjects=0&afterTime=2013-09-12&beforeTime=",
			"test.txt","17:20:00").list(100000);
	}

}