package Util;

public class mapping {
	public static String exp_id2url(String exp_id)
	{
		String exp_url=ConfigManager.getProperty("LifeMapper_WebService_URI")+"/"+exp_id;
		return exp_url;
	}
	
	public static String pro_id2url(String pro_id)
	{
		String pro_url=ConfigManager.getProperty("LifeMapper_Projection_URI")+"/"+pro_id;
		return pro_url;
	}

	public static String occ_id2url(String occ_id)
	{
		String occ_url=ConfigManager.getProperty("LifeMapper_Occurrences_URI")+"/"+occ_id;
		return occ_url;
	}
	
	public static String sci_id2url(String sci_user, String sci_id)
	{
		String sci_url="http://lifemapper.org/services/"+sci_user+"/scenarios/"+sci_id+"/eml";
		return sci_url;
	}
}
