package KarmaClient;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;

import Util.ConfigManager;
import edu.indiana.dsi.karma.client.messaging.Notification;
import edu.indiana.dsi.karma.messaging.MessageConfig;

public class client {

	private String KARMA_PROPERTIES;
	private String notification_dir;
	private String query_dir;
	
	/* Logging Mechanism */
	static final Logger logger = Logger.getLogger("KarmaClient.client");

	public client(String experiment_folder) {
		ConfigManager config_manager = new ConfigManager();
		KARMA_PROPERTIES = config_manager.getProperty("Karma_Properties");
		notification_dir = experiment_folder+"/notifications";
		query_dir = config_manager.getProperty("OPM_DIR");
		
		logger.info("Karma client is invoked...");
		logger.info("Loading KARMA PROPERTIES:"+KARMA_PROPERTIES);
		logger.info("Loading Karma notification path:"+notification_dir);
	}

	public void sendNotifications() {
		logger.info("Karma Client is sending notifications...");
		
		File dir = new File(notification_dir);
		MessageConfig config=new MessageConfig(KARMA_PROPERTIES);
		Notification notificator=new Notification(config);
		
		if (dir.isDirectory()) {
			for (File notification : dir.listFiles()) {
				try{
					notificator.sendNotification(notification);
					logger.info(notification.getName()+" is successfully sended.");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					logger.warn(e.toString());
					logger.warn(notification.getName()+" fails to send.");
				}
			}
		}
		
		notificator.closeConnection();
		notificator.closeChannel();
	}
	
	public void getWorkflowGraph()
	{
		System.out.println("\n"+"Karma Client is querying workflow graph...\n");
		
		String s = null;
		Process p = null;
		String query_xml="getWorkflowGraphRequest.xml";
		
		//Writing query xml file
		File query=new File(query_xml);
		/*BufferedWriter query_writer=null;
		try {
			query_writer = new BufferedWriter(new FileWriter(, false));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
		
		File query_output = new File(query_dir);
		if(!query_output.exists()) {
			try {
				query_output.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		BufferedWriter writer=null;
		try {
			writer = new BufferedWriter(new FileWriter(query_output, false));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			//System.out.println(KARMA_HOME+ "bin/query.sh " + KARMA_HOME + "config/karma.properties " + query.getAbsolutePath());
			p = Runtime.getRuntime().exec(KARMA_PROPERTIES+ "bin/query.sh " + KARMA_PROPERTIES + "config/karma.properties " + query.getAbsolutePath());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedReader stdInput = new BufferedReader(
				new InputStreamReader(p.getInputStream()));
		try {
			s=stdInput.readLine();
			while (s!=null && !s.contains("<v1")) {
				s=stdInput.readLine();
			}
			
			while(s!=null)
			{
				if(s.contains("<") &&!s.contains("</ns"))
				{
					writer.write(s);
					writer.newLine();
				}
				s=stdInput.readLine();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			try {
				writer.flush();
				writer.close();
				
				stdInput.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println("\n"+"Workflow Graph is successfully requested by Karma Client."+"\n");
		p.destroy();
	}
}
