package KARMADaemon;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.util.ArrayList;

import KarmaAdaptor.AdaptorTrigger;
import KarmaClient.client;
import Util.ConfigManager;
import Util.upzip;
import org.apache.log4j.*;
import org.apache.log4j.PropertyConfigurator;

public class KARMADaemon {
	
	static final Logger logger = Logger.getLogger("KARMADaemon.KARMADaemon");
	
	public static void main(String[] args) {
		String log4JPropertyFile = "config/log4j.properties";
		PropertyConfigurator.configure(log4JPropertyFile);
		
		ArrayList<String> complete_jobs = new ArrayList<String>();
		ArrayList<File> pending_jobs = new ArrayList<File>();
		String _daemon_state = ConfigManager.getProperty("Daemon_State_Path");
		String _log_central = ConfigManager.getProperty("Central_Log_Path");
		File daemon_state = new File(_daemon_state);
		File log_central = new File(_log_central);
		
		logger.info("Karma Daemon is invoked.");
		logger.info("Looping through log central location...");
		if (!log_central.exists()) {
			logger.warn("No valid log central location is specified. Terminated.");
			return;
		} else {
			logger.info("Check Karma Daemon State ...");
			if (!daemon_state.exists()) {
				try {
					daemon_state.createNewFile();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					logger.warn(e.getMessage());
				}
			}

			FileInputStream state = null;
			try {
				state = new FileInputStream(daemon_state);
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				logger.warn(e1.getMessage());
			}
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					state));
			BufferedWriter writer = null;
			try {
				writer = new BufferedWriter(new FileWriter(daemon_state, true));
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				logger.warn(e1.getMessage());
			}
			try {
				String line = reader.readLine();
				while (line != null) {
					complete_jobs.add(line);
					line = reader.readLine();
				}

				File[] dir_list = log_central.listFiles();
				for (int i = 0; i < dir_list.length; i++) {
					if (dir_list[i].isDirectory()) {
						String dirname = dir_list[i].getName();
						if (!complete_jobs.contains(dirname))
						{
							pending_jobs.add(dir_list[i]);
							logger.info("Add pending job:"+dirname);
						}
					}
				}

				for (File job_dir : pending_jobs) {
					String name = job_dir.getName();
					logger.info("Executing pending job:"+name);
					if (name.contains("job-1-")) {
						String job_log = "";
						String mod_log = "";
						
						logger.info("Job Type: Model");
						File[] job_dir_list = job_dir.listFiles();
						for (int i = 0; i < job_dir_list.length; i++) {
							if (!job_dir_list[i].isDirectory()) {
								String jobdirname = job_dir_list[i].getName();
								if (jobdirname.endsWith(".log")
										&& jobdirname.startsWith("job")) {
									job_log = job_dir_list[i].getAbsolutePath();
								}
								if (jobdirname.endsWith(".log")
										&& jobdirname.startsWith("mod")) {
									mod_log = job_dir_list[i].getAbsolutePath();
								}
							}
						}
						logger.info("Job Log Path:"+job_log);
						logger.info("Mod Log Path:"+mod_log);
						AdaptorTrigger.invoke(job_log, mod_log, name);
					} else if (name.contains("job-2-")) {
						String job_log = "";
						String pro_log = "";
						
						logger.info("Job Type: Projection");
						File[] job_dir_list = job_dir.listFiles();
						for (int i = 0; i < job_dir_list.length; i++) {
							if (!job_dir_list[i].isDirectory()) {
								String jobdirname = job_dir_list[i].getName();
								if (jobdirname.endsWith(".log")
										&& jobdirname.startsWith("job")) {
									job_log = job_dir_list[i].getAbsolutePath();
								}
								if (jobdirname.endsWith(".log")
										&& jobdirname.startsWith("proj")) {
									pro_log = job_dir_list[i].getAbsolutePath();
								}
							}
						}
						logger.info("Job Log Path:"+job_log);
						logger.info("Mod Log Path:"+pro_log);
						AdaptorTrigger.invoke(job_log, pro_log, name);
					}
					
					logger.info("Finish pending job:"+name+";Writing into daemon state.");
					writer.write(name);
					writer.newLine();
				}
				
				if(pending_jobs.size()==0)
				{
					logger.info("No Pending Jobs.Karma Daemon Suspended.");
				}
			} catch (Exception e) {
				logger.warn(e.getMessage());
			} finally {
				try {
					writer.flush();
					writer.close();
					reader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					logger.warn(e.getMessage());
				}
			}
		}
	}
}
