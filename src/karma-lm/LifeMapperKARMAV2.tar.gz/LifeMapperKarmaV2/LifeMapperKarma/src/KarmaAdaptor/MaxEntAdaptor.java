package KarmaAdaptor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.jdom2.Element;
import org.jdom2.Namespace;

import Util.ConfigManager;
import Util.timeParser;

public class MaxEntAdaptor {

	/* KARMA Namespace*/
	public Namespace ns = Namespace.getNamespace("ns",
			"http://www.dataandsearch.org/karma/2010/08/");
	public Namespace soapenv = Namespace.getNamespace("soapenv",
			"http://schemas.xmlsoap.org/soap/envelope/");

	/* Workflow General Information*/
	private String _workflowID = null;
	private String _workflowNodeID = ConfigManager.getProperty("workflowNodeID");
	private String _userDN = ConfigManager.getProperty("userDN");
	private String _usertype = ConfigManager.getProperty("type");
	private String _email = ConfigManager.getProperty("email");
	private String _workflowinvocationTime = null;
	private String _fileownerDN = ConfigManager.getProperty("file_ownerDN");
	
	/*Input Log files and Notification output folder*/
	private String parsedLogName = null;
	private String parsedemllog=null;
	//private String parsedmiddlewarelog=null;
	private String notification_dir =null;

	/*LifeMapper General Information*/
	private int timestep = 1;
	private Element LMwebserviceInformation;
	private String _LMserviceNodeID=ConfigManager.getProperty("LifeMapper_WebService_URI");
	
	/* Global Variables*/
	//private Map<String, Element> worker_map = new HashMap<String, Element>();
	private Map<String, Element>scenario_list = new HashMap<String, Element>();

	
	public MaxEntAdaptor(String experiment_folder, String experiment_url) {
		parsedLogName = experiment_folder+"/Log/parsed_maxent_log.txt";
		parsedemllog= experiment_folder+"/Log/eml_log.txt";
		//parsedmiddlewarelog=experiment_folder+"/Log/maxent_middleware_log.txt";
		_workflowID=experiment_url;
		
		notification_dir=experiment_folder+"/notifications/";
		File _notification_dir = new File(notification_dir);
		if (!_notification_dir.exists()) {
			_notification_dir.mkdir();
		} else {
			String[] _deleteFiles = _notification_dir.list();
			for (int i = 0; i < _deleteFiles.length; i++) {
				File _deleteFile = new File(_notification_dir, _deleteFiles[i]);
				_deleteFile.delete();
			}
		}
	}

	public void workflowInvoked() {

		FileInputStream parsed_Log = null;
		try {
			parsed_Log = new FileInputStream(new File(parsedLogName));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				parsed_Log));

		String line;
		String[] tokens;
		String experiment_algorithm="";
		try {
			line = reader.readLine();
			tokens = line.split("-");
			String time = tokens[0];
			_workflowinvocationTime = timeParser.dateParser(time);
			experiment_algorithm=tokens[1];
		} catch (Exception e) {
			// TODO: handle exception
		}

		Process p=null;
		try {
			p = Runtime.getRuntime().exec("uname -a");
			p.waitFor();
		} catch (IOException e4) {
			// TODO Auto-generated catch block
			e4.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		BufferedReader buf = new BufferedReader(new InputStreamReader(
				p.getInputStream()));
		String _systemInfo = "";
		String system_output = "";

		try {
			while ((system_output = buf.readLine()) != null) {
				_systemInfo += system_output + "\n";
			}
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		FileInputStream parsed_eml_log = null;
		try {
			parsed_eml_log = new FileInputStream(new File(parsedemllog));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		BufferedReader eml_reader = new BufferedReader(new InputStreamReader(
				parsed_eml_log));

		String species_name="";
		try {
			line = eml_reader.readLine();
			while(line!=null)
			{
				if(line.startsWith("species name"))
				{
					tokens=line.split(":");
					species_name=tokens[1];
				}
				line=eml_reader.readLine();
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		Element userInformation = KarmaElement.userInformation(_userDN,
				_usertype, _email);
		ArrayList<Element> wf_annotations=new LMAnnotations().modworkflowAnnotations(species_name);
		Element workflowInformation = KarmaElement.workflowInformation(
				_workflowID, _workflowNodeID, timestep,wf_annotations);
		KarmaNotification.workflowInvoked(userInformation, "USER",
				workflowInformation, "WORKFLOW", _workflowinvocationTime,
				notification_dir + "workflowInvoked.xml");
		System.out
				.println("\n LifeMapper WorkflowInvoked Notification Created and Saved!"
						+ "\n");
		timestep++;
		
		Element submitInformation = KarmaElement.serviceInformation(
				_workflowID, _workflowNodeID, timestep,
				"Submit Experiment Input");
		KarmaNotification.serviceInvoked(workflowInformation, "WORKFLOW",
				submitInformation, "SERVICE", _workflowinvocationTime,
				notification_dir + "submitInvoked.xml");
		System.out
				.println("\n LifeMapper Submit Experiment Input ServiceInvoked Notification Created and Saved!"
						+ "\n");
		timestep++;
	}
	
	public Map<String, Element> SubmitPhase()
	{
		Element submitInformation = KarmaElement.serviceInformation(
				_workflowID, _workflowNodeID, timestep - 1,
				"Submit Experiment Input");

		ArrayList<Element> LMWS_annotations=new LMAnnotations().LMwebserviceAnnotations(_LMserviceNodeID);
		LMwebserviceInformation = KarmaElement.serviceInformation(
				_workflowID, _LMserviceNodeID, timestep,
				"LifeMapper Web Service",LMWS_annotations);
		
		FileInputStream parsed_Log = null;
		try {
			parsed_Log = new FileInputStream(new File(parsedLogName));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				parsed_Log));
		
		FileInputStream parsed_eml_log = null;
		try {
			parsed_eml_log = new FileInputStream(new File(parsedemllog));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		BufferedReader eml_reader = new BufferedReader(new InputStreamReader(
				parsed_eml_log));
		
		
		String occurrenceID="";
		try {
			String occurrence_line;
			String[] occurrence_tokens;

			occurrence_line = eml_reader.readLine();
			if (occurrence_line.startsWith("occurrence id")) {
				occurrence_tokens = occurrence_line.split(":");
				occurrenceID = occurrence_tokens[1].trim();
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		String line = null;
		Map<String, Element> inputlayer_list=new HashMap<String, Element>();
		
		int count = 1;
		try {
			
			line=reader.readLine();
			while(!line.startsWith("layer"))
			{
				line=reader.readLine();
			}
			
			String[] tokens = null;
			
			
			while (!line.contains("Phase 2 begins")) 
			{
					tokens = line.split(";");

					String consumeTimestamp = _workflowinvocationTime;
					String produceTimestamp = _workflowinvocationTime;
					
					String[] layer_tokens=tokens[1].split(",");
					String[] layer_name_tokens=layer_tokens[0].split("/");
					Element layer_file = KarmaElement.File(layer_tokens[0], layer_tokens[1], consumeTimestamp, 
							layer_name_tokens[layer_name_tokens.length-1], _fileownerDN);
					ArrayList<Element> layer_annotations = new LMAnnotations().layerAnnotations(layer_tokens[2],tokens[2],occurrenceID);
					Element layer_object = KarmaElement.dataObject(layer_file,layer_annotations);
					
					KarmaNotification.dataRelation("PRODUCE",
							submitInformation, "SERVICE", layer_object,
							produceTimestamp, "File Produced",
							notification_dir + "layerProduced" + count + ".xml");

					KarmaNotification.dataRelation("CONSUME", LMwebserviceInformation,
							"SERVICE", layer_object, consumeTimestamp,
							"File Consumed", notification_dir + "layerReceived"
									+ count + ".xml");
					
					count++;
					inputlayer_list.put(layer_tokens[0], layer_object);
					
					line = reader.readLine();
				}
			
			line=eml_reader.readLine();
			count=1;
			while(line!=null)
			{
				if(line.startsWith("scenario"))
				{
					String consumeTimestamp = _workflowinvocationTime;
					String produceTimestamp = _workflowinvocationTime;
					
					tokens=line.split(";");
					String scenario_line=tokens[0];
					String[] scenario_tokens=scenario_line.split("!");
					
					String scenarioID=scenario_tokens[0];
					String scenario_code=scenario_tokens[1];
					String scenario_metadata=scenario_tokens[2];
					
					Element scenario_file = KarmaElement.File(scenario_metadata, "0", consumeTimestamp, 
							scenarioID, _fileownerDN);
					ArrayList<Element> scenario_annotations = new LMAnnotations().scenarioAnnotations(scenario_code, scenario_metadata);
					Element scenario_object = KarmaElement.dataObject(scenario_file,scenario_annotations);
					
					KarmaNotification.dataRelation("PRODUCE",
							submitInformation, "SERVICE", scenario_object,
							produceTimestamp, "File Produced",
							notification_dir + "scenarioProduced" + count + ".xml");
					
					KarmaNotification.dataRelation("CONSUME", LMwebserviceInformation,
							"SERVICE", scenario_object, consumeTimestamp,
							"File Consumed", notification_dir + "scenarioReceived"
									+ count + ".xml");
					count++;
					scenario_list.put(scenarioID, scenario_object);
				}
				
				line=eml_reader.readLine();
			}
			System.out.println("\nLifeMapper Submit Experiment Input Phase Notification Created and Saved!\n");
		} catch (Exception e) {
			System.out.print(e);
			// TODO: handle exception
		} finally {
			try {
				reader.close();
			} catch (IOException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		
		timestep++;
		return inputlayer_list;
	}
	
	public ArrayList<Element> ConversionPhase(Map<String, Element> inputlayer_list) {

		FileInputStream parsed_Log = null;
		try {
			parsed_Log = new FileInputStream(new File(parsedLogName));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				parsed_Log));

		ArrayList<Element> outputmxe_list = new ArrayList<Element>();
		String line = null;

		int count = 1;
		try {
			
			line=reader.readLine();
			while(!line.startsWith("layer"))
			{
				line=reader.readLine();
			}
			
			String[] tokens = null;

			while (!line.contains("Phase 2 begins")) 
			{
					tokens = line.split(";");

					String _serviceNodeID = _workflowNodeID;

					String consumeTimestamp = _workflowinvocationTime;
					String produceTimestamp = _workflowinvocationTime;
					
					String[] layer_tokens=tokens[1].split(",");
					Element layer_object = inputlayer_list.get(layer_tokens[0]);
					
					String[] mxe_tokens=tokens[3].split("/");
					Element mxe_file = KarmaElement.File(tokens[3], "0", produceTimestamp, 
							mxe_tokens[mxe_tokens.length-1], _fileownerDN);
					Element mxe_object = KarmaElement.dataObject(mxe_file,null);
					
					ArrayList<Element> conversion_anno=LMAnnotations.conversionAnnotations(tokens[4], tokens[5]);
					Element conversionInformation = KarmaElement.serviceInformation(
							_workflowID, _serviceNodeID, timestep,
							"Layer File Conversion", conversion_anno);
					
					KarmaNotification.serviceInvoked(LMwebserviceInformation, "SERVICE",
							conversionInformation, "SERVICE", consumeTimestamp,
							notification_dir + "conversionInvoked" + count + ".xml");

					KarmaNotification.dataRelation("CONSUME", conversionInformation,
							"SERVICE", layer_object, consumeTimestamp,
							"File Consumed", notification_dir + "layerConsumed"
									+ count + ".xml");
					KarmaNotification.dataRelation("PRODUCE", conversionInformation,
							"SERVICE", mxe_object, produceTimestamp,
							"File Produced", notification_dir + "mxeProduced"
									+ count + ".xml");
					outputmxe_list.add(mxe_object);

					count++;
					timestep++;
					line = reader.readLine();
				}

			System.out.println("\nLifeMapper Conversion Phase Notification Created and Saved!\n");
		} catch (Exception e) {
			System.out.print(e);
			// TODO: handle exception
		} finally {
			try {
				reader.close();
			} catch (IOException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}

		return outputmxe_list;
	}

	public Element Phase2(ArrayList<Element> outputmxe_list) {
		FileInputStream parsed_Log = null;
		try {
			parsed_Log = new FileInputStream(new File(parsedLogName));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				parsed_Log));

		String line = null;
		
		String[] tokens = null;
		String[] warning_tokens=null;
		String phase2_time="";
		String phase2_samples="";
		
		String phase2_timestamp = _workflowinvocationTime;

		try {
			line = reader.readLine();
			while (!line.startsWith("Phase 2 begins")) 
			{
				line = reader.readLine();
			}
			while (!line.contains("Phase 2 ends")) {
				line = line.trim();
				if (line.startsWith("warning:")) {
					tokens = line.split(":");
					warning_tokens=tokens[1].split(";");
				} else if (line.startsWith("time")) {
					tokens = line.split(":");
					phase2_time=tokens[1];
				} else if(line.startsWith("samples")){
					tokens=line.split(":");
					phase2_samples=tokens[1];
				}
				line = reader.readLine();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ArrayList<Element> phase2Annotations=new LMAnnotations().phase2Annotations(warning_tokens, phase2_time, phase2_samples);
		Element phase2_Information=KarmaElement.serviceInformation(_workflowID, _workflowNodeID, timestep, "Extracting random background and sample data", phase2Annotations);
		KarmaNotification.serviceInvoked(LMwebserviceInformation, "SERVICE",
				phase2_Information, "SERVICE", phase2_timestamp, notification_dir
						+ "phase2_Invoked.xml");
		
		int count = 1;
		for (Element outputmxe : outputmxe_list) {
			KarmaNotification.dataRelation("CONSUME", phase2_Information,
					"SERVICE", outputmxe, phase2_timestamp, "File Consumed",
					notification_dir + "phase2_mxeConsumed" + count + ".xml");
			count++;
		}

		System.out
				.println("\nLifeMapper Add samples to background Phase Notification Created and Saved!\n");
		timestep++;
		return phase2_Information;
	}
	
	public Element Phase3(Element phase2_information) {
		FileInputStream parsed_Log = null;
		try {
			parsed_Log = new FileInputStream(new File(parsedLogName));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				parsed_Log));

		String line = null;
		
		String[] tokens = null;
		String command_line_used="";
		String species="";
		String layers="";
		String layer_types="";
		String output_dir="";
		String samples_file="";
		String environmentallayers="";
		String setup_warnings="";
		String setup_autorun="";
		String setup_visible="";
		
		String phase3_timestamp = _workflowinvocationTime;
		String produceTimestamp = _workflowinvocationTime;
		String consumeTimestamp = _workflowinvocationTime;
		
		try {
			line = reader.readLine();
			while (!line.startsWith("Phase 3 begins")) 
			{
				line = reader.readLine();
			}
			while (!line.contains("Phase 3 ends")) {
				line = line.trim();
				if (line.startsWith("Command line used")) {
					tokens = line.split(":");
					command_line_used=tokens[1].trim();
				} else if (line.startsWith("Species")) {
					tokens = line.split(":");
					species=tokens[1];
				} else if(line.startsWith("Layers")){
					tokens=line.split(":");
					layers=tokens[1];
				} else if(line.startsWith("Layertypes"))
				{
					tokens=line.split(":");
					layer_types=tokens[1];
				} else if(line.startsWith("outputdirectory"))
				{
					tokens=line.split(":");
					output_dir=tokens[1];
				}
				else if(line.startsWith("samplesfile"))
				{
					tokens=line.split(":");
					samples_file=tokens[1];
				}
				else if(line.startsWith("environmentallayers"))
				{
					tokens=line.split(":");
					environmentallayers=tokens[1];
				}
				else if(line.startsWith("warnings"))
				{
					tokens=line.split(":");
					setup_warnings=tokens[1];
				}
				else if(line.startsWith("autorun"))
				{
					tokens=line.split(":");
					setup_autorun=tokens[1];
				}
				else if(line.startsWith("visible"))
				{
					tokens=line.split(":");
					setup_visible=tokens[1];
				}
					
				line = reader.readLine();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Element env_layers_file = KarmaElement.File(environmentallayers, "0", produceTimestamp, 
				environmentallayers, _fileownerDN);
		ArrayList<Element> env_layers_anno= new LMAnnotations().envlayersAnnotations(layers,layer_types);
		Element env_layers_object = KarmaElement.dataObject(env_layers_file, env_layers_anno);

		KarmaNotification.dataRelation("PRODUCE", phase2_information,
				"SERVICE", env_layers_object, produceTimestamp,
				"File Produced", notification_dir + "envlayersProduced.xml");
		
		ArrayList<Element> phase3Annotations=new LMAnnotations().phase3Annotations(command_line_used, species, layers, layer_types, 
				output_dir, samples_file, environmentallayers, setup_warnings, setup_autorun, setup_visible);
		Element phase3_Information=KarmaElement.serviceInformation(_workflowID, _workflowNodeID, timestep, "Adding samples to background in feature space", phase3Annotations);
		
		KarmaNotification.dataRelation("CONSUME", phase3_Information,
				"SERVICE", env_layers_object, consumeTimestamp,
				"File Consumed", notification_dir + "envlayersConsumed.xml");

		Element samples_output_file = KarmaElement.File(output_dir, "0", produceTimestamp, 
				output_dir, _fileownerDN);
		Element samples_output_object = KarmaElement.dataObject(samples_output_file, null);

		KarmaNotification.dataRelation("PRODUCE", phase3_Information,
				"SERVICE", samples_output_object, produceTimestamp,
				"File Produced", notification_dir + "samplesoutputProduced.xml");

		System.out
				.println("\nLifeMapper Experiment Execution Phase Notification Created and Saved!\n");
		
		timestep++;
		return samples_output_object;
	}
	
	public Element Phase5(Element samples_output_information) {
		FileInputStream parsed_Log = null;
		try {
			parsed_Log = new FileInputStream(new File(parsedLogName));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				parsed_Log));

		String line = null;
		
		String[] tokens = null;
		String regularization="";
		String density="";
		String linearpredictor="";
		String phase5_time="";
		String featuredspace="";
		String sequential="";
		String initialloss="";
		String resulting_gain="";
		
		String phase5_timestamp = _workflowinvocationTime;
		String produceTimestamp = _workflowinvocationTime;
		String consumeTimestamp = _workflowinvocationTime;
		
		try {
			line = reader.readLine();
			while (!line.startsWith("Phase 5 begins")) 
			{
				line = reader.readLine();
			}
			while (!line.contains("Phase 5 ends")) {
				line = line.trim();
				if (line.startsWith("Regularization values")) {
					tokens = line.split(":");
					regularization=tokens[1].trim()+":"+tokens[2].trim();
					featuredspace=tokens[1];
				} else if (line.startsWith("Density")) {
					tokens = line.split(":");
					density=tokens[1];
				} else if(line.startsWith("linearPredictor")){
					tokens=line.split(":");
					linearpredictor=tokens[1];
				} else if(line.startsWith("Sequential"))
				{
					tokens=line.split(":");
					sequential=tokens[1];
				}
				else if(line.startsWith("Initial loss"))
				{
					tokens=line.split(":");
					initialloss=tokens[1];
				}
				else if(line.startsWith("Time since start"))
				{
					tokens=line.split(":");
					phase5_time=tokens[1];
				}
				else if(line.startsWith("Resulting gain"))
				{
					tokens=line.split(":");
					resulting_gain=tokens[1];
				}
					
				line = reader.readLine();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ArrayList<Element> phase5Annotations=new LMAnnotations().phase5Annotations(regularization, density, linearpredictor,
				phase5_time, featuredspace, sequential, initialloss);
		Element phase5_Information=KarmaElement.serviceInformation(_workflowID, _workflowNodeID, timestep, "Make Features", phase5Annotations);
		
		KarmaNotification.dataRelation("CONSUME", phase5_Information,
				"SERVICE", samples_output_information, consumeTimestamp,
				"File Consumed", notification_dir + "samplesoutputConsumed.xml");

		Element featuredspace_file = KarmaElement.File(featuredspace, "0", produceTimestamp, 
				featuredspace, _fileownerDN);
		ArrayList<Element> featuredspace_anno= new LMAnnotations().featuredspaceAnnotations(sequential,initialloss, phase5_time, resulting_gain);
		Element featuredspace_object = KarmaElement.dataObject(featuredspace_file, featuredspace_anno);

		KarmaNotification.dataRelation("PRODUCE", phase5_Information,
				"SERVICE", featuredspace_object, produceTimestamp,
				"File Produced", notification_dir + "featuredspaceProduced.xml");
		
		System.out
				.println("\nLifeMapper Make features Phase Notification Created and Saved!\n");
		
		timestep++;
		return featuredspace_object;
	}
	
	public Element Phase7(Element featuredspace_object) {
		Element SDMInformation=null;
		
		FileInputStream parsed_Log = null;
		try {
			parsed_Log = new FileInputStream(new File(parsedLogName));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				parsed_Log));

		String line = null;
		
		String[] tokens = null;
		String phase7_output="";
		
		String phase7_timestamp = _workflowinvocationTime;
		String consumeTimestamp = _workflowinvocationTime;
		
		try {
			line = reader.readLine();
			while (!line.startsWith("Phase 6 begins")) 
			{
				line = reader.readLine();
			}
			while (!line.contains("Phase 6 ends")) {
				line = line.trim();
				if (line.startsWith("Projecting")) {
					tokens = line.split(":");
					phase7_output=tokens[1];
				} 
				line = reader.readLine();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Element phase7_Information=KarmaElement.serviceInformation(_workflowID, _workflowNodeID, timestep, "Projecting Species Distribution Model");
		KarmaNotification.dataRelation("CONSUME", phase7_Information,
				"SERVICE", featuredspace_object, consumeTimestamp,
				"File Consumed", notification_dir + "featuredspaceConsumed.xml");
		
		String[] LM_output=phase7_output.split(";");
		int count=1;
		for(int i=0; i<LM_output.length;i++)
		{
			String[] output_tokens=LM_output[i].split(",");
			String file_uri=output_tokens[0];
			String projecting_time=output_tokens[1];
			
			String[] file_uri_tokens=file_uri.split("/");
			String file_name=file_uri_tokens[file_uri_tokens.length-1];
			
			ArrayList<Element> output_file_anno=new LMAnnotations().projectingAnnotations(projecting_time);
			Element output_file = KarmaElement.File(file_uri, "0", phase7_timestamp, 
					file_name, _fileownerDN);
			Element output_object = KarmaElement.dataObject(output_file,output_file_anno);
			
			String timestamp=_workflowinvocationTime;
			KarmaNotification.dataRelation("PRODUCE",
					phase7_Information, "SERVICE", output_object,
					timestamp, "File Produced",
					notification_dir + "modelProduced" + count + ".xml");
			if(file_name.endsWith("asc"))
				SDMInformation=output_object;
			
			count++;
		}
		
		System.out.println("\nLifeMapper Projecting Species Distribution Model Phase Notification Created and Saved!\n");
		timestep++;
		return SDMInformation;
	}
	
	public void projectionPhase(Element SDMInformation)
	{
		FileInputStream parsed_eml_log = null;
		try {
			parsed_eml_log = new FileInputStream(new File(parsedemllog));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		BufferedReader eml_reader = new BufferedReader(new InputStreamReader(
				parsed_eml_log));

		String line = null;

		int count = 1;
		try {
			
			line=eml_reader.readLine();
			while(!line.startsWith("scenario"))
			{
				line=eml_reader.readLine();
			}
			
			String[] tokens = null;

			while (line!=null&&line.startsWith("scenario")) 
			{
					tokens = line.split(";");

					String scenario_line = tokens[0];
					String[] scenario_tokens=scenario_line.split("!");
					
					Element scenario_object = scenario_list.get(scenario_tokens[0]);

					String consumeTimestamp = _workflowinvocationTime;
					String produceTimestamp = _workflowinvocationTime;
					
					Element projection_Information=KarmaElement.serviceInformation(_workflowID, _workflowNodeID, timestep, "Generate Projection");
					KarmaNotification.serviceInvoked(LMwebserviceInformation, "SERVICE",
							projection_Information, "SERVICE", consumeTimestamp, notification_dir
									+ "projection"+count+"Invoked.xml");
					
					KarmaNotification.dataRelation("CONSUME", projection_Information,
							"SERVICE", SDMInformation, consumeTimestamp,
							"File Consumed", notification_dir + "SDMConsumed"
									+ count + ".xml");
					KarmaNotification.dataRelation("CONSUME", projection_Information,
							"SERVICE", scenario_object, consumeTimestamp,
							"File Consumed", notification_dir + "scenarioConsumed"
									+ count + ".xml");
					
					String projection_line=tokens[1];
					String[] projection_tokens=projection_line.split("!");
					String projection_name=projection_tokens[1];
					String bounding_box=projection_tokens[2];
					String scenario_code=projection_tokens[3];
					String species_name=projection_tokens[4];
					String projection_metadata=projection_tokens[5];
					
					Element projection_file = KarmaElement.File(projection_metadata, "0", produceTimestamp, 
							projection_name, _fileownerDN);
					ArrayList<Element> projection_anno= new LMAnnotations().projectionAnnotations(projection_name, 
																bounding_box, scenario_code, species_name, projection_metadata);
					Element projection_object = KarmaElement.dataObject(projection_file,projection_anno);
			
					KarmaNotification.dataRelation("PRODUCE", projection_Information,
							"SERVICE", projection_object, produceTimestamp,
							"File Produced", notification_dir + "projectionProduced"
									+ count + ".xml");

					count++;
					timestep++;
					line = eml_reader.readLine();
				}
			System.out.println("\nLifeMapper Species Distribution Projection Phase Notification Created and Saved!\n");
		} catch (Exception e) {
			System.out.print(e);
			// TODO: handle exception
		} finally {
			try {
				eml_reader.close();
			} catch (IOException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
	}
}