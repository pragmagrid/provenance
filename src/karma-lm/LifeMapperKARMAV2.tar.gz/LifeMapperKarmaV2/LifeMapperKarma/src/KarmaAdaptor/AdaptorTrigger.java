package KarmaAdaptor;

import java.io.File;
import java.util.ArrayList;
import java.util.Map;

import org.apache.log4j.Logger;
import org.jdom2.Element;

import KarmaClient.client;
import LogProcessor.LogParser;
import LogProcessor.experimentParser;
import LogProcessor.testLogParser;
import Util.ConfigManager;

public class AdaptorTrigger {
	static final Logger logger = Logger.getLogger("KarmaAdaptor.AdaptorTrigger");
	
	public static void invoke(String job_log, String app_log, String job_name) {
		ConfigManager config_Manager = new ConfigManager();
		String _job_folder = "experiment/" + job_name;
		File job_folder = new File(_job_folder);
		if (!job_folder.isDirectory()) {
			job_folder.mkdirs();
		}
		logger.info("Karma Adaptor For LifeMapper is invoked by Job"+job_name);
		//Parsing Experiment Log files
		logger.info("Creating Job Provenance Folder...");
		String _logoutput=_job_folder+"/Log";
		File logoutput=new File(_logoutput);
		
		if(!logoutput.isDirectory())
		{
			logoutput.mkdirs();
		}
		logger.info("Job Provenance Folder:"+_logoutput);
		if(job_name.contains("job-1-"))
		{
			String[] tokens=job_name.split("-");
			String job_ID=tokens[tokens.length-1];
			
			LogParser.modparse(app_log, _logoutput+"/parsed_appLog.txt");
			logger.info("Parsing Mod Log. Source:"+app_log+"; Output:"+_logoutput+"/parsed_appLog.txt");
			
			String job_info=LogParser.jobparse(job_log);
			logger.info("Parsing Job Log. Source:"+job_log+"; Output:"+job_info);
			
			experimentParser.parse(job_ID, _logoutput);
			logger.info("Parsing Experiment Log. Experiment ID:"+job_ID+"; Output:"+_logoutput);
			
			modJobAdaptor karma_adaptor = new modJobAdaptor(_job_folder,job_ID, job_info);
			logger.info("Convert Raw Information into Provenance Notification...");
			
			logger.info("Generate Workflow Invoked Notification...");
			karma_adaptor.workflowInvoked();
			logger.info("Generate Submit Phase Notification...");
			Element occurrence_set = karma_adaptor.SubmitPhase();
			logger.info("Generate Load Lib and Model Creating Phase Notification...");
			Element SDMInformation = karma_adaptor.loadLibPhase(occurrence_set);
			logger.info("Generate Projection Creating Phase Notification...");
			karma_adaptor.projectionPhase(SDMInformation);
			logger.info("KARMA Adaptor For Job "+job_name+" finished.");
			
			logger.info("Send Notifications To IU Karma Server with Karma Client...");
			client Karma_client=new client(_job_folder);
			Karma_client.sendNotifications();
			logger.info(job_name+" provenance collection is finished.");
		}
		else if(job_name.contains("job-2-"))
		{
			String[] tokens=job_name.split("-");
			String job_ID=tokens[tokens.length-1];
			
			String proj_ID=LogParser.projparse(app_log, _logoutput+"/parsed_appLog.txt");
			logger.info("Parsing Proj Log. Source:"+app_log+"; Output:"+_logoutput+"/parsed_appLog.txt; "+"Proj ID:"+proj_ID);
			String job_info=LogParser.jobparse(job_log);
			logger.info("Parsing Job Log. Source:"+job_log+"; Output:"+job_info);
			
			projJobAdaptor karma_adaptor = new projJobAdaptor(_job_folder,job_ID, job_info, "2514990");
			logger.info("Convert Raw Information into Provenance Notification...");

			logger.info("Generate Workflow Invoked Notification...");
			karma_adaptor.workflowInvoked();
			logger.info("Generate Projection Creating Phase Notification...");
			karma_adaptor.projectionPhase();
			logger.info("KARMA Adaptor For Job "+job_name+" finished.");
			
			logger.info("Send Notifications To IU Karma Server with Karma Client...");
			client Karma_client=new client(_job_folder);
			Karma_client.sendNotifications();
			logger.info(job_name+" provenance collection is finished.");
		}
		
		//Algorithm is ATT MAXENT
		/*if (algorithm.equalsIgnoreCase("ATT_MAXENT")) {
			
			log_parser.maxEntParse();
			log_parser.projectionParser(experiment_url);

			MaxEntAdaptor karma_adaptor = new MaxEntAdaptor(experiment_folder,experiment_url);

			System.out.println("\n" + "KARMA Adaptor is starting...\n");

			karma_adaptor.workflowInvoked();
			Map<String, Element> inputlayer_list = karma_adaptor.SubmitPhase();
			ArrayList<Element> outputmxe_list = karma_adaptor.ConversionPhase(inputlayer_list);

			Element phase2_information = karma_adaptor.Phase2(outputmxe_list);

			Element samples_output = karma_adaptor.Phase3(phase2_information);
			Element featuredspace = karma_adaptor.Phase5(samples_output);
			Element SDMInformation = karma_adaptor.Phase7(featuredspace);
			karma_adaptor.projectionPhase(SDMInformation);
			System.out.println("\n" + "KARMA Adaptor finished.\n");
		} 
		
		// Algorithm is not MAXENT
		else 
		{*/	
	}
	public static void main(String[] args)
	{
		invoke("/home/quanzhou/LifeMapper/jobs/job-1-519347/jobLog-519347.log","/home/quanzhou/LifeMapper/jobs/job-1-519347/modLog-519347.log","job-1-519347");
		//invoke("/home/quanzhou/LifeMapper/jobs/job-2-39070/jobLog-39070.log","/home/quanzhou/LifeMapper/jobs/job-2-39070/projLog-39070.log","job-2-39070");
	}
}
