package KarmaAdaptor;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.jdom2.Element;
import org.jdom2.Namespace;

import Util.ConfigManager;

public class LMAnnotations {
	
	private InputStream input_file=null;
	private Namespace ns = Namespace.getNamespace("ns","http://www.dataandsearch.org/karma/2010/08/");
	private Namespace soapenv = Namespace.getNamespace("soapenv","http://schemas.xmlsoap.org/soap/envelope/");
	
	public LMAnnotations(String file_url)
	{
		URL url=null;
		try {
			url = new URL(file_url);
			try {
				input_file=url.openStream();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public LMAnnotations()
	{
		
	}
	
	public ArrayList<Element> modworkflowAnnotations(String species_name)
	{
		ArrayList<Element> wf_anno=new ArrayList<Element>();
		
		Element species=KarmaElement.annotations("Species Name", species_name);
		
		wf_anno.add(species);
		
		return wf_anno;
	}
	
	public ArrayList<Element> LMwebserviceAnnotations(String _ws_uri)
	{
		ArrayList<Element> LMWS_anno=new ArrayList<Element>();
		
		Element ws_uri=KarmaElement.annotations("LifeMapper Web Service URI", _ws_uri);
		
		LMWS_anno.add(ws_uri);
		
		return LMWS_anno;
	}
	
	public ArrayList<Element> layerAnnotations(String _maxmemory, String _pixels, String _occurrenceID)
	{
		ArrayList<Element> layer_anno=new ArrayList<Element>();
		
		Element maxmemory=KarmaElement.annotations("Max Memory", _maxmemory);
		Element pixels=KarmaElement.annotations("Pixels with data", _pixels);
		Element occurrence_metadata=KarmaElement.annotations("Occurrence Set Metadata URL", 
				new ConfigManager().getProperty("LifeMapper_Occurrences_URI")+"/"+_occurrenceID);
		layer_anno.add(maxmemory);
		layer_anno.add(pixels);
		layer_anno.add(occurrence_metadata);
		
		return layer_anno;
	}
	
	public ArrayList<Element> scenarioAnnotations(String _scenario_code, String _scenario_metadata)
	{
		ArrayList<Element> scenario_anno=new ArrayList<Element>();
		
		Element scenario_code=KarmaElement.annotations("Scenario Code", _scenario_code);
		Element scenario_metadata=KarmaElement.annotations("Scenario Metadata URL", _scenario_metadata);
		
		scenario_anno.add(scenario_code);
		scenario_anno.add(scenario_metadata);
		
		return scenario_anno;
	}
	
	public ArrayList<Element> projectionAnnotations(String _projection_name, String _bounding_box, String _scenario_code, String _species_name, String _projection_metadata)
	{
		ArrayList<Element> projection_anno=new ArrayList<Element>();
		
		Element projection_name=KarmaElement.annotations("projection Name", _projection_name);
		Element bounding_box=KarmaElement.annotations("Bounding Box", _bounding_box);
		Element scenario_code=KarmaElement.annotations("Scenario Code", _scenario_code);
		Element species_name=KarmaElement.annotations("Species Name", _species_name);
		Element projection_metadata=KarmaElement.annotations("Projection Metadata URL", _projection_metadata);
		
		projection_anno.add(projection_name);
		projection_anno.add(bounding_box);
		projection_anno.add(scenario_code);
		projection_anno.add(species_name);
		projection_anno.add(projection_metadata);
		
		return projection_anno;
	}
	
	
	public ArrayList<Element> phase2Annotations(String[] _warning_tokens, String _time, String _samples)
	{
		ArrayList<Element> phase2_anno=new ArrayList<Element>();
		
		int warnings_num=_warning_tokens.length;
		for(int i=0;i<warnings_num;i++)
		{
			Element warning=KarmaElement.annotations("Warning", _warning_tokens[i]);
			phase2_anno.add(warning);
		}
		
		Element maxmemory=KarmaElement.annotations("Execution Time", _time);
		Element pixels=KarmaElement.annotations("Samples Number", _samples);
		
		phase2_anno.add(maxmemory);
		phase2_anno.add(pixels);
		
		return phase2_anno;
	}

	public ArrayList<Element> phase3Annotations(String _command_line, String _species, String _layers, String _layer_types, 
			String _output_dir, String _samples_file, String _env_layers, String _setup_warnings, String _setup_autorun, String
			_setup_visible)
	{
		ArrayList<Element> phase3_anno=new ArrayList<Element>();
		
		Element command_line=KarmaElement.annotations("Command Line Used", _command_line);
		Element species=KarmaElement.annotations("Samples Number", _species);
		Element layers=KarmaElement.annotations("Layers", _layers);
		Element layer_types=KarmaElement.annotations("Layer types", _layer_types);
		Element output_dir=KarmaElement.annotations("outputdirectory", _output_dir);
		Element samples_file=KarmaElement.annotations("samplesfile",_samples_file);
		Element env_layers=KarmaElement.annotations("enviromentallayers", _env_layers);
		Element warnings=KarmaElement.annotations("warnings",_setup_warnings);
		Element autorun=KarmaElement.annotations("autorun",_setup_autorun);
		Element visible=KarmaElement.annotations("visible",_setup_visible);
		
		phase3_anno.add(command_line);
		phase3_anno.add(species);
		phase3_anno.add(layers);
		phase3_anno.add(layer_types);
		phase3_anno.add(output_dir);
		phase3_anno.add(samples_file);
		phase3_anno.add(env_layers);
		phase3_anno.add(warnings);
		phase3_anno.add(autorun);
		phase3_anno.add(visible);
		
		return phase3_anno;
	}
	
	public ArrayList<Element> envlayersAnnotations(String _layers, String _layer_types)
	{
		ArrayList<Element> env_layers_anno=new ArrayList<Element>();
		
		Element layers=KarmaElement.annotations("Layers",_layers);
		Element layer_types=KarmaElement.annotations("Layer Types",_layer_types);
		
		env_layers_anno.add(layers);
		env_layers_anno.add(layer_types);
		
		return env_layers_anno;
	}
	
	public ArrayList<Element> featuredspaceAnnotations(String _sequential,String _initialloss, 
						String _phase5_time,String _resulting_gain)
	{
		ArrayList<Element> featuredspace_anno=new ArrayList<Element>();
		
		Element sequential=KarmaElement.annotations("Sequential",_sequential);
		Element initialloss=KarmaElement.annotations("Initial Loss",_initialloss);
		Element phase5_time=KarmaElement.annotations("Time since start",_phase5_time);
		Element resulting_gain=KarmaElement.annotations("Resulting gain",_resulting_gain);
		
		featuredspace_anno.add(sequential);
		featuredspace_anno.add(initialloss);
		featuredspace_anno.add(phase5_time);
		featuredspace_anno.add(resulting_gain);
		
		return featuredspace_anno;
	}
	
	public ArrayList<Element> modelAnnotations(ArrayList<String> _modelAnnotations)
	{
		ArrayList<Element> modelAnnotations=new ArrayList<Element>();
		
		int count=1;
		for(String _annotation: _modelAnnotations)
		{
			Element annotation=KarmaElement.annotations("Model Annotation "+Integer.toString(count), _annotation);
			
			modelAnnotations.add(annotation);
			count++;
		}
		
		return modelAnnotations;
	}
	
	public ArrayList<Element> projAnnotations(ArrayList<String> _projAnnotations)
	{
		ArrayList<Element> projAnnotations=new ArrayList<Element>();
		
		int count=1;
		for(String _annotation: _projAnnotations)
		{
			Element annotation=KarmaElement.annotations("Projection Annotation "+Integer.toString(count), _annotation);
			
			projAnnotations.add(annotation);
			count++;
		}
		
		return projAnnotations;
	}
	
	public ArrayList<Element> occuAnnotations(ArrayList<String> _occuAnnotations)
	{
		ArrayList<Element> occuAnnotations=new ArrayList<Element>();
		
		int count=1;
		for(String _annotation: _occuAnnotations)
		{
			Element annotation=KarmaElement.annotations("Occurrence Dataset Annotation "+Integer.toString(count), _annotation);
			
			occuAnnotations.add(annotation);
			count++;
		}
		
		return occuAnnotations;
	}
	
	public ArrayList<Element> phase5Annotations(String _regularization, String _density, String _linearpredictor,
	String _phase5_time, String _featuredspace, String _sequential, String _initialloss)
	{
		ArrayList<Element> phase5_anno=new ArrayList<Element>();
		
		Element regularization=KarmaElement.annotations("Regularization values", _regularization);
		Element density=KarmaElement.annotations("Density", _density);
		Element linearpredictor=KarmaElement.annotations("linearPredictor", _linearpredictor);
		Element featuredspace=KarmaElement.annotations("FeaturedSpace", _featuredspace);
		Element sequential=KarmaElement.annotations("Sequential", _sequential);
		Element initialloss=KarmaElement.annotations("Initial loss",_initialloss);
		Element phase5_time=KarmaElement.annotations("Execution Time", _phase5_time);
		
		phase5_anno.add(regularization);
		phase5_anno.add(density);
		phase5_anno.add(linearpredictor);
		phase5_anno.add(featuredspace);
		phase5_anno.add(sequential);
		phase5_anno.add(initialloss);
		phase5_anno.add(phase5_time);
		
		return phase5_anno;
	}
	
	public ArrayList<Element> projectingAnnotations(String _projectingtime)
	{
		ArrayList<Element> projecting_anno=new ArrayList<Element>();
		
		Element projectingtime=KarmaElement.annotations("Projecting Time", _projectingtime);
		
		projecting_anno.add(projectingtime);
		
		return projecting_anno;
	}
	
	public static ArrayList<Element> conversionAnnotations(String _system, String _time)
	{
		ArrayList<Element> conversion_result=new ArrayList<Element>();
		
		Element system=KarmaElement.annotations("System Information", _system);
		Element host=KarmaElement.annotations("Time since start", _time);
		
		conversion_result.add(system);
		conversion_result.add(host);
		
		return conversion_result;
	}

}
