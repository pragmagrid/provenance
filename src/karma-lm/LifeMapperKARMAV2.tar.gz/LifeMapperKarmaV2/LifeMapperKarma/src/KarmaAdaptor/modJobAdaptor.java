package KarmaAdaptor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.jdom2.Element;
import org.jdom2.Namespace;

import Util.ConfigManager;
import Util.mapping;
import Util.timeParser;

public class modJobAdaptor {

	/* KARMA Namespace */
	public Namespace ns = Namespace.getNamespace("ns",
			"http://www.dataandsearch.org/karma/2010/08/");
	public Namespace soapenv = Namespace.getNamespace("soapenv",
			"http://schemas.xmlsoap.org/soap/envelope/");

	/* Workflow General Information */
	private String _workflowID = null;
	private String _workflowNodeID = ConfigManager
			.getProperty("workflowNodeID");
	private String _userDN = ConfigManager.getProperty("userDN");
	private String _usertype = ConfigManager.getProperty("type");
	private String _email = ConfigManager.getProperty("email");
	private String _workflowinvocationTime = null;
	private String _fileownerDN = ConfigManager.getProperty("file_ownerDN");
	private String _jobInfo = null;

	/* Input Log files and Notification output folder */
	private String parsedLogName = null;
	private String parsedemllog = null;
	private String notification_dir = null;

	/* LifeMapper General Information */
	private int timestep = 1;
	private Element LMwebserviceInformation;
	private String _LMserviceNodeID = ConfigManager
			.getProperty("LifeMapper_WebService_URI");

	/* Global Variables */
	private Map<String, Element> scenario_list = new HashMap<String, Element>();

	/* Logging Mechanism */
	static final Logger logger = Logger.getLogger("KarmaAdaptor.modJobAdaptor");

	public modJobAdaptor(String job_folder, String job_ID, String job_info) {
		parsedLogName = job_folder + "/Log/parsed_appLog.txt";
		parsedemllog = job_folder + "/Log/eml_log.txt";
		_workflowID = mapping.exp_id2url(job_ID);
		_jobInfo = job_info;

		notification_dir = job_folder + "/notifications/";
		File _notification_dir = new File(notification_dir);
		if (!_notification_dir.exists()) {
			_notification_dir.mkdir();
		} else {
			String[] _deleteFiles = _notification_dir.list();
			for (int i = 0; i < _deleteFiles.length; i++) {
				File _deleteFile = new File(_notification_dir, _deleteFiles[i]);
				_deleteFile.delete();
			}
		}
		logger.info("Creating notification folder...");
		logger.info("Creating tmp parsing file:" + parsedLogName);
		logger.info("Creating tmp parsing file:" + parsedemllog);
		logger.info("Assign Workflow ID:" + _workflowID);
	}

	public void workflowInvoked() {

		FileInputStream parsed_eml_log = null;
		try {
			parsed_eml_log = new FileInputStream(new File(parsedemllog));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			logger.warn(e1.toString());
		}
		BufferedReader eml_reader = new BufferedReader(new InputStreamReader(
				parsed_eml_log));

		String line;
		String[] tokens;
		String species_name = "";

		tokens = _jobInfo.split(";");
		_workflowinvocationTime = tokens[0];
		try {
			line = eml_reader.readLine();
			while (line != null) {
				if (line.startsWith("species name")) {
					tokens = line.split(":");
					species_name = tokens[1];
				}
				line = eml_reader.readLine();
			}

		} catch (Exception e) {
			// TODO: handle exception
			logger.warn(e.toString());
		}

		Element userInformation = KarmaElement.userInformation(_userDN,
				_usertype, _email);
		ArrayList<Element> wf_annotations = new LMAnnotations()
				.modworkflowAnnotations(species_name);
		Element workflowInformation = KarmaElement.workflowInformation(
				_workflowID, _workflowNodeID, timestep, wf_annotations);
		KarmaNotification.workflowInvoked(userInformation, "USER",
				workflowInformation, "WORKFLOW", _workflowinvocationTime,
				notification_dir + "workflowInvoked.xml");
		logger.info("LifeMapper WorkflowInvoked Notification Created and Saved!");
		timestep++;

		Element submitInformation = KarmaElement.serviceInformation(
				_workflowID, _workflowNodeID, timestep,
				"Submit Experiment Input");
		KarmaNotification.serviceInvoked(workflowInformation, "WORKFLOW",
				submitInformation, "SERVICE", _workflowinvocationTime,
				notification_dir + "submitInvoked.xml");
		timestep++;
	}

	public Element SubmitPhase() {
		Element submitInformation = KarmaElement.serviceInformation(
				_workflowID, _workflowNodeID, timestep - 1,
				"Submit Experiment Input");

		ArrayList<Element> LMWS_annotations = new LMAnnotations()
				.LMwebserviceAnnotations(_LMserviceNodeID);
		LMwebserviceInformation = KarmaElement.serviceInformation(_workflowID,
				_LMserviceNodeID, timestep, "LifeMapper Web Service",
				LMWS_annotations);

		FileInputStream parsed_eml_log = null;
		try {
			parsed_eml_log = new FileInputStream(new File(parsedemllog));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			logger.warn(e1.toString());
		}
		BufferedReader eml_reader = new BufferedReader(new InputStreamReader(
				parsed_eml_log));

		ArrayList<String> occurrence_quality = new ArrayList<String>();

		FileInputStream parsed_om_log = null;
		try {
			parsed_om_log = new FileInputStream(new File(parsedLogName));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			logger.warn(e1.toString());
		}
		BufferedReader om_reader = new BufferedReader(new InputStreamReader(
				parsed_om_log));
		try {
			String line = om_reader.readLine();
			while (line != null) {
				if (line.startsWith("[Warn]"))
					occurrence_quality.add(line);
				line = om_reader.readLine();
			}
		} catch (IOException e3) {
			// TODO Auto-generated catch block
			logger.warn(e3.toString());
		}

		String occurrenceID = "";
		try {
			String occurrence_line;
			String[] occurrence_tokens;

			occurrence_line = eml_reader.readLine();
			if (occurrence_line.startsWith("occurrence id")) {
				occurrence_tokens = occurrence_line.split(":");
				occurrenceID = occurrence_tokens[1];
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			logger.warn(e1.toString());
		}

		String line = null;
		Element occurrence_object = null;
		int count = 1;
		try {
			String[] tokens = null;
			String consumeTimestamp = _workflowinvocationTime;
			String produceTimestamp = _workflowinvocationTime;

			Element occurrence_file = KarmaElement.File(
					mapping.occ_id2url(occurrenceID), "0", consumeTimestamp,
					"Occurrence Set " + occurrenceID, _fileownerDN);
			ArrayList<Element> occurrence_anno = new LMAnnotations()
					.occuAnnotations(occurrence_quality);
			occurrence_object = KarmaElement.dataObject(occurrence_file,
					occurrence_anno);

			KarmaNotification.dataRelation("PRODUCE", submitInformation,
					"SERVICE", occurrence_object, produceTimestamp,
					"File Produced", notification_dir
							+ "occurrenceProduced.xml");

			KarmaNotification.dataRelation("CONSUME", LMwebserviceInformation,
					"SERVICE", occurrence_object, consumeTimestamp,
					"File Consumed", notification_dir
							+ "occurrenceReceived.xml");

			logger.info("Submitted Occurrence Data Set URL:"
					+ mapping.occ_id2url(occurrenceID));

			line = eml_reader.readLine();
			while (line != null) {
				if (line.startsWith("scenario")) {
					tokens = line.split(";");
					String scenario_line = tokens[0];
					String[] scenario_tokens = scenario_line.split("!");

					String scenarioID = scenario_tokens[0];
					String scenario_code = scenario_tokens[1];
					String scenario_metadata = scenario_tokens[2];

					Element scenario_file = KarmaElement.File(
							scenario_metadata, "0", consumeTimestamp,
							scenarioID, _fileownerDN);
					ArrayList<Element> scenario_annotations = new LMAnnotations()
							.scenarioAnnotations(scenario_code,
									scenario_metadata);
					Element scenario_object = KarmaElement.dataObject(
							scenario_file, scenario_annotations);

					KarmaNotification.dataRelation("PRODUCE",
							submitInformation, "SERVICE", scenario_object,
							produceTimestamp, "File Produced", notification_dir
									+ "scenarioProduced" + count + ".xml");

					KarmaNotification.dataRelation("CONSUME",
							LMwebserviceInformation, "SERVICE",
							scenario_object, consumeTimestamp, "File Consumed",
							notification_dir + "scenarioReceived" + count
									+ ".xml");

					logger.info("Submitted Scenario URL:" + scenario_metadata);

					count++;
					scenario_list.put(scenarioID, scenario_object);
				}

				line = eml_reader.readLine();
			}
			logger.info("LifeMapper Submit Experiment Input Phase Notification Created and Saved!");
		} catch (Exception e) {
			logger.info(e.toString());
			// TODO: handle exception
		} finally {
			try {
				eml_reader.close();
			} catch (IOException ex) {
				// TODO Auto-generated catch block
				logger.info(ex.toString());
			}
		}

		timestep++;
		return occurrence_object;
	}

	public Element loadLibPhase(Element occurrence_object) {
		String line;
		String[] tokens;
		Element model_object = null;

		String consumeTimestamp = _workflowinvocationTime;
		String produceTimestamp = _workflowinvocationTime;

		FileInputStream parsed_om_log = null;
		try {
			parsed_om_log = new FileInputStream(new File(parsedLogName));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		BufferedReader om_reader = new BufferedReader(new InputStreamReader(
				parsed_om_log));

		try {
			line = om_reader.readLine();
			ArrayList<String> model_annotations = new ArrayList<String>();
			ArrayList<String> lib_list = new ArrayList<String>();

			while (line != null) {
				if (line.contains("Loading")) {
					tokens = line.split(":");
					String[] lib_tokens = tokens[1].trim().split(" ");
					String lib_name = lib_tokens[0];
					lib_list.add(lib_name);
				}

				if (line.startsWith("Creating Model")) {
					while (!line.startsWith("Finished creating model")) {
						if (!line.startsWith("[Warn]"))
							model_annotations.add(line);
						line = om_reader.readLine();
					}
				}
				line = om_reader.readLine();
			}

			tokens = _jobInfo.split(";");
			model_annotations.add("Job Starting Timestamp:" + tokens[0]);
			model_annotations.add("Job ID:" + tokens[1]);
			model_annotations.add("Process ID:" + tokens[2]);
			model_annotations.add("Job Ending Timestamp:" + tokens[3]);

			ArrayList<Element> modelAnnotations = new LMAnnotations()
					.modelAnnotations(model_annotations);
			Element createmodelInformation = KarmaElement.serviceInformation(
					_workflowID, _workflowNodeID, timestep, "Creat Model",
					modelAnnotations);

			int count = 1;
			for (String lib_name : lib_list) {

				String[] lib_tokens = lib_name.split("/");

				Element lib_file = KarmaElement.File(lib_name, "0",
						produceTimestamp, lib_tokens[lib_tokens.length - 1],
						_fileownerDN);
				Element lib_object = KarmaElement.dataObject(lib_file, null);

				KarmaNotification.dataRelation("PRODUCE",
						LMwebserviceInformation, "SERVICE", lib_object,
						produceTimestamp, "File Produced", notification_dir
								+ "libProduced" + count + ".xml");
				KarmaNotification.dataRelation("CONSUME",
						createmodelInformation, "SERVICE", lib_object,
						consumeTimestamp, "File Consumed", notification_dir
								+ "libConsumed" + count + ".xml");

				count++;
			}

			logger.info("LifeMapper Loading Job Lib Files Phase notifications created and saved!");

			KarmaNotification.dataRelation("CONSUME", createmodelInformation,
					"SERVICE", occurrence_object, produceTimestamp,
					"File Consumed", notification_dir
							+ "occurrenceConsumed.xml");

			Element model_file = KarmaElement.File(_workflowID + "/model", "0",
					produceTimestamp, _workflowID + "/model", _fileownerDN);
			model_object = KarmaElement.dataObject(model_file, null);

			KarmaNotification.dataRelation("PRODUCE", createmodelInformation,
					"SERVICE", model_object, produceTimestamp, "File Produced",
					notification_dir + "modelProduced.xml");
			
			logger.info("Created Model URL:" + _workflowID + "/model");
			logger.info("LifeMapper Model Creating Phase notifications created and saved!");

			timestep++;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.warn(e.toString());
		} finally {
			try {
				om_reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				logger.warn(e.toString());
			}
		}

		return model_object;
	}

	public void projectionPhase(Element SDMInformation) {
		FileInputStream parsed_eml_log = null;
		try {
			parsed_eml_log = new FileInputStream(new File(parsedemllog));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			logger.warn(e1.toString());
		}
		BufferedReader eml_reader = new BufferedReader(new InputStreamReader(
				parsed_eml_log));

		String line = null;

		int count = 1;
		try {

			line = eml_reader.readLine();
			while (!line.startsWith("scenario")) {
				line = eml_reader.readLine();
			}

			String[] tokens = null;

			while (line != null && line.startsWith("scenario")) {
				tokens = line.split(";");

				String scenario_line = tokens[0];
				String[] scenario_tokens = scenario_line.split("!");

				Element scenario_object = scenario_list.get(scenario_tokens[0]);

				String consumeTimestamp = _workflowinvocationTime;
				String produceTimestamp = _workflowinvocationTime;

				Element projection_Information = KarmaElement
						.serviceInformation(_workflowID, _workflowNodeID,
								timestep, "Generate Projection");
				KarmaNotification.serviceInvoked(LMwebserviceInformation,
						"SERVICE", projection_Information, "SERVICE",
						consumeTimestamp, notification_dir + "projection"
								+ count + "Invoked.xml");

				KarmaNotification.dataRelation("CONSUME",
						projection_Information, "SERVICE", SDMInformation,
						consumeTimestamp, "File Consumed", notification_dir
								+ "SDMConsumed" + count + ".xml");
				KarmaNotification.dataRelation("CONSUME",
						projection_Information, "SERVICE", scenario_object,
						consumeTimestamp, "File Consumed", notification_dir
								+ "scenarioConsumed" + count + ".xml");

				String projection_line = tokens[1];
				String[] projection_tokens = projection_line.split("!");
				String projection_name = projection_tokens[1];
				String bounding_box = projection_tokens[2];
				String scenario_code = projection_tokens[3];
				String species_name = projection_tokens[4];
				String projection_metadata = projection_tokens[5];

				Element projection_file = KarmaElement.File(
						projection_metadata, "0", produceTimestamp,
						projection_name, _fileownerDN);
				ArrayList<Element> projection_anno = new LMAnnotations()
						.projectionAnnotations(projection_name, bounding_box,
								scenario_code, species_name,
								projection_metadata);
				Element projection_object = KarmaElement.dataObject(
						projection_file, projection_anno);

				KarmaNotification.dataRelation("PRODUCE",
						projection_Information, "SERVICE", projection_object,
						produceTimestamp, "File Produced", notification_dir
								+ "projectionProduced" + count + ".xml");

				logger.info("Projection created with Projection URL:"
						+ projection_metadata);

				count++;
				timestep++;
				line = eml_reader.readLine();
			}
			logger.info("LifeMapper Species Distribution Projection Phase Notification Created and Saved!");
		} catch (Exception e) {
			logger.warn(e.toString());
			// TODO: handle exception
		} finally {
			try {
				eml_reader.close();
			} catch (IOException ex) {
				// TODO Auto-generated catch block
				logger.warn(ex.toString());
			}
		}

	}
}