package KarmaAdaptor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.jdom2.Element;
import org.jdom2.Namespace;

import LogProcessor.experimentParser;
import Util.ConfigManager;
import Util.mapping;
import Util.timeParser;

public class projJobAdaptor {

	/* KARMA Namespace*/
	public Namespace ns = Namespace.getNamespace("ns",
			"http://www.dataandsearch.org/karma/2010/08/");
	public Namespace soapenv = Namespace.getNamespace("soapenv",
			"http://schemas.xmlsoap.org/soap/envelope/");

	/* Workflow General Information*/
	private String _workflowID = null;
	private String _workflowNodeID = ConfigManager.getProperty("workflowNodeID");
	private String _userDN = ConfigManager.getProperty("userDN");
	private String _usertype = ConfigManager.getProperty("type");
	private String _email = ConfigManager.getProperty("email");
	private String _workflowinvocationTime = null;
	private String _fileownerDN = ConfigManager.getProperty("file_ownerDN");
	private String _jobInfo =null;
	private String _projID=null;
	private String _jobFolder=null;
	
	/*Input Log files and Notification output folder*/
	private String parsedLogName = null;
	private String notification_dir =null;

	/*LifeMapper General Information*/
	private int timestep = 1;
	private Element workflowInformation;
	
	/* Logging Mechanism */
	static final Logger logger = Logger.getLogger("KarmaAdaptor.modJobAdaptor");
	
	public projJobAdaptor(String job_folder, String job_ID, String job_info, String proj_ID) {
		parsedLogName = job_folder+"/Log/parsed_appLog.txt";

		_workflowID=mapping.pro_id2url(proj_ID);
		_jobInfo=job_info;
		_projID=proj_ID;
		_jobFolder=job_folder;

		notification_dir=job_folder+"/notifications/";
		File _notification_dir = new File(notification_dir);
		if (!_notification_dir.exists()) {
			_notification_dir.mkdir();
		} else {
			String[] _deleteFiles = _notification_dir.list();
			for (int i = 0; i < _deleteFiles.length; i++) {
				File _deleteFile = new File(_notification_dir, _deleteFiles[i]);
				_deleteFile.delete();
			}
		}
		
		logger.info("Creating notification folder...");
		logger.info("Creating tmp parsing file:" + parsedLogName);
		logger.info("Assign Workflow ID:" + _workflowID);
	}

	public void workflowInvoked() {
		
		String[] tokens=_jobInfo.split(";");
		_workflowinvocationTime=tokens[0];
		
		Element userInformation = KarmaElement.userInformation(_userDN,
				_usertype, _email);
		
		workflowInformation = KarmaElement.workflowInformation(
				_workflowID, _workflowNodeID, timestep, null);
		KarmaNotification.workflowInvoked(userInformation, "USER",
				workflowInformation, "WORKFLOW", _workflowinvocationTime,
				notification_dir + "workflowInvoked.xml");
		logger.info("LifeMapper WorkflowInvoked Notification Created and Saved!");
		timestep++;
		
		/*Element submitInformation = KarmaElement.serviceInformation(
				_workflowID, _workflowNodeID, timestep,
				"Submit Experiment Input");
		KarmaNotification.serviceInvoked(workflowInformation, "WORKFLOW",
				submitInformation, "SERVICE", _workflowinvocationTime,
				notification_dir + "submitInvoked.xml");
		System.out
				.println("\n LifeMapper Submit Experiment Input ServiceInvoked Notification Created and Saved!"
						+ "\n");
		timestep++;*/
	}
	
	/*public Element SubmitPhase()
	{
		Element submitInformation = KarmaElement.serviceInformation(
				_workflowID, _workflowNodeID, timestep - 1,
				"Submit Experiment Input");

		ArrayList<Element> LMWS_annotations=new LMAnnotations().LMwebserviceAnnotations(_LMserviceNodeID);
		LMwebserviceInformation = KarmaElement.serviceInformation(
				_workflowID, _LMserviceNodeID, timestep,
				"LifeMapper Web Service",LMWS_annotations);
		
		FileInputStream parsed_eml_log = null;
		try {
			parsed_eml_log = new FileInputStream(new File(parsedemllog));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		BufferedReader eml_reader = new BufferedReader(new InputStreamReader(
				parsed_eml_log));
		
		
		String occurrenceID="";
		try {
			String occurrence_line;
			String[] occurrence_tokens;

			occurrence_line = eml_reader.readLine();
			if (occurrence_line.startsWith("occurrence id")) {
				occurrence_tokens = occurrence_line.split(":");
				occurrenceID = occurrence_tokens[1];
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		String line = null;
		Element occurrence_object=null;
		int count=1;
		try {
			String[] tokens = null;
			String consumeTimestamp = _workflowinvocationTime;
			String produceTimestamp = _workflowinvocationTime;
			
			Element occurrence_file = KarmaElement.File(mapping.occ_id2url(occurrenceID), 
					"0", consumeTimestamp, "Occurrence Set "+occurrenceID, _fileownerDN);
			occurrence_object = KarmaElement.dataObject(occurrence_file, null);
			
			KarmaNotification.dataRelation("PRODUCE",
					submitInformation, "SERVICE", occurrence_object,
					produceTimestamp, "File Produced",
					notification_dir + "occurrenceProduced.xml");

			KarmaNotification.dataRelation("CONSUME", LMwebserviceInformation,
					"SERVICE", occurrence_object, consumeTimestamp,
					"File Consumed", notification_dir + "occurrenceReceived.xml");
			
			line=eml_reader.readLine();
			while(line!=null)
			{
				if(line.startsWith("scenario"))
				{	
					tokens=line.split(";");
					String scenario_line=tokens[0];
					String[] scenario_tokens=scenario_line.split("!");
					
					String scenarioID=scenario_tokens[0];
					String scenario_code=scenario_tokens[1];
					String scenario_metadata=scenario_tokens[2];
					
					Element scenario_file = KarmaElement.File(scenario_metadata, "0", consumeTimestamp, 
							scenarioID, _fileownerDN);
					ArrayList<Element> scenario_annotations = new LMAnnotations().scenarioAnnotations(scenario_code, scenario_metadata);
					Element scenario_object = KarmaElement.dataObject(scenario_file,scenario_annotations);
					
					KarmaNotification.dataRelation("PRODUCE",
							submitInformation, "SERVICE", scenario_object,
							produceTimestamp, "File Produced",
							notification_dir + "scenarioProduced" + count + ".xml");
					
					KarmaNotification.dataRelation("CONSUME", LMwebserviceInformation,
							"SERVICE", scenario_object, consumeTimestamp,
							"File Consumed", notification_dir + "scenarioReceived"
									+ count + ".xml");
					count++;
					scenario_list.put(scenarioID, scenario_object);
				}
				
				line=eml_reader.readLine();
			}
			System.out.println("\nLifeMapper Submit Experiment Input Phase Notification Created and Saved!\n");
		} catch (Exception e) {
			System.out.print(e);
			// TODO: handle exception
		} finally {
			try {
				eml_reader.close();
			} catch (IOException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		
		timestep++;
		return occurrence_object;
	}
	*/
	public void projectionPhase()
	{
		String line;
		String[] tokens;
		
		String consumeTimestamp = _workflowinvocationTime;
		String produceTimestamp = _workflowinvocationTime;
		
		FileInputStream parsed_om_log = null;
		try {
			parsed_om_log = new FileInputStream(new File(parsedLogName));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			logger.warn(e1.toString());
		}
		BufferedReader om_reader = new BufferedReader(
				new InputStreamReader(parsed_om_log));

		try {
			line = om_reader.readLine();
			ArrayList<String> proj_annotations=new ArrayList<String>();
			ArrayList<String> lib_list=new ArrayList<String>();
			
 			while (line != null) {
				if(line.contains("Loading"))
				{
					tokens=line.split(":");
					String[] lib_tokens=tokens[1].trim().split(" ");
					String lib_name=lib_tokens[0];
					lib_list.add(lib_name);
				}
				
				if(line.startsWith("Creating Model"))
				{
					while(!line.startsWith("Finished projecting model"))
					{
						proj_annotations.add(line);
						line=om_reader.readLine();
					}
				}
				line=om_reader.readLine();
			}
			
 			tokens=_jobInfo.split(";");
 			proj_annotations.add("Job Starting Timestamp:"+tokens[0]);
 			proj_annotations.add("Job ID:"+tokens[1]);
 			proj_annotations.add("Process ID:"+tokens[2]);
 			proj_annotations.add("Job Ending Timestamp:"+tokens[3]);
 			
			ArrayList<Element> projAnnotations=new LMAnnotations().projAnnotations(proj_annotations);
			Element projectionInformation = KarmaElement.serviceInformation(
					_workflowID, _workflowNodeID, timestep,
					"Projecting Model", projAnnotations);
			
			int count=1;
			for(String lib_name: lib_list)
			{
				
				String[] lib_tokens=lib_name.split("/");

				Element lib_file = KarmaElement.File(lib_name, "0", produceTimestamp, 
						lib_tokens[lib_tokens.length-1], _fileownerDN);
				Element lib_object = KarmaElement.dataObject(lib_file,null);
				
				KarmaNotification.dataRelation("PRODUCE", workflowInformation,
						"SERVICE", lib_object, produceTimestamp,
						"File Produced", notification_dir + "libProduced"
								+ count + ".xml");
				KarmaNotification.dataRelation("CONSUME", projectionInformation,
						"SERVICE", lib_object, consumeTimestamp,
						"File Consumed", notification_dir + "libConsumed"
								+ count + ".xml");
				count++;
			}
			
			logger.info("LifeMapper Loading Job Lib Files Phase notifications created and saved!");
			
			String projection_info=experimentParser.projParse(_projID, _jobFolder+"/Log/");
			tokens=projection_info.split("!");
			String projection_name=tokens[0];
			String bounding_box=tokens[1];
			String scenario_code=tokens[2];
			String species_name=tokens[3];
			String projection_metadata=tokens[4];
			
			Element projection_file = KarmaElement.File(projection_metadata, "0", produceTimestamp, 
					projection_name, _fileownerDN);
			ArrayList<Element> projection_anno= new LMAnnotations().projectionAnnotations(projection_name, 
														bounding_box, scenario_code, species_name, projection_metadata);
			Element projection_object = KarmaElement.dataObject(projection_file,projection_anno);
	
			KarmaNotification.dataRelation("PRODUCE", projectionInformation,
					"SERVICE", projection_object, produceTimestamp,
					"File Produced", notification_dir + "projectionProduced"
							+ count + ".xml");
			
			logger.info("Projection Name:"+projection_name);
			logger.info("Bounding Box:"+bounding_box);
			logger.info("Scenario Code:"+scenario_code);
			logger.info("Species Name:"+species_name);
			logger.info("Projection URL:"+projection_metadata);
			logger.info("LifeMapper Projection Creating Phase notifications created and saved!");
			
			timestep++;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.warn(e.toString());
		} finally {
			try {
				om_reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				logger.warn(e.toString());
			}
		}
	}
}