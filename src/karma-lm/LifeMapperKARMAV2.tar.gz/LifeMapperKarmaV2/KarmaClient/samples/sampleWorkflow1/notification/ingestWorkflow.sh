#!/bin/sh
KarmaMessagingClient=/Users/yuanluo/WorkZone/workspace/Karma-Messaging-Client-Core
/bin/echo $KarmaMessagingClient
cd $KarmaMessagingClient
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/workflowInvoked.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/serviceInvoked1.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/serviceInvoked2.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/dataProduced1.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/dataConsumed1.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/dataConsumed2.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/serviceInvoked3.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/dataProduced2.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/dataConsumed3.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/serviceInvoked4.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/serviceInvoked5.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/serviceInvoked6.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/serviceInvoked7.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/serviceInvoked6.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/serviceInvoked7.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/serviceInvoked8.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/serviceInvoked9.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/dataProduced3.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/dataConsumed4.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/dataProduced4.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/dataConsumed5.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/dataProduced5.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/dataConsumed6.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/dataProduced6.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/dataConsumed7.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/dataProduced7.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/linkEntity0.xml
bin/sendNotification.sh config/karma.properties  samples/sampleWorkflow1/notification/linkEntity1.xml

