This directory contains scripts for running Cytoscape from the command line prompt.

These scripts are bundled with the official Cytoscape release.

cytoscape.sh:  Used for running Cytoscape from Unix, Linux and Mac OS X.
cytoscape.bat  Used for running Cytoscape from Window.

Updated by:  Ethan Cerami
