#!/bin/sh
# Generates the Cytoscape.vmoptions file

script_path="$(dirname -- $0)"

#vm_options_path="$HOME/.cytoscape"
vm_options_path=$script_path

if [ ! -e $vm_options_path ]; then
    /bin/mkdir $vm_options_path
fi

# Determine amount of physical memory present:
if [ `uname` = "Darwin" ]; then
    phys_mem=`sysctl -a | grep 'hw.memsize =' | sed 's/[ ][ ][ ]*/ /g' | cut -f 3 -d ' '`
    phys_mem=$((phys_mem / 1024 / 1024)) # Convert from B to MiB
else # We assume Linux
    phys_mem=`cat /proc/meminfo | grep 'MemTotal:' | sed 's/[ ][ ][ ]*/ /g' | cut -f 2 -d ' '`
    phys_mem=$((phys_mem / 1024)) # Convert from KiB to MiB
fi

if `java -version 2>&1 | grep -- 64-Bit > /dev/null`; then # We have a 64 bit JVM.
    echo -Xms20m          >  "$vm_options_path/Cytoscape.vmoptions"
    echo -Xmx${phys_mem}m >> "$vm_options_path/Cytoscape.vmoptions"
    echo -d64             >> "$vm_options_path/Cytoscape.vmoptions"
else # Assume a 32 bit JVM.
    # Truncate memory setting at 1550 MiB:
    if [ $phys_mem -gt 1550 ]; then
	phys_mem=1550
    fi

    echo -Xms10m          >  "$vm_options_path/Cytoscape.vmoptions"
    echo -Xmx${phys_mem}m >> "$vm_options_path/Cytoscape.vmoptions"
fi

# Shared JVM options
echo -Dswing.aatext=true               >> "$vm_options_path/Cytoscape.vmoptions"
echo -Dawt.useSystemAAFontSettings=lcd >> "$vm_options_path/Cytoscape.vmoptions"

exit 0
