/*
#
# Copyright 2007 The Trustees of Indiana University
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or areed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# -----------------------------------------------------------------
#
# Project: Karma-Service-core
# File:  AnnotationFactory.java
# Description:  Factory for annotation
#
# -----------------------------------------------------------------
# 
*/



/**
 * 
 */
package edu.indiana.dsi.karma.ingest.db;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import org.apache.xmlbeans.XmlOptions;
import org.dataandsearch.www.karma._2010._08.AnnotationType;
import org.dataandsearch.www.karma._2010._08.LinkEntityType;
import org.dataandsearch.www.karma._2010._08.LinkedType;

import edu.indiana.dsi.karma.ingest.Annotation;
import edu.indiana.dsi.karma.ingest.EntityObject;
import edu.indiana.dsi.karma.ingest.Annotation.AnnotationDefinitionScopeEnum;
import edu.indiana.dsi.karma.ingest.LinkEntity;

/**
 * @author Yiming Sun
 * @author Devarshi Ghoshal
 *
 */
public class LinkEntityFactory {

    public static class LinkEntityImpl implements LinkEntity {

        private final EntityObject endPoint;
        private final Calendar linkTime;
        private final List<Annotation> annotationList;
        
        LinkEntityImpl(EntityObject endPoint, Calendar linkTime, List<Annotation> annotationList) {
            this.endPoint = endPoint;
            this.linkTime = linkTime;
            this.annotationList = annotationList;
        }
        
        public EntityObject getEndPoint(){
        	return endPoint;
        }
        public Calendar getLinkTime(){
        	return linkTime;
        }
        public List<Annotation> getAnnotationList(){
        	return annotationList;
        }
        
    }

    public static LinkEntity createLinkEntity(EntityObject endPoint, Calendar linkTime, List<Annotation> annotationList) {
    	LinkEntity linkEntity = new LinkEntityImpl(endPoint, linkTime, annotationList);
        return linkEntity;
    }
    
    /**
     * Convert an array of AnnotationType XmlBeans objects to a List of Annotation objects
     * @param annotationsArray array of AnnotationType objects
     * @return List of Annotation objects
     * 
     * @author Yiming Sun
     */
    public static List<LinkEntity> convert(LinkedType[] endPointArray) {
        List<LinkEntity> endPointList = null;
        if (endPointArray != null && endPointArray.length > 0) {
        	endPointList = new ArrayList<LinkEntity>();
            for (LinkedType linkEntityType : endPointArray) {
            	endPointList.add(convert(linkEntityType));
            }
        }
        return endPointList;
    }

    public static LinkEntity convert(LinkedType linkEntityType) {
    	LinkEntity linkEntity = null;
        if (linkEntityType != null) {
            EntityObject endPoint = EntityFactory.convertFromXmlBeansEntityType(linkEntityType.getLinkedEntity());
            Calendar linkTime = linkEntityType.getLinkTime();
            List<Annotation> annotationList = AnnotationFactory.convert(linkEntityType.getAnnotationsArray());
            linkEntity = new LinkEntityImpl(endPoint, linkTime, annotationList);
        }
        return linkEntity;
    }


}

