package edu.indiana.dsi.karma.query;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.dataandsearch.www.karma.query._2010._10.DetailEnumType;
import org.openprovenance.model.v1_1_a.Agent;
import org.openprovenance.model.v1_1_a.AgentRef;
import org.openprovenance.model.v1_1_a.Agents;
import org.openprovenance.model.v1_1_a.Artifact;
import org.openprovenance.model.v1_1_a.ArtifactRef;
import org.openprovenance.model.v1_1_a.Artifacts;
import org.openprovenance.model.v1_1_a.CausalDependencies;
import org.openprovenance.model.v1_1_a.EmbeddedAnnotation;
import org.openprovenance.model.v1_1_a.OPMGraph;
import org.openprovenance.model.v1_1_a.OTime;
import org.openprovenance.model.v1_1_a.OpmGraphDocument;
import org.openprovenance.model.v1_1_a.Process;
import org.openprovenance.model.v1_1_a.ProcessRef;
import org.openprovenance.model.v1_1_a.Processes;
import org.openprovenance.model.v1_1_a.Property;
import org.openprovenance.model.v1_1_a.Role;
import org.openprovenance.model.v1_1_a.Used;
import org.openprovenance.model.v1_1_a.WasControlledBy;
import org.openprovenance.model.v1_1_a.WasDerivedFrom;
import org.openprovenance.model.v1_1_a.WasGeneratedBy;
import org.openprovenance.model.v1_1_a.WasTriggeredBy;

import edu.indiana.dsi.karma.ingest.DataObject;
import edu.indiana.dsi.karma.ingest.EntityObject.EntityCategoryEnum;
import edu.indiana.dsi.karma.query.common.Common;

/*
 * @author You-Wei Cheah 
 */

public class QueryDataForwardFlowUtil {

	public static final Log l = LogFactory
			.getLog(QueryDataForwardFlowUtil.class);

	// for use with cache table
	private static final String NEW_CACHE_GRAPH = "INSERT INTO cache_data_usage_graph (data_product_id, graph_content, generation_time, query_date, time_range, detailed) VALUES (?, ?, ?, ?, ?, ?)";
	private static final String UPDATE_CACHE_GRAPH = "UPDATE cache_data_usage_graph SET graph_content = ? , dirty = ? , generation_time = ? , query_date = ? WHERE graph_id = ?";
	private static final String GET_CACHE_DATA_USAGE_GRAPH = "SELECT * FROM cache_data_usage_graph WHERE data_product_id = ? and time_range = ? and detailed = ?";
	private static final String GET_CACHE_COUNT = "SELECT count(*) FROM cache_data_usage_graph";
	private static final String UPDATE_QUERY_DATE = "UPDATE cache_data_usage_graph SET query_date = ? WHERE graph_id = ?";
	private static final String GET_GRAPH_TO_DELETE = "(SELECT * FROM cache_data_usage_graph ORDER BY query_date ASC) ORDER BY generation_time ASC limit 1";
	private static final int MAX_CACHE_ENTRIES = 10000;

	/* Hash maps to store visited nodes and edges */
	HashMap<String, String> visitedArtifacts = null;
	HashMap<String, String> visitedProcesses = null;
	HashMap<String, String> visitedUsed = null;
	HashMap<String, String> visitedWasGeneratedBy = null;
	HashMap<String, String> visitedWasDerivedFrom = null;
	HashMap<String, String> visitedWasTriggeredBy = null;
	HashMap<String, String> visitedRegEntity = null;

	private void setOPMUsed(Used u, Used newUsed) {

		newUsed.setAnnotationArray(u.getAnnotationArray());
		newUsed.setCause(u.getCause());
		newUsed.setEffect(u.getEffect());
		newUsed.setRole(u.getRole());
		newUsed.setTime(u.getTime());
	}

	private void setOPMWasTriggeredBy(WasTriggeredBy w,
			WasTriggeredBy newWasTriggeredBy) {

		newWasTriggeredBy.setTime(w.getTime());
		newWasTriggeredBy.setEffect(w.getEffect());
		newWasTriggeredBy.setCause(w.getCause());
		newWasTriggeredBy.setAnnotationArray(w.getAnnotationArray());
	}

	private void setOPMWasDerivedFrom(WasDerivedFrom w,
			WasDerivedFrom newWasDerivedFrom) {

		newWasDerivedFrom.setTime(w.getTime());
		newWasDerivedFrom.setEffect(w.getEffect());
		newWasDerivedFrom.setCause(w.getCause());
		newWasDerivedFrom.setAnnotationArray(w.getAnnotationArray());
	}

	private void setOPMWasGeneratedBy(WasGeneratedBy w,
			WasGeneratedBy newWasGeneratedBy) {

		newWasGeneratedBy.setTime(w.getTime());
		newWasGeneratedBy.setEffect(w.getEffect());
		newWasGeneratedBy.setCause(w.getCause());
		newWasGeneratedBy.setAnnotationArray(w.getAnnotationArray());
		newWasGeneratedBy.setRole(w.getRole());
	}

	private void setOPMProcess(Process p, Process newProcess) {
		if (p.getAnnotationArray() != null)
			newProcess.setAnnotationArray(p.getAnnotationArray());
		if (p.getId() != null)
			newProcess.setId(p.getId());
	}

	private void setOPMArtifact(Artifact a, Artifact newArtifact) {
		if (a.getAnnotationArray() != null)
			newArtifact.setAnnotationArray(a.getAnnotationArray());
		if (a.getId() != null)
			newArtifact.setId(a.getId());
	}

	private void setOPMAgent(Agent a, Agent newAgent) {
		if (a.getAnnotationArray() != null)
			newAgent.setAnnotationArray(a.getAnnotationArray());
		if (a.getId() != null)
			newAgent.setId(a.getId());
	}

	private void copyToNewGraph(OpmGraphDocument oGraph, OpmGraphDocument nGraph) {
		OPMGraph opmGraph = nGraph.getOpmGraph();
		Artifacts processGraphArtifacts = opmGraph.getArtifacts();
		Processes processGraphProcesses = opmGraph.getProcesses();
		Agents processGraphAgents = opmGraph.getAgents();
		CausalDependencies processCausalDependencies = opmGraph
				.getCausalDependencies();
		OPMGraph graph = oGraph.getOpmGraph();

		if (graph.getArtifacts() != null) {
			if (processGraphArtifacts == null)
				processGraphArtifacts = opmGraph.addNewArtifacts();
			for (Artifact a : graph.getArtifacts().getArtifactArray()) {
				Artifact newArtifact = processGraphArtifacts.addNewArtifact();
				setOPMArtifact(a, newArtifact);
			}
		}

		if (graph.getProcesses() != null) {
			if (processGraphProcesses == null)
				processGraphProcesses = opmGraph.addNewProcesses();
			for (Process p : graph.getProcesses().getProcessArray()) {

				Process newProcess = processGraphProcesses.addNewProcess();
				setOPMProcess(p, newProcess);
			}
		}

		if (graph.getAgents() != null) {
			if (processGraphAgents == null)
				processGraphAgents = opmGraph.addNewAgents();
			for (Agent a : graph.getAgents().getAgentArray()) {

				Agent newAgent = processGraphAgents.addNewAgent();
				setOPMAgent(a, newAgent);
			}
		}

		if (graph.getCausalDependencies() != null) {
			if (processCausalDependencies == null)
				processCausalDependencies = opmGraph.addNewCausalDependencies();

			if (graph.getCausalDependencies().getUsedArray() != null) {

				for (Used u : graph.getCausalDependencies().getUsedArray()) {
					Used newUsed = processCausalDependencies.addNewUsed();
					setOPMUsed(u, newUsed);
				}
			}

			if (graph.getCausalDependencies().getWasTriggeredByArray() != null) {

				for (WasTriggeredBy w : graph.getCausalDependencies()
						.getWasTriggeredByArray()) {
					WasTriggeredBy newWasTriggeredBy = processCausalDependencies
							.addNewWasTriggeredBy();
					setOPMWasTriggeredBy(w, newWasTriggeredBy);
				}
			}

			if (graph.getCausalDependencies().getWasGeneratedByArray() != null) {

				for (WasGeneratedBy w : graph.getCausalDependencies()
						.getWasGeneratedByArray()) {
					WasGeneratedBy newWasGeneratedBy = processCausalDependencies
							.addNewWasGeneratedBy();
					setOPMWasGeneratedBy(w, newWasGeneratedBy);
				}
			}

			if (graph.getCausalDependencies().getWasDerivedFromArray() != null) {

				for (WasDerivedFrom w : graph.getCausalDependencies()
						.getWasDerivedFromArray()) {
					WasDerivedFrom newWasDerivedFrom = processCausalDependencies
							.addNewWasDerivedFrom();
					setOPMWasDerivedFrom(w, newWasDerivedFrom);
				}
			}
		}
	}

	public List<WasDerivedFrom> getOPMWasDerivedFrom(Connection connection,
			String dataObjectID, String provenanceHistoryDataObjectID,
			DetailEnumType.Enum informationDetailLevel) throws SQLException {
		assert (connection != null);
		assert (dataObjectID != null);
		assert (provenanceHistoryDataObjectID != null);
		l.info("Entering getOPMWasDerivedFrom()");

		PreparedStatement wasDerivedFromStmt = null;
		ResultSet res = null;
		try {
			wasDerivedFromStmt = connection
					.prepareStatement(OPMSqlQuery.GET_OPM_REVERSED_DATA_WAS_DERIVED_FROM);
			wasDerivedFromStmt.setString(
					1,
					dataObjectID.replace(Common.FILE_IDENTIFIER, "")
							.replace(Common.BLOCK_IDENTIFIER, "")
							.replace(Common.COLLECTION_IDENTIFIER, ""));
			res = wasDerivedFromStmt.executeQuery();

			List<WasDerivedFrom> wasDerivedFromList = new ArrayList<WasDerivedFrom>();

			while (res.next()) {
				String effectId = Common.getArtifactId(connection,
						res.getInt(1));
				java.sql.Timestamp noLaterThan = res.getTimestamp(2);
				String causeId = Common
						.getArtifactId(connection, res.getInt(3));
				java.sql.Timestamp noEarlierThan = res.getTimestamp(4);

				WasDerivedFrom wasDerivedFrom = WasDerivedFrom.Factory
						.newInstance();
				wasDerivedFrom.addNewEffect().setRef(effectId);
				wasDerivedFrom.addNewCause().setRef(causeId);

				OTime time = wasDerivedFrom.addNewTime();
				time.setNoEarlierThan(Common
						.getCalendarFromTimeStamp(noEarlierThan));
				time.setNoLaterThan(Common
						.getCalendarFromTimeStamp(noLaterThan));

				if (informationDetailLevel != null
						&& informationDetailLevel != null
						&& informationDetailLevel.equals(DetailEnumType.FINE)) {
					EmbeddedAnnotation effectDataLifecycleAnnotation = getDataLifecycleAnnotation(
							connection, res.getString("consumed_event_id"));
					EmbeddedAnnotation causeDataLifecycleAnnotation = getDataLifecycleAnnotation(
							connection, res.getString("produced_event_id"));
					if (effectDataLifecycleAnnotation != null) {
						wasDerivedFrom.addNewAnnotation();
						int i = wasDerivedFrom.getAnnotationArray().length - 1;
						wasDerivedFrom.setAnnotationArray(i,
								effectDataLifecycleAnnotation);

					}

					if (causeDataLifecycleAnnotation != null) {
						wasDerivedFrom.addNewAnnotation();
						int i = wasDerivedFrom.getAnnotationArray().length - 1;
						wasDerivedFrom.setAnnotationArray(i,
								causeDataLifecycleAnnotation);
					}
				}

				wasDerivedFromList.add(wasDerivedFrom);
			}

			l.info("Exiting getOPMWasDerivedFrom() with success");
			res.close();
			wasDerivedFromStmt.close();

			return wasDerivedFromList;
		} catch (SQLException e) {
			l.error("Exiting getOPMWasDerivedFrom() with errors");
			l.error(e.toString());
			return null;
		} finally {

			if (wasDerivedFromStmt != null) {
				wasDerivedFromStmt.close();
				wasDerivedFromStmt = null;
			}

			if (res != null) {
				res.close();
				res = null;
			}
		}
	}

	public List<WasTriggeredBy> getOPMWasTriggeredBy(Connection connection,
			String processID, String provenanceHistoryDataObjectID,
			DetailEnumType.Enum informationDetailLevel) throws SQLException {
		assert (connection != null);
		assert (processID != null);
		assert (provenanceHistoryDataObjectID != null);
		l.info("Entering getOPMWasTriggeredBy()");

		PreparedStatement wasTriggeredByStmt = null;
		ResultSet res = null;

		try {
			processID = processID.replace(Common.PROCESS_IDENTIFIER, "");
			List<WasTriggeredBy> wasTriggeredByList = new ArrayList<WasTriggeredBy>();

			wasTriggeredByStmt = connection
					.prepareStatement(OPMSqlQuery.GET_OPM_REVERSED_DATA_WAS_TRIGGERED_BY_WITH_ARTIFACTS);

			wasTriggeredByStmt.setString(1, processID);

			res = wasTriggeredByStmt.executeQuery();

			while (res.next()) {
				String effectId = Common.PROCESS_IDENTIFIER
						+ res.getInt("effect");
				String causeId = Common.PROCESS_IDENTIFIER
						+ res.getInt("cause");

				java.sql.Timestamp noEarlierThan = res
						.getTimestamp("noEarlierThan");
				java.sql.Timestamp noLaterThan = res
						.getTimestamp("noLaterThan");

				WasTriggeredBy wasTriggeredBy = WasTriggeredBy.Factory
						.newInstance();
				ProcessRef effect = wasTriggeredBy.addNewEffect();
				effect.setRef(effectId);
				ProcessRef cause = wasTriggeredBy.addNewCause();
				cause.setRef(causeId);
				OTime time = wasTriggeredBy.addNewTime();
				time.setNoEarlierThan(Common
						.getCalendarFromTimeStamp(noEarlierThan));
				time.setNoLaterThan(Common
						.getCalendarFromTimeStamp(noLaterThan));

				if (informationDetailLevel != null
						&& informationDetailLevel != null
						&& informationDetailLevel.equals(DetailEnumType.FINE)) {
					EmbeddedAnnotation consumedDataLifecycleAnnotation = getDataLifecycleAnnotation(
							connection, res.getString("consumed_event_id"));
					EmbeddedAnnotation producedDataLifecycleAnnotation = getDataLifecycleAnnotation(
							connection, res.getString("produced_event_id"));
					if (consumedDataLifecycleAnnotation != null) {
						wasTriggeredBy.addNewAnnotation();
						int i = wasTriggeredBy.getAnnotationArray().length - 1;
						wasTriggeredBy.setAnnotationArray(i,
								consumedDataLifecycleAnnotation);

					}

					if (producedDataLifecycleAnnotation != null) {
						wasTriggeredBy.addNewAnnotation();
						int i = wasTriggeredBy.getAnnotationArray().length - 1;
						wasTriggeredBy.setAnnotationArray(i,
								producedDataLifecycleAnnotation);
					}
				}

				wasTriggeredByList.add(wasTriggeredBy);

			}

			if (res != null) {
				res.close();
				res = null;
			}

			if (wasTriggeredByStmt != null) {
				wasTriggeredByStmt.close();
				wasTriggeredByStmt = null;
			}

			wasTriggeredByStmt = connection
					.prepareStatement(OPMSqlQuery.GET_OPM_REVERSED_DATA_WAS_TRIGGERED_BY_WITHOUT_ARTIFACTS);

			wasTriggeredByStmt.setString(1, processID);
			res = wasTriggeredByStmt.executeQuery();

			while (res.next()) {
				String effectId = Common.PROCESS_IDENTIFIER
						+ res.getInt("effect");
				String causeId = Common.PROCESS_IDENTIFIER
						+ res.getInt("cause");
				String invocationId = res.getString("invocation_id");
				java.sql.Timestamp noEarlierThan = res
						.getTimestamp("noEarlierThan");
				java.sql.Timestamp noLaterThan = res
						.getTimestamp("noLaterThan");

				WasTriggeredBy wasTriggeredBy = WasTriggeredBy.Factory
						.newInstance();
				ProcessRef effect = wasTriggeredBy.addNewEffect();
				effect.setRef(effectId);
				ProcessRef cause = wasTriggeredBy.addNewCause();
				cause.setRef(causeId);
				OTime time = wasTriggeredBy.addNewTime();
				time.setNoEarlierThan(Common
						.getCalendarFromTimeStamp(noEarlierThan));
				time.setNoLaterThan(Common
						.getCalendarFromTimeStamp(noLaterThan));

				if (informationDetailLevel != null
						&& informationDetailLevel.equals(DetailEnumType.FINE)) {
					EmbeddedAnnotation invocationAnnotation = getInvocationAnnotation(
							connection, provenanceHistoryDataObjectID,
							invocationId);
					if (invocationAnnotation != null) {
						wasTriggeredBy.addNewAnnotation();
						wasTriggeredBy.setAnnotationArray(0,
								invocationAnnotation);
					}
				}

				wasTriggeredByList.add(wasTriggeredBy);
			}
			res.close();
			wasTriggeredByStmt.close();
			l.info("Exiting getOPMWasTriggeredBy() with success");
			return wasTriggeredByList;

		} catch (SQLException e) {
			l.error("Exiting getOPMWasTriggeredBy() with errors");
			l.error(e.toString());
			return null;
		} finally {

			if (wasTriggeredByStmt != null) {
				wasTriggeredByStmt.close();
				wasTriggeredByStmt = null;
			}

			if (res != null) {
				res.close();
				res = null;
			}
		}
	}

	public List<WasGeneratedBy> getOPMWasGeneratedBy(Connection connection,
			String processID, String provenanceHistoryDataObjectID,
			DetailEnumType.Enum informationDetailLevel) throws SQLException {
		assert (connection != null);
		assert (processID != null);
		assert (provenanceHistoryDataObjectID != null);
		l.info("Entering getOPMWasGeneratedBy()");

		PreparedStatement wasGeneratedByStmt = null;
		ResultSet res = null;

		try {
			wasGeneratedByStmt = connection
					.prepareStatement(OPMSqlQuery.GET_OPM_REVERSED_DATA_FILE_WAS_GENERATED_BY);
			l.debug("getOPMWasGeneratedBy() using processID: " + processID);
			wasGeneratedByStmt.setString(1,
					processID.replace(Common.PROCESS_IDENTIFIER, ""));
			res = wasGeneratedByStmt.executeQuery();
			List<WasGeneratedBy> wasGeneratedByList = new ArrayList<WasGeneratedBy>();

			while (res.next()) {
				String processId = Common.PROCESS_IDENTIFIER + res.getInt(1);
				int dataObjectId = res.getInt(2);
				java.sql.Timestamp noEarlierThan = res.getTimestamp(4);
				String role = res.getString(6);

				WasGeneratedBy wasGeneratedBy = WasGeneratedBy.Factory
						.newInstance();

				wasGeneratedBy.addNewEffect().setRef(
						Common.FILE_IDENTIFIER + dataObjectId);
				wasGeneratedBy.addNewCause().setRef(processId);

				if (role == null) {
					wasGeneratedBy.addNewRole().setValue("Output");
				} else {
					wasGeneratedBy.addNewRole().setValue(role);
				}

				OTime time = wasGeneratedBy.addNewTime();

				time.setNoEarlierThan(Common
						.getCalendarFromTimeStamp(noEarlierThan));
				Calendar c = Common.getArtifactUsedTime(connection,
						dataObjectId);
				if (c == null)
					time.setNoLaterThan(Common
							.getCalendarFromTimeStamp(noEarlierThan));
				else
					time.setNoLaterThan(c);

				if (informationDetailLevel != null
						&& informationDetailLevel.equals(DetailEnumType.FINE)) {

					EmbeddedAnnotation dataLifecycleAnnotation = getDataLifecycleAnnotation(
							connection, res.getString(5));
					if (dataLifecycleAnnotation != null) {
						wasGeneratedBy.addNewAnnotation();
						wasGeneratedBy.setAnnotationArray(0,
								dataLifecycleAnnotation);
					}
				}
				wasGeneratedByList.add(wasGeneratedBy);
			}

			if (res != null) {
				res.close();
				res = null;
			}

			if (wasGeneratedByStmt != null) {
				wasGeneratedByStmt.close();
				wasGeneratedByStmt = null;
			}

			wasGeneratedByStmt = connection
					.prepareStatement(OPMSqlQuery.GET_OPM_REVERSED_DATA_BLOCK_WAS_GENERATED_BY);
			wasGeneratedByStmt.setString(1,
					processID.replace(Common.PROCESS_IDENTIFIER, ""));
			res = wasGeneratedByStmt.executeQuery();

			while (res.next()) {
				String processId = Common.PROCESS_IDENTIFIER + res.getInt(1);
				int dataObjectId = res.getInt(2);
				java.sql.Timestamp noEarlierThan = res.getTimestamp(4);
				String role = res.getString(6);

				WasGeneratedBy wasGeneratedBy = WasGeneratedBy.Factory
						.newInstance();

				wasGeneratedBy.addNewEffect().setRef(
						Common.BLOCK_IDENTIFIER + dataObjectId);
				wasGeneratedBy.addNewCause().setRef(processId);

				if (role == null) {
					wasGeneratedBy.addNewRole().setValue("Output");
				} else {
					wasGeneratedBy.addNewRole().setValue(role);
				}

				OTime time = wasGeneratedBy.addNewTime();

				time.setNoEarlierThan(Common
						.getCalendarFromTimeStamp(noEarlierThan));
				Calendar c = Common.getArtifactUsedTime(connection,
						dataObjectId);
				if (c == null)
					time.setNoLaterThan(Common
							.getCalendarFromTimeStamp(noEarlierThan));
				else
					time.setNoLaterThan(c);
				if (informationDetailLevel != null
						&& informationDetailLevel.equals(DetailEnumType.FINE)) {
					EmbeddedAnnotation dataLifecycleAnnotation = getDataLifecycleAnnotation(
							connection, res.getString(5));
					if (dataLifecycleAnnotation != null) {
						wasGeneratedBy.addNewAnnotation();
						wasGeneratedBy.setAnnotationArray(0,
								dataLifecycleAnnotation);
					}
				}
				wasGeneratedByList.add(wasGeneratedBy);
			}

			res.close();
			wasGeneratedByStmt.close();

			// Collection support to be implemented.
			wasGeneratedByStmt = connection
					.prepareStatement(OPMSqlQuery.GET_OPM_REVERSED_DATA_COLLECTION_WAS_GENERATED_BY);
			wasGeneratedByStmt.setString(1,
					processID.replace(Common.PROCESS_IDENTIFIER, ""));
			res = wasGeneratedByStmt.executeQuery();

			while (res.next()) {
				String processId = Common.PROCESS_IDENTIFIER + res.getInt(1);
				int dataObjectId = res.getInt(2);
				java.sql.Timestamp noEarlierThan = res.getTimestamp(4);
				String role = res.getString(6);

				WasGeneratedBy wasGeneratedBy = WasGeneratedBy.Factory
						.newInstance();

				wasGeneratedBy.addNewEffect().setRef(
						Common.BLOCK_IDENTIFIER + dataObjectId);
				wasGeneratedBy.addNewCause().setRef(processId);

				if (role == null) {
					wasGeneratedBy.addNewRole().setValue("Output");
				} else {
					wasGeneratedBy.addNewRole().setValue(role);
				}

				OTime time = wasGeneratedBy.addNewTime();

				time.setNoEarlierThan(Common
						.getCalendarFromTimeStamp(noEarlierThan));
				Calendar c = Common.getArtifactUsedTime(connection,
						dataObjectId);
				if (c == null)
					time.setNoLaterThan(Common
							.getCalendarFromTimeStamp(noEarlierThan));
				else
					time.setNoLaterThan(c);
				if (informationDetailLevel != null
						&& informationDetailLevel.equals(DetailEnumType.FINE)) {
					EmbeddedAnnotation dataLifecycleAnnotation = getDataLifecycleAnnotation(
							connection, res.getString(5));
					if (dataLifecycleAnnotation != null) {
						wasGeneratedBy.addNewAnnotation();
						wasGeneratedBy.setAnnotationArray(0,
								dataLifecycleAnnotation);
					}
				}
				wasGeneratedByList.add(wasGeneratedBy);
			}

			res.close();
			wasGeneratedByStmt.close();

			l.info("Exiting getOPMWasGeneratedBy() with success");
			return wasGeneratedByList;
		} catch (SQLException e) {
			l.error("Exiting getOPMWasGeneratedBy() with errors");
			l.error(e.toString());
			return null;
		} finally {

			if (wasGeneratedByStmt != null) {
				wasGeneratedByStmt.close();
				wasGeneratedByStmt = null;
			}

			if (res != null) {
				res.close();
				res = null;
			}
		}
	}

	public List<Used> getOPMUsed(Connection connection, String dataObjectID,
			String provenanceHistoryDataObjectID,
			DetailEnumType.Enum informationDetailLevel) throws SQLException {
		assert (connection != null);
		assert (dataObjectID != null);
		assert (provenanceHistoryDataObjectID != null);
		l.info("Entering getOPMUsed()");

		PreparedStatement dataObjectUsedSqlStmt = null;
		ResultSet res = null;
		try {
			dataObjectID = dataObjectID.replace(Common.FILE_IDENTIFIER, "")
					.replace(Common.BLOCK_IDENTIFIER, "")
					.replace(Common.COLLECTION_IDENTIFIER, "");
			List<Used> usedList = new ArrayList<Used>();

			dataObjectUsedSqlStmt = connection
					.prepareStatement(OPMSqlQuery.GET_OPM_REVERSED_DATA_OBJECT_USED);
			dataObjectUsedSqlStmt.setString(1, dataObjectID);
			l.info("dataObjectID : " + dataObjectID);

			res = dataObjectUsedSqlStmt.executeQuery();

			while (res.next()) {
				String pID = Common.PROCESS_IDENTIFIER + res.getString(1);
				int dataObjectId = res.getInt(2);
				java.sql.Timestamp usedTime = res.getTimestamp(3);
				String role = res.getString(5);
				String type = res.getString(6);

				Used used = Used.Factory.newInstance();
				ProcessRef effect = used.addNewEffect();
				effect.setRef(pID);
				ArtifactRef cause = used.addNewCause();
				if (type.equals(DataObject.DataObjectEnum.FILE.toString())) {
					cause.setRef(Common.FILE_IDENTIFIER + dataObjectId);
				} else if (type.equals(DataObject.DataObjectEnum.BLOCK
						.toString())) {
					cause.setRef(Common.BLOCK_IDENTIFIER + dataObjectId);
				} else if (type.equals(DataObject.DataObjectEnum.COLLECTION
						.toString())) {
					cause.setRef(Common.COLLECTION_IDENTIFIER + dataObjectId);
				}

				OTime time = used.addNewTime();

				Calendar noEarlierThan = Common.getArtifactGeneratedTime(
						connection, dataObjectId);

				Calendar noLaterThan = Calendar.getInstance();
				noLaterThan.setTimeInMillis(usedTime.getTime());

				/*
				 * if noEarlierThan time is unavailable, we default to
				 * noLaterThan time
				 */
				if (noEarlierThan == null) {
					time.setNoEarlierThan(noLaterThan);
				} else {
					time.setNoEarlierThan(noEarlierThan);
				}
				time.setNoLaterThan(noLaterThan);

				if (role == null) {
					used.addNewRole().setValue("Input");
				} else {
					used.addNewRole().setValue(role);
				}

				if (informationDetailLevel != null
						&& informationDetailLevel.equals(DetailEnumType.FINE)) {

					EmbeddedAnnotation dataLifecycleAnnotation = getDataLifecycleAnnotation(
							connection, res.getString(4));
					used.addNewAnnotation();
					used.setAnnotationArray(0, dataLifecycleAnnotation);
				}

				usedList.add(used);

			}

			if (res != null) {
				res.close();
				res = null;
			}

			if (dataObjectUsedSqlStmt != null) {
				dataObjectUsedSqlStmt.close();
				dataObjectUsedSqlStmt = null;
			}

			l.info("Exiting getOPMUsed() with success");
			return usedList;
		} catch (SQLException e) {
			l.error("Exiting getOPMUsed() with errors");
			l.error(e.toString());
			return null;
		} finally {

			if (dataObjectUsedSqlStmt != null) {
				dataObjectUsedSqlStmt.close();
				dataObjectUsedSqlStmt = null;
			}

			if (res != null) {
				res.close();
				res = null;
			}
		}
	}

	public Processes getOPMProcessesByID(Connection connection,
			String processID, String provenanceHistoryDataObjectID,
			DetailEnumType.Enum informationDetailLevel) throws SQLException {
		assert (connection != null);
		assert (processID != null);
		assert (provenanceHistoryDataObjectID != null);
		l.info("Entering getOPMProcessesByID()");

		PreparedStatement getOPMProcessesStmt = null;
		PreparedStatement getOPMRegProcessesStmt = null;
		ResultSet res = null;
		ResultSet regProcessResult = null;
		try {
			Processes processes = Processes.Factory.newInstance();
			Process process = processes.addNewProcess();

			getOPMProcessesStmt = connection
					.prepareStatement(OPMSqlQuery.GET_EXE_ENTITIES_BY_ID);
			l.debug("getProcessByID: " + processID);
			getOPMProcessesStmt.setString(1,
					processID.replace(Common.PROCESS_IDENTIFIER, ""));
			/*
			 * In karma entity id is composed of
			 * {workflowID,serviceID,methodID,timestep,workflowNodeID}. All
			 * these information are stored as the value field of each Process.
			 * Unique IDs are assigned for each process in the loop. AccountID
			 * corresponds to the instance. ProcessID and the entity id are kept
			 * same for simplifying the Used and WasGeneratedBy relation
			 */
			String userID = null;
			String workflowID = null;
			String serviceID = null;
			String methodID = null;
			int timestep = -1;
			String workflowNodeID = null;
			String entityType = null;
			int instanceOfID = 0;

			res = getOPMProcessesStmt.executeQuery();

			while (res.next()) {
				userID = workflowID = serviceID = methodID = workflowNodeID = processID = entityType = null;
				timestep = -1;
				entityType = res.getString("entity_type");
				instanceOfID = res.getInt("instance_of");

				/* create the process ID */
				processID = Common.PROCESS_IDENTIFIER + res.getInt("entity_id");

				/* Add the new Process in the Processes list and set the fields */
				process.setId(processID);

				try {
					if (informationDetailLevel != null
							&& informationDetailLevel
									.equals(DetailEnumType.FINE)) {

						EmbeddedAnnotation embeddedAnnotation = process
								.addNewAnnotation();
						Property entityTypeProperty = embeddedAnnotation
								.addNewProperty();
						entityTypeProperty.addNewValue().set(
								XmlObject.Factory.parse("<type>" + entityType
										+ "</type>"));
						entityTypeProperty.setUri("process-type");

						/* User Entity */
						if (entityType.equals(EntityCategoryEnum.USER
								.toString())) {
							userID = res.getString("entity_uri");

							Property userIDProperty = embeddedAnnotation
									.addNewProperty();
							userIDProperty.addNewValue().set(
									XmlObject.Factory.parse("<userID>" + userID
											+ "</userID>"));
							userIDProperty.setUri("process-userID");

						} else if (entityType
								.equals(EntityCategoryEnum.WORKFLOW.toString())) {
							workflowID = res.getString("entity_uri");

							Property workflowIDProperty = embeddedAnnotation
									.addNewProperty();
							workflowIDProperty.addNewValue().set(
									XmlObject.Factory.parse("<workflowID>"
											+ workflowID + "</workflowID>"));
							workflowIDProperty.setUri("process-workflowID");

						} else if (entityType.equals(EntityCategoryEnum.SERVICE
								.toString())) {

							workflowID = res.getString("context_workflow_uri");
							serviceID = res.getString("entity_uri");
							workflowNodeID = res
									.getString("context_wf_node_id_token");
							timestep = res.getInt("timestep");

							Property workflowIDProperty = embeddedAnnotation
									.addNewProperty();
							workflowIDProperty.addNewValue().set(
									XmlObject.Factory.parse("<workflowID>"
											+ workflowID + "</workflowID>"));
							workflowIDProperty.setUri("process-workflowID");

							Property serviceIDProperty = embeddedAnnotation
									.addNewProperty();
							serviceIDProperty.addNewValue().set(
									XmlObject.Factory.parse("<serviceID>"
											+ serviceID + "</serviceID>"));
							serviceIDProperty.setUri("process-serviceID");

							Property timestepProperty = embeddedAnnotation
									.addNewProperty();
							timestepProperty.addNewValue().set(
									XmlObject.Factory.parse("<timestep>"
											+ timestep + "</timestep>"));
							timestepProperty.setUri("process-timestep");

							Property workflowNodeIDProperty = embeddedAnnotation
									.addNewProperty();
							workflowNodeIDProperty.addNewValue().set(
									XmlObject.Factory.parse("<workflowNodeID>"
											+ workflowNodeID
											+ "</workflowNodeID>"));
							workflowNodeIDProperty
									.setUri("process-workflowNodeID");

						} else if (entityType.equals(EntityCategoryEnum.METHOD
								.toString())) {
							workflowID = res.getString("context_workflow_uri");
							serviceID = res.getString("context_service_uri");
							workflowNodeID = res
									.getString("context_wf_node_id_token");
							timestep = res.getInt("timestep");
							methodID = res.getString("entity_uri");

							Property workflowIDProperty = embeddedAnnotation
									.addNewProperty();
							workflowIDProperty.addNewValue().set(
									XmlObject.Factory.parse("<workflowID>"
											+ workflowID + "</workflowID>"));
							workflowIDProperty.setUri("process-workflowID");

							Property serviceIDProperty = embeddedAnnotation
									.addNewProperty();
							serviceIDProperty.addNewValue().set(
									XmlObject.Factory.parse("<serviceID>"
											+ serviceID + "</serviceID>"));
							serviceIDProperty.setUri("process-serviceID");

							Property methodIDProperty = embeddedAnnotation
									.addNewProperty();
							methodIDProperty.addNewValue().set(
									XmlObject.Factory.parse("<methodID>"
											+ methodID + "</methodID>"));
							methodIDProperty.setUri("process-methodID");

							Property timestepProperty = embeddedAnnotation
									.addNewProperty();
							timestepProperty.addNewValue().set(
									XmlObject.Factory.parse("<timestep>"
											+ timestep + "</timestep>"));
							timestepProperty.setUri("process-timestep");

							Property workflowNodeIDProperty = embeddedAnnotation
									.addNewProperty();
							workflowNodeIDProperty.addNewValue().set(
									XmlObject.Factory.parse("<workflowNodeID>"
											+ workflowNodeID
											+ "</workflowNodeID>"));
							workflowNodeIDProperty
									.setUri("process-workflowNodeID");
						}

						EmbeddedAnnotation entityAnnotation = getExeEntityAnnotation(
								connection, provenanceHistoryDataObjectID,
								res.getString("entity_id"));
						if (entityAnnotation != null) {
							process.addNewAnnotation();
							process.setAnnotationArray(
									process.getAnnotationArray().length - 1,
									entityAnnotation);
						}
					}
				} catch (XmlException e) {
					l.error("Error while setting the annotation value of the exe_process.");
					l.error(e.toString());
				}

				if (instanceOfID > 0) {

					if (visitedRegEntity.get(Common.REG_PROCESS_IDENTIFIER
							+ instanceOfID) == null) {

						visitedRegEntity.put(Common.REG_PROCESS_IDENTIFIER
								+ instanceOfID, Common.REG_PROCESS_IDENTIFIER
								+ instanceOfID);

						getOPMRegProcessesStmt = connection
								.prepareStatement(OPMSqlQuery.GET_REG_ENTITIES_BY_ID);
						getOPMRegProcessesStmt.setString(1, instanceOfID + "");

						regProcessResult = getOPMRegProcessesStmt
								.executeQuery();
						while (regProcessResult.next()) {
							/* create the process ID */
							processID = Common.REG_PROCESS_IDENTIFIER
									+ instanceOfID;

							/*
							 * Add the new Process in the Processes list and set
							 * the fields
							 */
							Process regProcess = processes.addNewProcess();
							regProcess.setId(processID);

							String regEntityType = regProcessResult
									.getString("entity_type");
							String regEntityName = regProcessResult
									.getString("name");
							String regEntityVersion = regProcessResult
									.getString("version");
							String regEntityCreationTime = regProcessResult
									.getString("creation_time");

							if (informationDetailLevel != null
									&& informationDetailLevel
											.equals(DetailEnumType.FINE)) {

								try {
									EmbeddedAnnotation embeddedAnnotation = regProcess
											.addNewAnnotation();
									Property entityTypeProperty = embeddedAnnotation
											.addNewProperty();
									entityTypeProperty.addNewValue().set(
											XmlObject.Factory
													.parse("<type>"
															+ regEntityType
															+ "</type>"));
									entityTypeProperty.setUri("process-type");

									Property entityNameProperty = embeddedAnnotation
											.addNewProperty();
									entityNameProperty.addNewValue().set(
											XmlObject.Factory
													.parse("<name>"
															+ regEntityName
															+ "</name>"));
									entityNameProperty.setUri("process-name");

									Property entityVersionProperty = embeddedAnnotation
											.addNewProperty();
									entityVersionProperty.addNewValue().set(
											XmlObject.Factory.parse("<version>"
													+ regEntityVersion
													+ "</version>"));
									entityVersionProperty
											.setUri("process-version");

									Property entityCreationTimeProperty = embeddedAnnotation
											.addNewProperty();
									entityCreationTimeProperty
											.addNewValue()
											.set(XmlObject.Factory
													.parse("<creationTime>"
															+ regEntityCreationTime
															+ "</creationTime>"));
									entityCreationTimeProperty
											.setUri("process-version");

									EmbeddedAnnotation regEntityAnnotation = getRegEntityAnnotation(
											connection,
											provenanceHistoryDataObjectID,
											String.valueOf(instanceOfID));
									if (regEntityAnnotation != null) {
										process.addNewAnnotation();
										process.setAnnotationArray(
												process.getAnnotationArray().length - 1,
												regEntityAnnotation);
									}

								} catch (XmlException e) {
									l.error("Error while setting the annotation value of the reg_process.");
									l.error(e.toString());
								}
							}
						}

						regProcessResult.close();
						getOPMRegProcessesStmt.close();
					}
				}
			}
			res.close();
			getOPMProcessesStmt.close();

			l.info("Exiting getOPMProcessesByID()");
			return processes;
		} catch (SQLException e) {
			l.error("Exiting getOPMProcessesByID() with errors");
			l.error(e.toString());
			return null;
		} finally {

			if (getOPMProcessesStmt != null) {
				getOPMProcessesStmt.close();
				getOPMProcessesStmt = null;
			}

			if (getOPMRegProcessesStmt != null) {
				getOPMRegProcessesStmt.close();
				getOPMRegProcessesStmt = null;
			}

			if (res != null) {
				res.close();
				res = null;
			}

			if (regProcessResult != null) {
				regProcessResult.close();
				regProcessResult = null;
			}
		}
	}

	public Artifact getOPMArtifactByID(Connection connection,
			String artifactID, String provenanceHistoryDataObjectID,
			DetailEnumType.Enum informationDetailLevel) throws SQLException {
		assert (connection != null);
		assert (artifactID != null);
		assert (provenanceHistoryDataObjectID != null);
		l.info("Entering getOPMArtifactsByID()");

		PreparedStatement getDataObjectStmt = null;
		ResultSet res = null;

		/* get artifact based on unique ID */
		try {
			Artifact opmArtifact = Artifact.Factory.newInstance();

			/* get file_id */
			if (artifactID.startsWith(Common.FILE_IDENTIFIER)) {
				String fileID = artifactID.replace(Common.FILE_IDENTIFIER, "");

				getDataObjectStmt = connection
						.prepareStatement(OPMSqlQuery.GET_FILE_BY_ID);
				getDataObjectStmt.setString(1, fileID);

				res = getDataObjectStmt.executeQuery();

				if (res.next()) {
					String fileURI = res.getString(1);
					String size = res.getString(2);

					opmArtifact.setId(artifactID);

					if (informationDetailLevel != null
							&& informationDetailLevel
									.equals(DetailEnumType.FINE)) {

						try {
							Property newProperty;
							EmbeddedAnnotation embeddedAnnotation = opmArtifact
									.addNewAnnotation();
							newProperty = embeddedAnnotation.addNewProperty();
							newProperty.addNewValue().set(
									XmlObject.Factory.parse("<fileURI>"
											+ fileURI + "</fileURI>"));

							newProperty.setUri("artifact-uri");

						} catch (XmlException e) {
							l.error("Set uri annotation error.");
							l.error(e.toString());
						}

						if (size != null) {
							try {
								Property newProperty;
								if (opmArtifact.getAnnotationArray().length == 0) {
									EmbeddedAnnotation embeddedAnnotation = opmArtifact
											.addNewAnnotation();
									newProperty = embeddedAnnotation
											.addNewProperty();
								} else {
									newProperty = opmArtifact
											.getAnnotationArray(0)
											.addNewProperty();
								}

								newProperty.addNewValue().set(
										XmlObject.Factory.parse("<size>" + size
												+ "</size>"));
								newProperty.setUri("artifact-size");

							} catch (XmlException e) {
								l.error("Set size annotation error.");
								l.error(e.toString());
							}

						}

						EmbeddedAnnotation entityAnnotation = getDataObjectAnnotation(
								connection, provenanceHistoryDataObjectID,
								fileID);
						if (entityAnnotation != null) {
							opmArtifact.addNewAnnotation();
							opmArtifact
									.setAnnotationArray(
											opmArtifact.getAnnotationArray().length - 1,
											entityAnnotation);
						}
					}
					l.debug("Got artifact with ID : " + fileID);
				}

				res.close();
				getDataObjectStmt.close();
			} else if (artifactID.startsWith(Common.BLOCK_IDENTIFIER)) {
				String inputBlockID = artifactID.replace(
						Common.BLOCK_IDENTIFIER, "");
				/* get block_id */
				getDataObjectStmt = connection
						.prepareStatement(OPMSqlQuery.GET_BLOCK_BY_ID);
				getDataObjectStmt.setString(1, inputBlockID);

				res = getDataObjectStmt.executeQuery();

				if (res.next()) {

					String size = res.getString(2);
					String content = res.getString(3);
					opmArtifact.setId(artifactID);
					if (res.getString(1).equals(inputBlockID)
							&& informationDetailLevel != null
							&& informationDetailLevel
									.equals(DetailEnumType.FINE)) {

						if (size != null) {
							try {
								EmbeddedAnnotation embeddedAnnotation = opmArtifact
										.addNewAnnotation();
								Property newProperty = embeddedAnnotation
										.addNewProperty();

								newProperty.addNewValue().set(
										XmlObject.Factory.parse("<size>" + size
												+ "</size>"));
								newProperty.setUri("artifact-size");

							} catch (XmlException e) {
								l.error("Set size annotation error.");
								l.error(e.toString());
							}
						}

						if (content != null) {
							try {
								if (opmArtifact.getAnnotationArray().length == 0) {
									EmbeddedAnnotation embeddedAnnotation = opmArtifact
											.addNewAnnotation();
									Property newProperty = embeddedAnnotation
											.addNewProperty();
									newProperty.addNewValue().set(
											XmlObject.Factory.parse("<content>"
													+ content + "</content>"));
									newProperty.setUri("artifact-content");

								} else {
									Property newProperty = opmArtifact
											.getAnnotationArray(0)
											.addNewProperty();
									newProperty.addNewValue().set(
											XmlObject.Factory.parse("<content>"
													+ content + "</content>"));
									newProperty.setUri("artifact-content");
								}
							} catch (XmlException e) {
								l.error("Set content annotation error.");
								l.error(e.toString());
							}

						}

						EmbeddedAnnotation entityAnnotation = getDataObjectAnnotation(
								connection, provenanceHistoryDataObjectID,
								inputBlockID);
						if (entityAnnotation != null) {
							opmArtifact.addNewAnnotation();
							opmArtifact
									.setAnnotationArray(
											opmArtifact.getAnnotationArray().length - 1,
											entityAnnotation);
						}
					}
				}

				res.close();
				getDataObjectStmt.close();
			} else if (artifactID.startsWith(Common.COLLECTION_IDENTIFIER)) {
				String collectionID = artifactID.replace(
						Common.COLLECTION_IDENTIFIER, "");

				getDataObjectStmt = connection
						.prepareStatement(OPMSqlQuery.GET_COLLECTION_BY_ID);
				getDataObjectStmt.setString(1, collectionID);

				res = getDataObjectStmt.executeQuery();

				if (res.next()) {

					String collectionURI = res.getString(2);
					opmArtifact.setId(artifactID);

					if (informationDetailLevel != null
							&& informationDetailLevel
									.equals(DetailEnumType.FINE)) {

						try {
							Property newProperty;
							EmbeddedAnnotation embeddedAnnotation = opmArtifact
									.addNewAnnotation();
							newProperty = embeddedAnnotation.addNewProperty();
							newProperty.addNewValue().set(
									XmlObject.Factory.parse("<collectionURI>"
											+ collectionURI
											+ "</collectionURI>"));

							newProperty.setUri("artifact-uri");

						} catch (XmlException e) {
							l.error("Set uri annotation error.");
							l.error(e.toString());
						}

						EmbeddedAnnotation entityAnnotation = getDataObjectAnnotation(
								connection, provenanceHistoryDataObjectID,
								collectionID);
						if (entityAnnotation != null) {
							opmArtifact.addNewAnnotation();
							opmArtifact
									.setAnnotationArray(
											opmArtifact.getAnnotationArray().length - 1,
											entityAnnotation);
						}
					}
					l.debug("Got artifact with ID : " + collectionID);
				}

				res.close();
				getDataObjectStmt.close();
			} else {
				l.error("Unrecognized artifact type.");
			}

			l.debug(opmArtifact.getId());
			l.info("Exiting getArtifactDataID() with success");

			return opmArtifact;

		} catch (SQLException e) {
			l.error("Exiting getArtifactDataID() with errors");
			l.error(e.toString());
			return null;
		} finally {

			if (getDataObjectStmt != null) {
				getDataObjectStmt.close();
				getDataObjectStmt = null;
			}

			if (res != null) {
				res.close();
				res = null;
			}
		}
	}

	private OpmGraphDocument getOPMGraphDocumentByArtifactID(
			Connection connection, List<Artifact> artifactList,
			String provenanceHistoryDataObjectID, Calendar boundaryTime,
			DetailEnumType.Enum informationDetailLevel) throws QueryException,
			SQLException {

		l.info("Entering getOPMGraphDocumentByArtifactID()");

		OpmGraphDocument opmGraphDoc = OpmGraphDocument.Factory.newInstance();
		OPMGraph opmGraph = opmGraphDoc.addNewOpmGraph();

		List<Artifact> OPMArtifacts = new ArrayList<Artifact>();
		List<Process> OPMProcesses = new ArrayList<Process>();
		List<WasDerivedFrom> OPMWasDerivedFrom = new ArrayList<WasDerivedFrom>();
		List<WasDerivedFrom> wasDerivedFromProcessingList = new ArrayList<WasDerivedFrom>();
		List<Used> OPMUsed = new ArrayList<Used>();
		List<Used> usedProcessingList = new ArrayList<Used>();

		for (Artifact artifact : artifactList) {
			OPMWasDerivedFrom.addAll(getOPMWasDerivedFrom(connection,
					artifact.getId(), provenanceHistoryDataObjectID,
					informationDetailLevel));

			OPMUsed.addAll(getOPMUsed(connection, artifact.getId(),
					provenanceHistoryDataObjectID, informationDetailLevel));
		}

		while (OPMWasDerivedFrom.size() > 0) {
			WasDerivedFrom wasDerivedFrom = OPMWasDerivedFrom.get(0);

			if (boundaryTime == null
					|| wasDerivedFrom.getTime().getNoLaterThan()
							.equals(boundaryTime)
					|| wasDerivedFrom.getTime().getNoLaterThan()
							.before(boundaryTime)) {
				if (visitedWasDerivedFrom.size() == 0
						|| visitedWasDerivedFrom.get(wasDerivedFrom.getEffect()
								.getRef()) == null
						|| !visitedWasDerivedFrom.get(
								wasDerivedFrom.getEffect().getRef()).equals(
								wasDerivedFrom.getCause().getRef())) {

					if (visitedArtifacts.size() == 0
							|| visitedArtifacts.get(wasDerivedFrom.getEffect()
									.getRef()) == null) {

						OPMArtifacts.add(getOPMArtifactByID(connection,
								wasDerivedFrom.getEffect().getRef(),
								provenanceHistoryDataObjectID,
								informationDetailLevel));
						visitedArtifacts.put(wasDerivedFrom.getEffect()
								.getRef(), wasDerivedFrom.getEffect().getRef());
					}

					wasDerivedFromProcessingList.add(wasDerivedFrom);
					visitedWasDerivedFrom.put(wasDerivedFrom.getEffect()
							.getRef(), wasDerivedFrom.getCause().getRef());
				}
			}

			OPMWasDerivedFrom.remove(0);
		}

		while (OPMUsed.size() > 0) {
			Used used = OPMUsed.get(0);
			if (boundaryTime == null
					|| used.getTime().getNoLaterThan().equals(boundaryTime)
					|| used.getTime().getNoLaterThan().before(boundaryTime)) {

				if (visitedUsed.size() == 0
						|| visitedUsed.get(used.getEffect().getRef()) == null
						|| !visitedUsed.get(used.getEffect().getRef()).equals(
								used.getCause().getRef())) {

					if (visitedProcesses.size() == 0
							|| visitedProcesses.get(used.getEffect().getRef()) == null) {

						Processes processesByID = getOPMProcessesByID(
								connection, used.getEffect().getRef(),
								provenanceHistoryDataObjectID,
								informationDetailLevel);

						if (processesByID != null) {
							for (Process p : processesByID.getProcessArray())
								OPMProcesses.add(p);
						}
						visitedProcesses.put(used.getEffect().getRef(), used
								.getEffect().getRef());
					}
					usedProcessingList.add(used);
					visitedUsed.put(used.getEffect().getRef(), used.getCause()
							.getRef());
				}
			}
			OPMUsed.remove(0);
		}

		if (OPMArtifacts.size() == 0) {
			/* Base case: do nothing */
		} else {
			/* Expand Graph for Artifacts within time range */
			l.debug("getOPMGraphDocumentByArtifactID: " + OPMArtifacts.size());
			OpmGraphDocument opmGraphDocumentByArtifactID = getOPMGraphDocumentByArtifactID(
					connection, OPMArtifacts, provenanceHistoryDataObjectID,
					boundaryTime, informationDetailLevel);

			copyToNewGraph(opmGraphDocumentByArtifactID, opmGraphDoc);

			if (OPMArtifacts.size() > 0 && opmGraph.getArtifacts() == null)
				opmGraph.addNewArtifacts();
			for (int i = 0; i < OPMArtifacts.size(); i++) {
				Artifact a = OPMArtifacts.get(i);
				Artifact newArtifact = opmGraph.getArtifacts().addNewArtifact();
				setOPMArtifact(a, newArtifact);
			}
		}

		if (OPMProcesses.size() == 0) {
			/* Base case: do nothing */
		} else {
			if (OPMProcesses.size() == 0) {

			} else {
				/* Expand Graph for Artifacts within time range */

				OpmGraphDocument opmGraphDocumentByProcessID = getOPMGraphDocumentByProcessID(
						connection, OPMProcesses,
						provenanceHistoryDataObjectID, boundaryTime,
						informationDetailLevel);
				copyToNewGraph(opmGraphDocumentByProcessID, opmGraphDoc);

				if (OPMProcesses.size() > 0 && opmGraph.getProcesses() == null)
					opmGraph.addNewProcesses();
				for (int i = 0; i < OPMProcesses.size(); i++) {
					Process p = OPMProcesses.get(i);
					Process newProcess = opmGraph.getProcesses()
							.addNewProcess();
					setOPMProcess(p, newProcess);
				}
			}
		}

		if ((wasDerivedFromProcessingList.size() > 0)
				|| (usedProcessingList.size() > 0)) {
			if (opmGraph.getCausalDependencies() == null)
				opmGraph.addNewCausalDependencies();

			CausalDependencies causalDependencies = opmGraph
					.getCausalDependencies();
			for (WasDerivedFrom w : wasDerivedFromProcessingList) {
				causalDependencies.addNewWasDerivedFrom();
				int i = causalDependencies.getWasDerivedFromArray().length - 1;
				causalDependencies.setWasDerivedFromArray(i, w);
			}

			for (Used u : usedProcessingList) {
				causalDependencies.addNewUsed();
				int i = causalDependencies.getUsedArray().length - 1;
				causalDependencies.setUsedArray(i, u);
			}

		}

		l.info("Exiting getOPMGraphDocumentByArtifactID() with success.");
		return opmGraphDoc;
	}

	private OpmGraphDocument getOPMGraphDocumentByProcessID(
			Connection connection, List<Process> processList,
			String provenanceHistoryDataObjectID, Calendar boundaryTime,
			DetailEnumType.Enum informationDetailLevel) throws QueryException,
			SQLException {
		l.info("Entering getOPMGraphDocumentByProcessID()");
		OpmGraphDocument opmGraphDoc = OpmGraphDocument.Factory.newInstance();
		OPMGraph opmGraph = opmGraphDoc.addNewOpmGraph();

		List<Artifact> OPMArtifacts = new ArrayList<Artifact>();
		List<Process> OPMProcesses = new ArrayList<Process>();

		List<WasTriggeredBy> OPMWasTriggeredBy = new ArrayList<WasTriggeredBy>();
		List<WasTriggeredBy> wasTriggeredByProcessingList = new ArrayList<WasTriggeredBy>();
		List<WasGeneratedBy> OPMWasGeneratedBy = new ArrayList<WasGeneratedBy>();
		List<WasGeneratedBy> wasGeneratedByProcessingList = new ArrayList<WasGeneratedBy>();

		for (Process process : processList) {
			OPMWasTriggeredBy.addAll(getOPMWasTriggeredBy(connection,
					process.getId(), provenanceHistoryDataObjectID,
					informationDetailLevel));

			OPMWasGeneratedBy.addAll(getOPMWasGeneratedBy(connection,
					process.getId(), provenanceHistoryDataObjectID,
					informationDetailLevel));
		}

		for (int i = 0; i < OPMWasTriggeredBy.size(); i++) {
			WasTriggeredBy wasTriggeredBy = OPMWasTriggeredBy.get(i);
			if (boundaryTime == null
					|| wasTriggeredBy.getTime().getNoLaterThan()
							.equals(boundaryTime)
					|| wasTriggeredBy.getTime().getNoLaterThan()
							.before(boundaryTime)) {

				if (visitedWasTriggeredBy.size() == 0
						|| visitedWasTriggeredBy.get(wasTriggeredBy.getEffect()
								.getRef()) == null
						|| !visitedWasTriggeredBy.get(
								wasTriggeredBy.getEffect().getRef()).equals(
								wasTriggeredBy.getCause().getRef())) {

					if (visitedProcesses.size() == 0
							|| visitedProcesses.get(wasTriggeredBy.getEffect()
									.getRef()) == null) {

						Processes processesByID = getOPMProcessesByID(
								connection,
								wasTriggeredBy.getEffect().getRef(),
								provenanceHistoryDataObjectID,
								informationDetailLevel);

						if (processesByID != null) {
							for (Process p : processesByID.getProcessArray())
								OPMProcesses.add(p);
						}
						visitedProcesses.put(wasTriggeredBy.getEffect()
								.getRef(), wasTriggeredBy.getEffect().getRef());
					}
					wasTriggeredByProcessingList.add(wasTriggeredBy);
					visitedWasTriggeredBy.put(wasTriggeredBy.getEffect()
							.getRef(), wasTriggeredBy.getCause().getRef());

				}
			}
		}

		while (OPMWasGeneratedBy.size() > 0) {
			WasGeneratedBy wasGeneratedBy = OPMWasGeneratedBy.get(0);

			if (boundaryTime == null
					|| wasGeneratedBy.getTime().getNoLaterThan()
							.equals(boundaryTime)
					|| wasGeneratedBy.getTime().getNoLaterThan()
							.before(boundaryTime)) {

				if (visitedWasGeneratedBy.size() == 0
						|| visitedWasGeneratedBy.get(wasGeneratedBy.getEffect()
								.getRef()) == null
						|| !visitedWasGeneratedBy.get(
								wasGeneratedBy.getEffect().getRef()).equals(
								wasGeneratedBy.getCause().getRef())) {

					if (visitedArtifacts.size() == 0
							|| visitedArtifacts.get(wasGeneratedBy.getEffect()
									.getRef()) == null) {

						OPMArtifacts.add(getOPMArtifactByID(connection,
								wasGeneratedBy.getEffect().getRef(),
								provenanceHistoryDataObjectID,
								informationDetailLevel));
						visitedArtifacts.put(wasGeneratedBy.getEffect()
								.getRef(), wasGeneratedBy.getEffect().getRef());
					}
					wasGeneratedByProcessingList.add(wasGeneratedBy);
					visitedWasGeneratedBy.put(wasGeneratedBy.getEffect()
							.getRef(), wasGeneratedBy.getCause().getRef());

				}
			}
			OPMWasGeneratedBy.remove(0);

		}

		if (OPMArtifacts.size() == 0) {
			/* Base case: do nothing */
		} else {
			/* Expand Graph for Artifacts within time range */
			OpmGraphDocument opmGraphDocumentByArtifactID = getOPMGraphDocumentByArtifactID(
					connection, OPMArtifacts, provenanceHistoryDataObjectID,
					boundaryTime, informationDetailLevel);
			copyToNewGraph(opmGraphDocumentByArtifactID, opmGraphDoc);

			if (OPMArtifacts.size() > 0 && opmGraph.getArtifacts() == null)
				opmGraph.addNewArtifacts();
			for (int i = 0; i < OPMArtifacts.size(); i++) {
				Artifact a = OPMArtifacts.get(i);
				Artifact newArtifact = opmGraph.getArtifacts().addNewArtifact();
				setOPMArtifact(a, newArtifact);
			}
		}

		if (OPMProcesses.size() == 0) {
			/* Base case: do nothing */
		} else {
			if (OPMProcesses.size() == 0) {

			} else {
				/* Expand Graph for Artifacts within time range */

				OpmGraphDocument opmGraphDocumentByProcessID = getOPMGraphDocumentByProcessID(
						connection, OPMProcesses,
						provenanceHistoryDataObjectID, boundaryTime,
						informationDetailLevel);
				copyToNewGraph(opmGraphDocumentByProcessID, opmGraphDoc);

				if (OPMProcesses.size() > 0 && opmGraph.getProcesses() == null)
					opmGraph.addNewProcesses();
				for (int i = 0; i < OPMProcesses.size(); i++) {
					Process p = OPMProcesses.get(i);
					Process newProcess = opmGraph.getProcesses()
							.addNewProcess();
					setOPMProcess(p, newProcess);
				}
			}
		}

		if ((wasGeneratedByProcessingList.size() > 0)
				|| (wasTriggeredByProcessingList.size() > 0)) {
			if (opmGraph.getCausalDependencies() == null)
				opmGraph.addNewCausalDependencies();
			CausalDependencies causalDependencies = opmGraph
					.getCausalDependencies();
			for (WasGeneratedBy w : wasGeneratedByProcessingList) {
				causalDependencies.addNewWasGeneratedBy();
				int i = causalDependencies.getWasGeneratedByArray().length - 1;
				causalDependencies.setWasGeneratedByArray(i, w);
			}

			for (WasTriggeredBy w : wasTriggeredByProcessingList) {
				causalDependencies.addNewWasTriggeredBy();
				int i = causalDependencies.getWasTriggeredByArray().length - 1;
				causalDependencies.setWasTriggeredByArray(i, w);
			}
		}

		l.info("Exiting getOPMGraphDocumentByProcessID() with success");
		return opmGraphDoc;
	}

	public OpmGraphDocument getOPMGraphDocumentByDataID(Connection connection,
			String dataObjectID, long timeRange,
			DetailEnumType.Enum informationDetailLevel, long cacheExpiration)
			throws QueryException, SQLException, IOException {

		OpmGraphDocument opmGraphDoc = OpmGraphDocument.Factory.newInstance();
		OPMGraph opmGraph = opmGraphDoc.addNewOpmGraph();

		PreparedStatement getCountStatement = null;
		PreparedStatement statement = null;
		PreparedStatement getEventTimeStmt = null;
		PreparedStatement getFileIDStmt = null;
		ResultSet rs = null;
		ResultSet resultSet = null;
		ResultSet blockResultSet = null;
		ResultSet collectionResultSet = null;
		ResultSet fileResultSet = null;
		ByteArrayInputStream byteArrayInputStream = null;

		try {

			visitedArtifacts = new HashMap<String, String>();
			visitedProcesses = new HashMap<String, String>();
			visitedUsed = new HashMap<String, String>();
			visitedWasGeneratedBy = new HashMap<String, String>();
			visitedWasDerivedFrom = new HashMap<String, String>();
			visitedWasTriggeredBy = new HashMap<String, String>();
			visitedRegEntity = new HashMap<String, String>();

			statement = connection.prepareStatement(GET_CACHE_DATA_USAGE_GRAPH);
			statement.setString(1, dataObjectID);
			statement.setString(2, String.valueOf(timeRange));
			if (informationDetailLevel.equals(DetailEnumType.FINE)) {
				statement.setBoolean(3, true);
			} else {
				statement.setBoolean(3, false);
			}
			resultSet = statement.executeQuery();

			boolean isCached = false;
			boolean b = false;
			int id = 0;
			if (resultSet.next()) {
				b = resultSet.getBoolean("dirty");
				id = resultSet.getInt(1);
				String cachedGraph = resultSet.getString(3);
				isCached = true;

				Timestamp currentTime = new java.sql.Timestamp(Calendar
						.getInstance().getTimeInMillis());
				Timestamp lastQueriedTime = resultSet.getTimestamp(4);

				long difference = currentTime.getTime()
						- lastQueriedTime.getTime();
				l.info("Last query was issued " + difference
						+ " milliseconds away..");

				if (difference > cacheExpiration) {
					b = true; // force record to be dirty and update.
				}

				if (!b) {
					l.info("Returning cached graph.");
					if (statement != null) {
						statement.close();
						statement = null;
					}

					if (resultSet != null) {
						resultSet.close();
						resultSet = null;
					}

					statement = connection.prepareStatement(UPDATE_QUERY_DATE);
					statement.setTimestamp(1, new java.sql.Timestamp(Calendar
							.getInstance().getTimeInMillis()));
					statement.setInt(2, id);
					statement.execute();
					if (statement != null) {
						statement.close();
						statement = null;
					}

					opmGraphDoc = OpmGraphDocument.Factory.parse(cachedGraph);
					return opmGraphDoc;
				} else {
					if (statement != null) {
						statement.close();
						statement = null;
					}

					if (resultSet != null) {
						resultSet.close();
						resultSet = null;
					}

				}
			} else {
				l.info("Query has not been cached.");
				isCached = false;
			}

			long beginTime = System.currentTimeMillis();
			Artifacts artifacts = opmGraph.addNewArtifacts();

			/* Initial Condition */
			Artifact initialArtifact = getOPMArtifactByID(connection,
					dataObjectID, dataObjectID, informationDetailLevel);

			Calendar boundaryTime = Calendar.getInstance();
			String artifactID = null;
			if (initialArtifact.getId() != null) {
				if (initialArtifact.getId().startsWith(Common.BLOCK_IDENTIFIER)) {
					artifactID = initialArtifact.getId().replace(
							Common.BLOCK_IDENTIFIER, "");
					getEventTimeStmt = connection
							.prepareStatement(OPMSqlQuery.GET_BLOCK_EVENT_TIME_BY_ID);
					getEventTimeStmt.setString(1, artifactID);
					blockResultSet = getEventTimeStmt.executeQuery();

					if (blockResultSet.next()) {
						Timestamp timestamp = blockResultSet.getTimestamp(1);
						if (timestamp != null) {
							l.info("Date to set: " + timestamp);
							boundaryTime.setTime(timestamp);
						} else {
							l.info("Time not set.");
						}
					}

					if (getEventTimeStmt != null) {
						getEventTimeStmt.close();
						getEventTimeStmt = null;
					}

					if (blockResultSet != null) {
						blockResultSet.close();
						blockResultSet = null;
					}

				} else if (initialArtifact.getId().startsWith(
						Common.COLLECTION_IDENTIFIER)) {
					artifactID = initialArtifact.getId().replace(
							Common.COLLECTION_IDENTIFIER, "");
					getEventTimeStmt = connection
							.prepareStatement(OPMSqlQuery.GET_COLLECTION_EVENT_TIME_BY_ID);
					getEventTimeStmt.setString(1, artifactID);
					collectionResultSet = getEventTimeStmt.executeQuery();

					if (collectionResultSet.next()) {
						Timestamp timestamp = collectionResultSet
								.getTimestamp(1);
						if (timestamp != null) {
							l.info("Date to set: " + timestamp);
							boundaryTime.setTime(timestamp);
						} else {
							l.info("Time not set.");
						}
					}

					if (getEventTimeStmt != null) {
						getEventTimeStmt.close();
						getEventTimeStmt = null;
					}

					if (collectionResultSet != null) {
						collectionResultSet.close();
						collectionResultSet = null;
					}
				} else {

					try {

						String fileID = dataObjectID.replace(
								Common.FILE_IDENTIFIER, "");
						getFileIDStmt = connection
								.prepareStatement(OPMSqlQuery.GET_FILE_BY_ID);
						getFileIDStmt.setString(1, fileID);
						fileResultSet = getFileIDStmt.executeQuery();
						if (fileResultSet.next()) {
							artifactID = fileID;
							Date date = fileResultSet.getDate(3);
							if (date != null) {
								boundaryTime.setTime(date);
							} else {
								l.info("Time not set.");
							}
						}

						if (getFileIDStmt != null) {
							getFileIDStmt.close();
							getFileIDStmt = null;
						}

						if (fileResultSet != null) {
							fileResultSet.close();
							fileResultSet = null;
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			} else {
				// no artifact found.
				l.info("Exiting getOPMGraphDocumentByDataID() with success: No initial artifact found.");
				return opmGraphDoc;
			}

			artifacts.addNewArtifact();
			artifacts.setArtifactArray(0, initialArtifact);
			visitedArtifacts.put(initialArtifact.getId(),
					initialArtifact.getId());

			/* Set time boundary */
			if (boundaryTime != null)
				l.info("Boundary time before adding on time range: "
						+ boundaryTime.getTime());

			if (timeRange != 0)
				boundaryTime.setTimeInMillis(boundaryTime.getTimeInMillis()
						+ timeRange);
			else
				boundaryTime = null;

			if (boundaryTime != null)
				l.info("Boundary time after adding time range: "
						+ boundaryTime.getTime());

			List<Artifact> OPMArtifacts = new ArrayList<Artifact>();
			List<Process> OPMProcesses = new ArrayList<Process>();
			List<WasDerivedFrom> OPMWasDerivedFrom = getOPMWasDerivedFrom(
					connection, dataObjectID, dataObjectID,
					informationDetailLevel);
			List<Used> OPMUsed = getOPMUsed(connection, dataObjectID,
					dataObjectID, informationDetailLevel);

			if ((OPMUsed.size() > 0) || (OPMWasDerivedFrom.size() > 0)) {
				if (opmGraph.getCausalDependencies() == null)
					opmGraph.addNewCausalDependencies();

				CausalDependencies causalDependencies = opmGraph
						.getCausalDependencies();

				for (WasDerivedFrom w : OPMWasDerivedFrom) {
					if (boundaryTime == null
							|| w.getTime().getNoLaterThan()
									.equals(boundaryTime)
							|| w.getTime().getNoLaterThan()
									.before(boundaryTime)) {

						if (visitedWasDerivedFrom.size() == 0
								|| visitedWasDerivedFrom.get(w.getEffect()
										.getRef()) == null
								|| !visitedWasDerivedFrom.get(
										w.getEffect().getRef()).equals(
										w.getCause().getRef())) {

							causalDependencies.addNewWasDerivedFrom();
							int i = causalDependencies.getWasDerivedFromArray().length - 1;
							causalDependencies.setWasDerivedFromArray(i, w);
							if (visitedArtifacts.size() == 0
									|| visitedArtifacts.get(w.getEffect()
											.getRef()) == null) {
								OPMArtifacts.add(getOPMArtifactByID(connection,
										w.getEffect().getRef(), dataObjectID,
										informationDetailLevel));
								visitedArtifacts.put(w.getEffect().getRef(), w
										.getEffect().getRef());
							}

							visitedWasDerivedFrom.put(w.getEffect().getRef(), w
									.getCause().getRef());
						}
					}
				}

				for (Used u : OPMUsed) {
					if (boundaryTime == null
							|| u.getTime().getNoLaterThan()
									.equals(boundaryTime)
							|| u.getTime().getNoLaterThan()
									.before(boundaryTime)) {

						if (visitedUsed.size() == 0
								|| visitedUsed.get(u.getEffect().getRef()) == null
								|| !visitedUsed.get(u.getEffect().getRef())
										.equals(u.getCause().getRef())) {

							visitedUsed.put(u.getCause().getRef(), u
									.getEffect().getRef());
							causalDependencies.addNewUsed();
							int i = causalDependencies.getUsedArray().length - 1;
							causalDependencies.setUsedArray(i, u);
							if (visitedProcesses.size() == 0
									|| visitedProcesses.get(u.getEffect()
											.getRef()) == null) {

								Processes processesByID = getOPMProcessesByID(
										connection, u.getEffect().getRef(),
										dataObjectID, informationDetailLevel);

								if (processesByID != null) {
									for (Process p : processesByID
											.getProcessArray())
										OPMProcesses.add(p);
								}

								visitedProcesses.put(u.getEffect().getRef(), u
										.getEffect().getRef());
							}
						}
					}
				}
			}

			if (OPMArtifacts.size() == 0) {
				/* Base case */
			} else {
				/* Expand Graph for Artifacts within time range */

				OpmGraphDocument opmGraphDocumentByArtifactID = getOPMGraphDocumentByArtifactID(
						connection, OPMArtifacts, dataObjectID, boundaryTime,
						informationDetailLevel);

				copyToNewGraph(opmGraphDocumentByArtifactID, opmGraphDoc);

				if (OPMArtifacts.size() > 0 && opmGraph.getArtifacts() == null)
					opmGraph.addNewArtifacts();
				for (int i = 0; i < OPMArtifacts.size(); i++) {
					Artifact a = OPMArtifacts.get(i);
					Artifact newArtifact = opmGraph.getArtifacts()
							.addNewArtifact();
					setOPMArtifact(a, newArtifact);
				}
			}

			if (OPMProcesses.size() == 0) {
				/* Base case */
			} else {
				/* Expand Graph for Artifacts within time range */
				l.info("getOPMGraphDocumentByDataID: " + OPMProcesses.size());

				OpmGraphDocument opmGraphDocumentByProcessID = getOPMGraphDocumentByProcessID(
						connection, OPMProcesses, dataObjectID, boundaryTime,
						informationDetailLevel);

				copyToNewGraph(opmGraphDocumentByProcessID, opmGraphDoc);

				if (OPMProcesses.size() > 0 && opmGraph.getProcesses() == null)
					opmGraph.addNewProcesses();
				for (int i = 0; i < OPMProcesses.size(); i++) {
					Process p = OPMProcesses.get(i);
					Process newProcess = opmGraph.getProcesses()
							.addNewProcess();
					setOPMProcess(p, newProcess);
				}

			}

			long endTime = System.currentTimeMillis();

			long generationTime = endTime - beginTime;

			if (!isCached) {
				// graph is not cached
				getCountStatement = connection
						.prepareStatement(GET_CACHE_COUNT);

				rs = getCountStatement.executeQuery();
				if (rs.next()) {
					if (rs.getInt(1) == MAX_CACHE_ENTRIES) {
						statement = connection
								.prepareStatement(GET_GRAPH_TO_DELETE);
						statement.execute();
						if (rs.next()) {
							rs.deleteRow();
						}

						if (statement != null) {
							statement.close();
							statement = null;
						}
					}

					byteArrayInputStream = new ByteArrayInputStream(opmGraphDoc
							.xmlText().getBytes());
					statement = connection.prepareStatement(NEW_CACHE_GRAPH);

					statement.setString(1, dataObjectID);
					statement.setBinaryStream(2, byteArrayInputStream);
					statement.setString(3, String.valueOf(generationTime));
					statement.setTimestamp(4, new java.sql.Timestamp(Calendar
							.getInstance().getTimeInMillis()));
					statement.setString(5, String.valueOf(timeRange));

					if (informationDetailLevel == DetailEnumType.FINE) {
						statement.setBoolean(6, true);
					} else {
						statement.setBoolean(6, false);
					}

				}

				if (getCountStatement != null) {
					getCountStatement.close();
					getCountStatement = null;
				}
				l.info("Caching graph.");
			} else {
				// dirty bit was set so update
				byteArrayInputStream = new ByteArrayInputStream(opmGraphDoc
						.xmlText().getBytes());

				statement = connection.prepareStatement(UPDATE_CACHE_GRAPH);
				statement.setBinaryStream(1, byteArrayInputStream);
				statement.setBoolean(2, false);
				statement.setString(3, String.valueOf(generationTime));
				statement.setTimestamp(4, new java.sql.Timestamp(Calendar
						.getInstance().getTimeInMillis()));
				statement.setInt(5, id);

				l.info("Updating cache graph.");
			}

			statement.executeUpdate();
			if (statement != null) {
				statement.close();
				statement = null;
			}

		} catch (SQLException e) {
			l.error("Exiting getOPMGraphDocumentByDataID() with SQL errors");
			l.error(e.toString());
			return opmGraphDoc;

		} catch (XmlException e) {
			l.error("Exiting getOPMGraphDocumentByDataID() with XML parse errors");
			l.error(e.toString());
			return opmGraphDoc;

		} finally {
			if (visitedArtifacts != null) {
				visitedArtifacts.clear();
				visitedArtifacts = null;
			}

			if (visitedProcesses != null) {
				visitedProcesses.clear();
				visitedProcesses = null;
			}

			if (visitedUsed != null) {
				visitedUsed.clear();
				visitedUsed = null;
			}

			if (visitedWasGeneratedBy != null) {
				visitedWasGeneratedBy.clear();
				visitedWasGeneratedBy = null;
			}

			if (visitedWasDerivedFrom != null) {
				visitedWasDerivedFrom.clear();
				visitedWasDerivedFrom = null;
			}

			if (visitedWasTriggeredBy != null) {
				visitedWasTriggeredBy.clear();
				visitedWasTriggeredBy = null;
			}

			if (visitedRegEntity != null) {
				visitedRegEntity.clear();
				visitedRegEntity = null;
			}

			if (getCountStatement != null) {
				getCountStatement.close();
				getCountStatement = null;
			}

			if (statement != null) {
				statement.close();
				statement = null;
			}

			if (getEventTimeStmt != null) {
				getEventTimeStmt.close();
				getEventTimeStmt = null;
			}

			if (getFileIDStmt != null) {
				getFileIDStmt.close();
				getFileIDStmt = null;
			}

			if (rs != null) {
				rs.close();
				rs = null;
			}

			if (resultSet != null) {
				resultSet.close();
				resultSet = null;
			}

			if (blockResultSet != null) {
				blockResultSet.close();
				blockResultSet = null;
			}

			if (collectionResultSet != null) {
				collectionResultSet.close();
				collectionResultSet = null;
			}

			if (fileResultSet != null) {
				fileResultSet.close();
				fileResultSet = null;
			}

			if (byteArrayInputStream != null) {
				byteArrayInputStream.close();
				byteArrayInputStream = null;
			}
		}

		l.info("Exiting getOPMGraphDocumentByDataID() with success");
		return opmGraphDoc;

	}

	/* This function retrieves data lifecycle annotations by event id. */
	public static EmbeddedAnnotation getDataLifecycleAnnotation(
			Connection connection, String eventID) throws SQLException {
		assert (connection != null);
		assert (eventID != null);
		l.info("Entering getDataLifecycleAnnotation");

		PreparedStatement dataLifecycleAnnotationStmt = null;
		ResultSet res = null;

		try {

			EmbeddedAnnotation embeddedAnnotation = EmbeddedAnnotation.Factory
					.newInstance();

			dataLifecycleAnnotationStmt = connection
					.prepareStatement(OPMSqlQuery.GET_DATA_LIFECYCLE_ANNOTATIONS_BY_ID);
			dataLifecycleAnnotationStmt.setString(1, eventID);

			res = dataLifecycleAnnotationStmt.executeQuery();

			while (res.next()) {

				Property property = embeddedAnnotation.addNewProperty();
				property.setUri("data-lifecycle-annotation/" + res.getString(5)
						+ "/" + res.getString(3));
				property.setValue(XmlObject.Factory.parse(res.getString(4)));
				embeddedAnnotation
						.setId(Common.DATA_LIFECYCLE_ANNOTATION_IDENTIFIER
								+ res.getString(1));
			}

			if (!embeddedAnnotation.isSetId()) {
				embeddedAnnotation = null;
			}

			dataLifecycleAnnotationStmt.close();
			res.close();
			l.info("Exiting getDataLifecycleAnnotation() with success");

			return embeddedAnnotation;
		} catch (SQLException e) {
			l.error("Exiting getDataLifecycleAnnotation() with error");
			l.error(e.toString());
			return null;
		} catch (XmlException e) {
			l.error("Exiting getDataLifecycleAnnotation() with error");
			l.error(e.toString());
			return null;
		} finally {

			if (dataLifecycleAnnotationStmt != null) {
				dataLifecycleAnnotationStmt.close();
				dataLifecycleAnnotationStmt = null;
			}

			if (res != null) {
				res.close();
				res = null;
			}
		}
	}

	/* This function retrieves execution level entity annotations by entity id. */
	public static EmbeddedAnnotation getExeEntityAnnotation(
			Connection connection, String dataObjectID, String entityID)
			throws SQLException {
		assert (connection != null);
		assert (dataObjectID != null);
		assert (entityID != null);
		l.info("Entering getEntityAnnotation()");

		PreparedStatement entityAnnotationStmt = null;
		ResultSet res = null;
		try {

			EmbeddedAnnotation embeddedAnnotation = EmbeddedAnnotation.Factory
					.newInstance();

			entityAnnotationStmt = connection
					.prepareStatement(OPMSqlQuery.GET_EXE_ENTITY_ANNOTATIONS_BY_ID);
			entityAnnotationStmt.setString(1, entityID);

			res = entityAnnotationStmt.executeQuery();

			while (res.next()) {

				Property property = embeddedAnnotation.addNewProperty();
				property.setUri("process-annotation/" + res.getString(5) + "/"
						+ res.getString(3));
				property.setValue(XmlObject.Factory.parse(res.getString(4)));
				embeddedAnnotation.setId(Common.PROCESS_ANNOTATION_IDENTIFIER
						+ res.getString(1));
			}

			if (!embeddedAnnotation.isSetId()) {
				embeddedAnnotation = null;
			}

			entityAnnotationStmt.close();
			res.close();
			l.info("Exiting getEntityAnnotation() with success");

			return embeddedAnnotation;
		} catch (SQLException e) {
			l.error("Exiting getEntityAnnotation() with error");
			l.error(e.toString());
			return null;
		} catch (XmlException e) {
			l.error("Exiting getEntityAnnotation() with error");
			l.error(e.toString());
			return null;
		} finally {

			if (entityAnnotationStmt != null) {
				entityAnnotationStmt.close();
				entityAnnotationStmt = null;
			}

			if (res != null) {
				res.close();
				res = null;
			}
		}
	}

	/* This function retrieves registry level entity annotations by entity id. */
	public static EmbeddedAnnotation getRegEntityAnnotation(
			Connection connection, String dataObjectID, String entityID)
			throws SQLException {
		assert (connection != null);
		assert (dataObjectID != null);
		assert (entityID != null);
		l.info("Entering getRegEntityAnnotation()");

		PreparedStatement entityAnnotationStmt = null;
		ResultSet res = null;

		try {

			EmbeddedAnnotation embeddedAnnotation = EmbeddedAnnotation.Factory
					.newInstance();

			entityAnnotationStmt = connection
					.prepareStatement(OPMSqlQuery.GET_REG_ENTITY_ANNOTATIONS_BY_ID);
			entityAnnotationStmt.setString(1, entityID);

			res = entityAnnotationStmt.executeQuery();

			while (res.next()) {

				Property property = embeddedAnnotation.addNewProperty();
				property.setUri("process-annotation/" + res.getString(5) + "/"
						+ res.getString(3));
				property.setValue(XmlObject.Factory.parse(res.getString(4)));
				embeddedAnnotation.setId(Common.PROCESS_ANNOTATION_IDENTIFIER
						+ res.getString(1));
			}

			if (!embeddedAnnotation.isSetId()) {
				embeddedAnnotation = null;
			}

			entityAnnotationStmt.close();
			res.close();
			l.info("Exiting getRegEntityAnnotation() with success");

			return embeddedAnnotation;
		} catch (SQLException e) {
			l.error("Exiting getRegEntityAnnotation() with error");
			l.error(e.toString());
			return null;
		} catch (XmlException e) {
			l.error("Exiting getRegEntityAnnotation() with error");
			l.error(e.toString());
			return null;
		} finally {

			if (entityAnnotationStmt != null) {
				entityAnnotationStmt.close();
				entityAnnotationStmt = null;
			}

			if (res != null) {
				res.close();
				res = null;
			}
		}
	}

	/* This function retrieves invocation annotations by entity id. */
	public static EmbeddedAnnotation getInvocationAnnotation(
			Connection connection, String dataObjectID, String invocationID)
			throws SQLException {
		assert (connection != null);
		assert (dataObjectID != null);
		assert (invocationID != null);
		l.info("Entering getInvocationAnnotation()");

		PreparedStatement invocationAnnotationStmt = null;
		ResultSet res = null;

		try {

			EmbeddedAnnotation embeddedAnnotation = EmbeddedAnnotation.Factory
					.newInstance();

			invocationAnnotationStmt = connection
					.prepareStatement(OPMSqlQuery.GET_INVOCATION_ANNOTATIONS_BY_ID);
			invocationAnnotationStmt.setString(1, invocationID);

			res = invocationAnnotationStmt.executeQuery();

			while (res.next()) {

				Property property = embeddedAnnotation.addNewProperty();
				property.setUri("invocation-annotation/" + res.getString(5)
						+ "/" + res.getString(3));
				property.setValue(XmlObject.Factory.parse(res.getString(4)));
				embeddedAnnotation
						.setId(Common.INVOCATION_ANNOTATION_IDENTIFIER
								+ res.getString(1));
			}

			if (!embeddedAnnotation.isSetId()) {
				embeddedAnnotation = null;
			}

			res.close();
			invocationAnnotationStmt.close();
			l.info("Exiting getInvocationAnnotation() with success");

			return embeddedAnnotation;
		} catch (SQLException e) {
			l.error("Exiting getInvocationAnnotation() with error");
			l.error(e.toString());
			return null;
		} catch (XmlException e) {
			l.error("Exiting getInvocationAnnotation() with error");
			l.error(e.toString());
			return null;
		} finally {

			if (invocationAnnotationStmt != null) {
				invocationAnnotationStmt.close();
				invocationAnnotationStmt = null;
			}

			if (res != null) {
				res.close();
				res = null;
			}
		}
	}

	/* This function retrieves data object annotations by data object id. */
	public static EmbeddedAnnotation getDataObjectAnnotation(
			Connection connection, String dataObjectID, String objectID)
			throws SQLException {
		assert (connection != null);
		assert (dataObjectID != null);
		assert (objectID != null);
		l.info("Entering getDataObjectAnnotation()");

		PreparedStatement dataObjectAnnotationStmt = null;
		ResultSet res = null;
		try {

			EmbeddedAnnotation embeddedAnnotation = EmbeddedAnnotation.Factory
					.newInstance();

			dataObjectAnnotationStmt = connection
					.prepareStatement(OPMSqlQuery.GET_DATA_OBJECT_ANNOTATIONS_BY_ID);
			dataObjectAnnotationStmt.setString(1, objectID);

			res = dataObjectAnnotationStmt.executeQuery();

			while (res.next()) {

				Property property = embeddedAnnotation.addNewProperty();
				property.setUri("artifact-annotation/" + res.getString(5) + "/"
						+ res.getString(3));
				property.setValue(XmlObject.Factory.parse(res.getString(4)));
				embeddedAnnotation.setId(Common.ARTIFACT_ANNOTATION_IDENTIFIER
						+ res.getString(1));
			}

			if (!embeddedAnnotation.isSetId()) {
				embeddedAnnotation = null;
			}

			dataObjectAnnotationStmt.close();
			res.close();
			l.info("Exiting getDataObjectAnnotation() with success");

			return embeddedAnnotation;
		} catch (SQLException e) {
			l.error("Exiting getDataObjectAnnotation() with error");
			l.error(e.toString());
			return null;
		} catch (XmlException e) {
			l.error("Exiting getDataObjectAnnotation() with error");
			l.error(e.toString());
			return null;
		} finally {

			if (dataObjectAnnotationStmt != null) {
				dataObjectAnnotationStmt.close();
				dataObjectAnnotationStmt = null;
			}

			if (res != null) {
				res.close();
				res = null;
			}
		}
	}
}