package edu.indiana.d2i.adaptor;

public class RuleApplicability {
	public static final int INVALID = 0;
	public static final int NEW = 1;
	public static final int CONTINUE = 2;
}
