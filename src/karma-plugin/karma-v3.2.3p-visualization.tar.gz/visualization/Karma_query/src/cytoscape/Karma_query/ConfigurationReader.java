/**
 * 
 */
package cytoscape.Karma_query;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.swing.JOptionPane;

import cytoscape.Cytoscape;

/**
 * @author peng Use java property reader to read the configuration
 */
public class ConfigurationReader {
	static String MessageConfigPath = "/config/karmaQueryConfig.txt";

	public static String serviceURL;
	public static String username;
	public static String password;
	public static String hostname;
	public static String hostport;
	public static String virtualhost;
	public static String exchangename;
	public static String queuename;
	public static String routingkey;

	private static ConfigurationReader instance = null;
	private static Properties properties;

	private ConfigurationReader(InputStream input) {
		try {
			properties = new Properties();
			properties.load(input);
		} catch (IOException e) {
			System.err.println("ERROR: Unable to load properties file ");
			e.printStackTrace(System.err);
			System.exit(-1);
		}
	}

	public static ConfigurationReader getInstance() {
		initialize();
		return instance;
	}

	public String getProperty(String propertyName) {
		return properties.getProperty(propertyName);
	}

	public static void store() {
		BufferedOutputStream output;
		try {
			// custom config file is stored at
			// "HOME/.cytoscape/config/config.file"
			String homeDir = System.getProperty("user.home");
			File customProFile = new File(homeDir + "/.cytoscape"
					+ MessageConfigPath);
			
			if(!customProFile.exists()){
				customProFile.getParentFile().mkdirs();
				customProFile.createNewFile();
			}

			// always write to custom config file
			output = new BufferedOutputStream(new FileOutputStream(
					customProFile));
			properties.setProperty("axis2.serviceURL", serviceURL);
			properties.setProperty("messaging.username", username);
			properties.setProperty("messaging.password", password);
			properties.setProperty("messaging.hostname", hostname);
			properties.setProperty("messaging.hostport", hostport);
			properties.setProperty("messaging.virtualhost", virtualhost);
			properties.setProperty("messaging.exchangename", exchangename);
			properties.setProperty("messaging.queuename", queuename);
			properties.setProperty("messaging.routingkey", routingkey);

			properties
					.store(
							output,
							"Properties for using Karma Query Plugin\n@author: Peng Chen (chenpeng@indiana.edu)\nInformation to use Axis Service and RabbitMQ messaging system");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void initialize() {
		if (instance != null)
			return;

		BufferedInputStream input;
		try {
			// custom config file is stored at
			// "HOME/.cytoscape/config/config.file"
			String homeDir = System.getProperty("user.home");
			File customProFile = new File(homeDir + "/.cytoscape"
					+ MessageConfigPath);

			if (customProFile.exists()) {
				input = new BufferedInputStream(new FileInputStream(
						customProFile));
			} else {
				// read default file from installation
				String url = ConfigurationReader.class.getResource(
						ConfigurationReader.class.getSimpleName() + ".class")
						.toString();
				String proFilePath = url.replaceFirst("jar:file:", "")
						.replaceFirst("[/\\\\][^/\\\\]+\\.jar!.*$", "/")
						+ MessageConfigPath;

				input = new BufferedInputStream(
						new FileInputStream(proFilePath));
			}

			instance = new ConfigurationReader(input);

			ConfigurationReader.serviceURL = instance
					.getProperty("axis2.serviceURL");
			ConfigurationReader.username = instance
					.getProperty("messaging.username");
			ConfigurationReader.password = instance
					.getProperty("messaging.password");
			ConfigurationReader.hostname = instance
					.getProperty("messaging.hostname");
			ConfigurationReader.hostport = instance
					.getProperty("messaging.hostport");
			ConfigurationReader.virtualhost = instance
					.getProperty("messaging.virtualhost");
			ConfigurationReader.exchangename = instance
					.getProperty("messaging.exchangename");
			ConfigurationReader.queuename = instance
					.getProperty("messaging.queuename");
			ConfigurationReader.routingkey = instance
					.getProperty("messaging.routingkey");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e.toString());
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e.toString());
		}
	}
}
