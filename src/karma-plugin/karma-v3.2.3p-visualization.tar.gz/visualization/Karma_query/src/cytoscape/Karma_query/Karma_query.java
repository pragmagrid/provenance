package cytoscape.Karma_query;

import java.awt.event.ActionEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedWriter;
import java.io.FileWriter;

import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import org.freehep.swing.ExtensionFileFilter;

import cytoscape.Cytoscape;
import cytoscape.GUI.QueryPanel;
import cytoscape.GUI.ServerConfigPanel;
import cytoscape.plugin.CytoscapePlugin;
import cytoscape.util.CytoscapeAction;

/**
 * @author Peng A simple plugin to get OPM xml from Karma database. Deploy this
 *         plugin (Karma_query.jar) to the plugins directory. An image icon
 *         (karma logo) will show up on the toolbar. Click on the icon will
 *         trigger a message box.
 */
public class Karma_query extends CytoscapePlugin {

	ServerConfigPanel scp = null;
	QueryPanel qp = null;
	static int response = -1;

	public static String filename;
	static private ConfigurationReader conf_reader;

	static int method = -1;

	protected ImageIcon icon_karma = new ImageIcon(getClass().getResource(
			"/karma.jpg"));

	public Karma_query() {

		// (1) Create an toolbarAction

		KarmaPluginToolBarAction karmaToolbarAction = new KarmaPluginToolBarAction(
				icon_karma, this);
		// (2) add the action to Cytoscape toolbar
		Cytoscape.getDesktop().getCyMenus().addCytoscapeAction(
				(CytoscapeAction) karmaToolbarAction);

		/*
		 * reading configuration
		 */

		conf_reader = ConfigurationReader.getInstance();
	}

	public class KarmaPluginToolBarAction extends CytoscapeAction implements
			WindowListener {

		/**
		 * 
		 */
		private static final long serialVersionUID = -7118436127661130349L;

		public KarmaPluginToolBarAction(ImageIcon icon, Karma_query myPlugin) {
			super("", icon);
			// Set SHORT_DESCRIPTION; used to create tool-tip
			this.putValue(Action.SHORT_DESCRIPTION, "Karma Client");
		}

		public void actionPerformed(ActionEvent e) {
			try {

				scp = new ServerConfigPanel(null);
				scp.setDefaultCloseOperation(scp.DISPOSE_ON_CLOSE);
				scp.addWindowListener(this);
				double x1 = Cytoscape.getDesktop().getX()
						+ Cytoscape.getDesktop().getWidth() / 3;
				double y1 = Cytoscape.getDesktop().getY()
						+ Cytoscape.getDesktop().getHeight() / 5;
				scp.setLocation((int) x1, (int) y1);

				scp.pack();
				scp.setVisible(true);

			} catch (Exception e1) {
				JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e1
						.toString());
			}

		}

		public boolean isInToolBar() {
			return true;
		}

		public boolean isInMenuBar() {
			return true;
		}

		@Override
		public void windowActivated(WindowEvent arg0) {
		}

		@Override
		public void windowClosing(WindowEvent arg0) {
		}

		@Override
		public void windowClosed(WindowEvent arg0) {
			if (!scp.createNewGraph)
				return;

			qp = new QueryPanel(null);
			qp.addWindowListener(new workflowQueryListener());
			qp.setDefaultCloseOperation(qp.DISPOSE_ON_CLOSE);
			double x = Cytoscape.getDesktop().getX()
					+ Cytoscape.getDesktop().getWidth() / 3;
			double y = Cytoscape.getDesktop().getY()
					+ Cytoscape.getDesktop().getHeight() / 3;
			qp.setLocation((int) x, (int) y);

			qp.setVisible(true);
		}

		@Override
		public void windowDeactivated(WindowEvent arg0) {
		}

		@Override
		public void windowDeiconified(WindowEvent arg0) {
		}

		@Override
		public void windowIconified(WindowEvent arg0) {
		}

		@Override
		public void windowOpened(WindowEvent arg0) {
		}
	}

	class workflowQueryListener implements WindowListener {

		@Override
		public void windowActivated(WindowEvent arg0) {
		}

		@Override
		public void windowClosed(WindowEvent arg0) {
			try {

				String graph_response = null;
				String graph = null;

				if (!qp.doRetrieval)
					return;

				if (scp.useAxis2) {
					KarmaAxis2Query axis2Tester = new KarmaAxis2Query(
							ConfigurationReader.serviceURL);
					if (qp.withAnnotation)
						graph_response = axis2Tester
								.getWorkflowGraphWithAnnotation(qp.ID);
					else
						graph_response = axis2Tester
								.getWorkflowGraphWithoutAnnotation(qp.ID);
				} else if (scp.useRabbitmq) {
					RabbitmqQuery rq = new RabbitmqQuery();
					if (qp.withAnnotation)
						graph_response = rq
								.getWorkflowGraphWithAnnotation(qp.ID);
					else
						graph_response = rq
								.getWorkflowGraphWithoutAnnotation(qp.ID);
				} else
					return;

				/*
				 * Re-organize the result xml into a opm xml
				 */
				int start = graph_response.lastIndexOf("<v1:opmGraph");
				int end = graph_response.lastIndexOf("<");

				if (start == -1 || end == -1) {
					graph = graph_response;

					JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
							"An invalid OPM graph returned");
				} else
					graph = graph_response.substring(start, end);

				JFileChooser fileChooser = new JFileChooser();

				ExtensionFileFilter filter = new ExtensionFileFilter();
				filter.addExtension("xml");
				filter.setDescription("xml files");
				fileChooser.setFileFilter(filter);

				// if set to null, will be displayed in the middle of window
				int returnVal = fileChooser.showSaveDialog(Cytoscape
						.getDesktop());
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					String filePath = fileChooser.getSelectedFile()
							.getAbsolutePath();
					String save_file_name = filePath;

					FileWriter fw;
					if (save_file_name.contains(".xml"))
						fw = new FileWriter(save_file_name);
					else
						fw = new FileWriter(save_file_name + ".xml");
					BufferedWriter bw = new BufferedWriter(fw);
					bw.write(graph);
					bw.flush();
					bw.close();
					fw.close();
				}

			} catch (Exception e1) {
				JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e1
						.toString());
			}
		}

		@Override
		public void windowClosing(WindowEvent arg0) {
		}

		@Override
		public void windowDeactivated(WindowEvent arg0) {
		}

		@Override
		public void windowDeiconified(WindowEvent arg0) {
		}

		@Override
		public void windowIconified(WindowEvent arg0) {
		}

		@Override
		public void windowOpened(WindowEvent arg0) {
		}

	}
}