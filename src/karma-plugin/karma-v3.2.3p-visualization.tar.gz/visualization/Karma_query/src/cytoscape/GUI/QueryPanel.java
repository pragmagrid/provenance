package cytoscape.GUI;

import javax.swing.JPanel;
import java.awt.Frame;
import java.awt.BorderLayout;
import javax.swing.JDialog;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.concurrent.Semaphore;

import javax.swing.ButtonGroup;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.BoxLayout;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

public class QueryPanel extends JDialog {
	public boolean withAnnotation = false;
	public String ID = null;

	public boolean isWorkflowGraph = true;
	public boolean isProcessDetail = false;
	public boolean isDataProvenanceGraph = false;

	public boolean doRetrieval = false;
	public boolean waitingForInput = true;
	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JPanel jPanel = null;
	private JPanel jPanel1 = null;
	private JPanel jPanel2 = null;
	private JPanel jPanel3 = null;
	private JLabel jLabel = null;
	private JRadioButton jRadioButton = null;
	private JRadioButton jRadioButton1 = null;
	private JTextField jTextField = null;
	private JLabel jLabel1 = null;
	private JPanel jPanel4 = null;
	private JLabel jLabel2 = null;
	private JButton jButton = null;
	private JLabel jLabel3 = null;
	private JButton jButton1 = null;
	private JPanel jPanel5 = null;
	private JRadioButton jRadioButton3 = null;
	private JRadioButton jRadioButton4 = null;
	private JRadioButton jRadioButton2 = null;
	private JRadioButton jRadioButton31 = null;
	private JRadioButton jRadioButton32 = null;

	/**
	 * @param owner
	 */
	public QueryPanel(Frame owner) {
		super(owner);
		initialize();

	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(400, 140);
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		this.setContentPane(getJContentPane());
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			GridLayout gridLayout = new GridLayout();
			gridLayout.setRows(1);
			jContentPane = new JPanel();
			jContentPane.setLayout(gridLayout);
			jContentPane.add(getJPanel(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel() {
		if (jPanel == null) {
			GridLayout gridLayout1 = new GridLayout();
			gridLayout1.setRows(4);
			jPanel = new JPanel();
			jPanel.setLayout(gridLayout1);
			jPanel.add(getJPanel2(), null);
			jPanel.add(getJPanel1(), null);
			jPanel.add(getJPanel3(), null);
			// jPanel.add(getJPanel5(), null);
			jPanel.add(getJPanel42(), null);
		}
		return jPanel;
	}

	/**
	 * This method initializes jPanel1
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel1() {
		if (jPanel1 == null) {
			jPanel1 = new JPanel();
			jPanel1.setLayout(new BorderLayout());
			ButtonGroup group = new ButtonGroup();
			group.add(getJRadioButton());
			group.add(getJRadioButton1());
			group.setSelected(getJRadioButton().getModel(), true);
			jPanel1.add(getJRadioButton(), BorderLayout.WEST);
			jPanel1.add(getJRadioButton1(), BorderLayout.EAST);
		}
		return jPanel1;
	}

	/**
	 * This method initializes jPanel2
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel2() {
		if (jPanel2 == null) {
			jLabel = new JLabel();
			jLabel.setText("enter ID here");
			jPanel2 = new JPanel();
			jPanel2.setLayout(new BorderLayout());
			jPanel2.add(jLabel, BorderLayout.WEST);
			jPanel2.add(getJTextField(), BorderLayout.CENTER);
		}
		return jPanel2;
	}

	/**
	 * This method initializes jPanel3
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel3() {
		if (jPanel3 == null) {
			jLabel1 = new JLabel();
			jLabel1
					.setText("Note: Retrieval with Annotation takes longer");
			jPanel3 = new JPanel();
			jPanel3.setLayout(new BorderLayout());
			jPanel3.add(jLabel1, BorderLayout.NORTH);
		}
		return jPanel3;
	}

	/**
	 * This method initializes jRadioButton
	 * 
	 * @return javax.swing.JRadioButton
	 */
	private JRadioButton getJRadioButton() {
		if (jRadioButton == null) {
			jRadioButton = new JRadioButton("With Annotation");
		}
		return jRadioButton;
	}

	/**
	 * This method initializes jRadioButton1
	 * 
	 * @return javax.swing.JRadioButton
	 */
	private JRadioButton getJRadioButton1() {
		if (jRadioButton1 == null) {
			jRadioButton1 = new JRadioButton("Without Annotation");
		}
		return jRadioButton1;
	}

	/**
	 * This method initializes jTextField
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getJTextField() {
		if (jTextField == null) {
			jTextField = new JTextField();
		}
		return jTextField;
	}

	/**
	 * This method initializes jPanel4
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel4() {
		if (jPanel4 == null) {
			GridLayout gridLayout2 = new GridLayout();
			gridLayout2.setRows(1);
		}
		return jPanel4;
	}

	/**
	 * This method initializes jPanel4
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel42() {
		if (jPanel4 == null) {
			jLabel3 = new JLabel();
			jLabel2 = new JLabel();
			GridLayout gridLayout3 = new GridLayout();
			gridLayout3.setRows(1);
			gridLayout3.setHgap(20);
			jPanel4 = new JPanel();
			jPanel4.setLayout(gridLayout3);
			jPanel4.setEnabled(false);
			jPanel4.add(jLabel2, null);
			jPanel4.add(getJButton(), null);
			jPanel4.add(getJButton1(), null);
			jPanel4.add(jLabel3, null);

			ActionListener a = new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					if (ae.getSource() == getJButton()) {
						System.out.println("You clicked the JButton1");
						if (jRadioButton.isSelected())
							withAnnotation = true;
//						if (jRadioButton2.isSelected())
//							isWorkflowGraph = true;
//						if (jRadioButton31.isSelected())
//							isProcessDetail = true;
//						if (jRadioButton32.isSelected())
//							isDataProvenanceGraph = true;

						ID = jTextField.getText();
						doRetrieval = true;
					} else if (ae.getSource() == getJButton1()) {
						System.out.println("You clicked the JButton2");
					}

					dispose();
				}

			};
			getJButton().addActionListener(a);
			getJButton1().addActionListener(a);
		}
		return jPanel4;
	}

	/**
	 * This method initializes jButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton("OK");
		}
		return jButton;
	}

	/**
	 * This method initializes jButton1
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButton1() {
		if (jButton1 == null) {
			jButton1 = new JButton("Cancel");
		}
		return jButton1;
	}

	// overwrite the dispose function to release the semaphore
	public void dispose() {
		// sem.release();
		waitingForInput = false;
		super.dispose();
	}

	/**
	 * This method initializes jPanel5
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel5() {
		if (jPanel5 == null) {
			GridLayout gridLayout4 = new GridLayout();
			gridLayout4.setRows(1);
			jPanel5 = new JPanel();
			jPanel5.setLayout(gridLayout4);
			ButtonGroup group = new ButtonGroup();
			group.add(getJRadioButton2());
			group.add(getJRadioButton31());
			group.add(getJRadioButton32());
			jPanel5.add(getJRadioButton2(), null);
			jPanel5.add(getJRadioButton31(), null);
			jPanel5.add(getJRadioButton32(), null);

			getJRadioButton2().setSelected(true);

			ActionListener a = new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					if (ae.getSource() == getJRadioButton2()) {
						System.out.println("You clicked the JButton2");

						getJRadioButton().setEnabled(true);
						getJRadioButton1().setEnabled(true);

					} else if (ae.getSource() == getJRadioButton31()) {
						System.out.println("You clicked the JButton31");
						getJRadioButton().setEnabled(false);
						getJRadioButton1().setEnabled(false);
					} else if (ae.getSource() == getJRadioButton32()) {
						System.out.println("You clicked the JButton31");
						getJRadioButton().setEnabled(false);
						getJRadioButton1().setEnabled(false);
					}

				}

			};

			getJRadioButton2().addActionListener(a);
			getJRadioButton31().addActionListener(a);
			getJRadioButton32().addActionListener(a);

		}
		return jPanel5;
	}

	/**
	 * This method initializes jRadioButton2
	 * 
	 * @return javax.swing.JRadioButton
	 */
	private JRadioButton getJRadioButton2() {
		if (jRadioButton2 == null) {
			jRadioButton2 = new JRadioButton("workflowGraph");
		}
		return jRadioButton2;
	}

	/**
	 * This method initializes jRadioButton31
	 * 
	 * @return javax.swing.JRadioButton
	 */
	private JRadioButton getJRadioButton31() {
		if (jRadioButton31 == null) {
			jRadioButton31 = new JRadioButton("processDetail");
		}
		return jRadioButton31;
	}

	/**
	 * This method initializes jRadioButton32
	 * 
	 * @return javax.swing.JRadioButton
	 */
	private JRadioButton getJRadioButton32() {
		if (jRadioButton32 == null) {
			jRadioButton32 = new JRadioButton("dataProvenanceGraph");
		}
		return jRadioButton32;
	}

} // @jve:decl-index=0:visual-constraint="197,39"
