package cytoscape.OPM_visualization.eventListener;

import java.util.Iterator;
import java.util.Set;

import cytoscape.CyEdge;
import cytoscape.CyNetwork;
import cytoscape.CyNode;
import cytoscape.Cytoscape;
import cytoscape.data.SelectEvent;
import cytoscape.data.SelectEventListener;
import cytoscape.view.CyNetworkView;

/**
 * @author Peng
 * */

/*
 * The action taken when the node is selected, not used now
 */
public class MyNodeSelectEventListener implements SelectEventListener {
	public void onSelectEvent(SelectEvent event) {
		CyNetwork cyNetwork = Cytoscape.getCurrentNetwork();
		CyNetworkView view = Cytoscape.getCurrentNetworkView();
		if (event.getEventType()) {
			switch (event.getTargetType()) {
			case SelectEvent.NODE_SET:

				Set<CyNode> nodes_set = cyNetwork.getSelectedNodes();
				Iterator<CyNode> itr_n = nodes_set.iterator();
				CyNode node = itr_n.next();

				int[] edges = cyNetwork.getAdjacentEdgeIndicesArray(node
						.getRootGraphIndex(), true, true, false);
				for (int i = 0; i < edges.length; i++) {
					view.getEdgeView(edges[i]).select();
				}
				break;
			case SelectEvent.EDGE_SET:

				Set<CyEdge> edges_set = cyNetwork.getSelectedEdges();
				Iterator<CyEdge> itr_e = edges_set.iterator();
				CyEdge edge = itr_e.next();

				view.getNodeView(edge.getSource()).select();
				view.getNodeView(edge.getTarget()).select();

				break;
			default:

			}

		}
	}
}
