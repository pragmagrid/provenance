package cytoscape.OPM_visualization.actionListener;

import giny.model.Edge;
import giny.model.Node;

import java.awt.event.InputEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Iterator;
import java.util.Set;

import cytoscape.CyEdge;
import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.data.CyAttributes;

/**
 * @author Peng
 */

/*
 * An action listener, when double click on the edge, it will show its subgraph
 * if it has
 */

public class EdgeExpendAction extends MouseAdapter {
	@Override
	public void mousePressed(MouseEvent mouseEvent) {
		int modifiers = mouseEvent.getModifiers();
		if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK
				&& mouseEvent.getClickCount() == 2) {
			CyNetwork cyNetwork = Cytoscape.getCurrentNetwork();
			Set<CyEdge> edges_set = cyNetwork.getSelectedEdges();

			// make sure if some node has been clicked
			if (edges_set.isEmpty())
				return;

			Iterator<CyEdge> itr_n = edges_set.iterator();
			CyEdge temp = itr_n.next();

			CyAttributes cyEdgeAttrs = Cytoscape.getEdgeAttributes();
			String edge_id = temp.getIdentifier();
			if (edge_id.contains("wasTriggeredBy")) {
				Node source = temp.getSource();
				Node target = temp.getTarget();

				int[] source_edges = cyNetwork.getRootGraph()
						.getAdjacentEdgeIndicesArray(
								source.getRootGraphIndex(), false, false, true);
				for (int i = 0; i < source_edges.length; i++) {
					Edge edge = cyNetwork.getRootGraph().getEdge(
							source_edges[i]);

					if (!cyEdgeAttrs.getStringAttribute(edge.getIdentifier(),
							"interaction").equalsIgnoreCase("used"))
						continue;

					Node node = edge.getTarget();
					int[] second_edges = cyNetwork.getRootGraph()
							.getAdjacentEdgeIndicesArray(
									node.getRootGraphIndex(), false, false,
									true);
					boolean isExpanded = false;
					for (int j = 0; j < second_edges.length; j++) {
						Edge second_edge = cyNetwork.getRootGraph().getEdge(
								second_edges[j]);

						if (!cyEdgeAttrs.getStringAttribute(
								second_edge.getIdentifier(), "interaction")
								.equalsIgnoreCase("wasGeneratedBy"))
							continue;

						Node second_node = second_edge.getTarget();

						if (second_node.getRootGraphIndex() == target
								.getRootGraphIndex()) {

							Node res1 = cyNetwork.restoreNode(node);
							Edge res2 = cyNetwork.restoreEdge(edge);
							Edge res3 = cyNetwork.restoreEdge(second_edge);

							if (res1 != null && res2 != null && res3 != null) {
								isExpanded = true;

								double x = (Cytoscape.getCurrentNetworkView()
										.getNodeView(source).getXPosition() + Cytoscape
										.getCurrentNetworkView().getNodeView(
												target).getXPosition()) / 2;
								double y = (Cytoscape.getCurrentNetworkView()
										.getNodeView(source).getYPosition() + Cytoscape
										.getCurrentNetworkView().getNodeView(
												target).getYPosition()) / 2;
								Cytoscape.getCurrentNetworkView().getNodeView(
										node).setXPosition(x);
								Cytoscape.getCurrentNetworkView().getNodeView(
										node).setYPosition(y);
							}
						}
					}

					if (isExpanded) {
						cyNetwork.removeEdge(temp.getRootGraphIndex(), true);
						Cytoscape.getCurrentNetworkView().redrawGraph(true,
								true);
						break;
					}
				}
			} else if (edge_id.contains("wasDerivedFrom")) {
				Node source = temp.getSource();
				Node target = temp.getTarget();

				int[] source_edges = cyNetwork.getRootGraph()
						.getAdjacentEdgeIndicesArray(
								source.getRootGraphIndex(), false, false, true);
				for (int i = 0; i < source_edges.length; i++) {
					Edge edge = cyNetwork.getRootGraph().getEdge(
							source_edges[i]);

					if (!cyEdgeAttrs.getStringAttribute(edge.getIdentifier(),
							"interaction").equalsIgnoreCase("wasGeneratedBy"))
						continue;

					Node node = edge.getTarget();
					int[] second_edges = cyNetwork.getRootGraph()
							.getAdjacentEdgeIndicesArray(
									node.getRootGraphIndex(), false, false,
									true);
					boolean isExpanded = false;
					for (int j = 0; j < second_edges.length; j++) {
						Edge second_edge = cyNetwork.getRootGraph().getEdge(
								second_edges[j]);

						if (!cyEdgeAttrs.getStringAttribute(
								second_edge.getIdentifier(), "interaction")
								.equalsIgnoreCase("used"))
							continue;

						Node second_node = second_edge.getTarget();

						if (second_node.getRootGraphIndex() == target
								.getRootGraphIndex()) {

							Node res1 = cyNetwork.restoreNode(node);
							Edge res2 = cyNetwork.restoreEdge(edge);
							Edge res3 = cyNetwork.restoreEdge(second_edge);

							if (res1 != null && res2 != null && res3 != null) {
								isExpanded = true;

								double x = (Cytoscape.getCurrentNetworkView()
										.getNodeView(source).getXPosition() + Cytoscape
										.getCurrentNetworkView().getNodeView(
												target).getXPosition()) / 2;
								double y = (Cytoscape.getCurrentNetworkView()
										.getNodeView(source).getYPosition() + Cytoscape
										.getCurrentNetworkView().getNodeView(
												target).getYPosition()) / 2;
								Cytoscape.getCurrentNetworkView().getNodeView(
										node).setXPosition(x);
								Cytoscape.getCurrentNetworkView().getNodeView(
										node).setYPosition(y);
							}

						}
					}

					if (isExpanded) {
						cyNetwork.removeEdge(temp.getRootGraphIndex(), true);
						Cytoscape.getCurrentNetworkView().redrawGraph(true,
								true);
						break;
					}
				}
			}

		}
	}

}
