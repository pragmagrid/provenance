package cytoscape.OPM_visualization.eventListener;

import giny.view.NodeView;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

import cytoscape.OPM_visualization.actionListener.ClusterAction;
import cytoscape.OPM_visualization.actionListener.CompressArtifactAction;
import cytoscape.OPM_visualization.actionListener.CompressProcessAction;
import cytoscape.OPM_visualization.actionListener.DCA_ThresholdSetting;
import cytoscape.OPM_visualization.actionListener.DataForwardGraphAction;
import cytoscape.OPM_visualization.actionListener.DataProvenanceHistoryGraphAction;
import cytoscape.OPM_visualization.actionListener.DocumentAction;
import cytoscape.OPM_visualization.actionListener.GetAssociatedWorkflowGraph;
import cytoscape.OPM_visualization.actionListener.LoadDetailAction;
import cytoscape.OPM_visualization.actionListener.NodeLabelExtractor;
import cytoscape.OPM_visualization.movie.Movie;
import cytoscape.OPM_visualization.movie.MovieActionOnTime;
import cytoscape.OPM_visualization.movie.MovieActionOnTimeStep;

import ding.view.NodeContextMenuListener;

public class MyNodeContextMenuListener implements NodeContextMenuListener {
	public void addNodeContextMenuItems(NodeView nodeView, JPopupMenu menu) {
		JMenuItem dataProvenanceMenuItem = new JMenuItem(
				"Data Provenance History");
		JMenuItem dataForwardMenuItem = new JMenuItem("Data Forward Graph");
		JMenuItem loadDetailMenuItem = new JMenuItem("Load Detail Info");
		JMenuItem associatedWorkflowGraphMenuItem = new JMenuItem(
				"Get Associated Workflow Graph");

		JMenuItem compressProcessMenuItem = new JMenuItem("Compress Processes");
		JMenuItem compressArtifactMenuItem = new JMenuItem("Compress Artifacts");
		JMenuItem documentMenuItem = new JMenuItem("Export OPM");
		JMenuItem myMenuItem = new JMenuItem("Cluster Neighbors");
		JMenu movieMenuItem = new JMenu("Play Movie");
		JMenuItem movieMenuItemOnTimeStep = new JMenuItem("timestep");
		JMenuItem movieMenuItemOnTime = new JMenuItem("time");
		JMenuItem movieMenuItemSetInterval = new JMenuItem("Set time interval");
		JMenuItem MenuItemSetMacthingThreshold = new JMenuItem(
				"Set matching threshold");
		JMenuItem labelMenuItem = new JMenuItem("Assgin Short Label");

		dataProvenanceMenuItem
				.addActionListener(new DataProvenanceHistoryGraphAction(
						nodeView));
		dataForwardMenuItem.addActionListener(new DataForwardGraphAction(
				nodeView));
		loadDetailMenuItem.addActionListener(new LoadDetailAction(nodeView));
		associatedWorkflowGraphMenuItem
				.addActionListener(new GetAssociatedWorkflowGraph(nodeView));
		compressProcessMenuItem.addActionListener(new CompressProcessAction(
				nodeView));
		compressArtifactMenuItem.addActionListener(new CompressArtifactAction(
				nodeView));
		documentMenuItem.addActionListener(new DocumentAction(nodeView));
		myMenuItem.addActionListener(new ClusterAction(nodeView));
		movieMenuItemOnTimeStep.addActionListener(new MovieActionOnTimeStep(
				nodeView));
		movieMenuItemOnTime.addActionListener(new MovieActionOnTime(nodeView));
		movieMenuItemSetInterval.addActionListener(new Movie());
		MenuItemSetMacthingThreshold.addActionListener(new DCA_ThresholdSetting());
		labelMenuItem.addActionListener(new NodeLabelExtractor(nodeView));

		if (menu == null) {
			menu = new JPopupMenu();
		}

		menu.add(dataProvenanceMenuItem);
		menu.add(dataForwardMenuItem);
		menu.add(loadDetailMenuItem);
		menu.add(associatedWorkflowGraphMenuItem);
		menu.add(compressProcessMenuItem);
		menu.add(compressArtifactMenuItem);
		menu.add(documentMenuItem);
		menu.add(myMenuItem);
		menu.add(movieMenuItem);
		movieMenuItem.add(movieMenuItemOnTimeStep);
		movieMenuItem.add(movieMenuItemOnTime);
		movieMenuItem.add(movieMenuItemSetInterval);
		menu.add(MenuItemSetMacthingThreshold);
		menu.add(labelMenuItem);
	}
}
