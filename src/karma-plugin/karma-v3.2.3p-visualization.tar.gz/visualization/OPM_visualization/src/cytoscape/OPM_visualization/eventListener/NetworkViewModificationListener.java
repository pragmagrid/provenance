package cytoscape.OPM_visualization.eventListener;

import giny.view.GraphViewChangeEvent;
import giny.view.GraphViewChangeListener;

public class NetworkViewModificationListener implements GraphViewChangeListener{

	@Override
	public void graphViewChanged(GraphViewChangeEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println("GraphViewChangeEvent: "+arg0.toString());
	}

}
