package cytoscape.OPM_visualization.eventListener;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.InputEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextPane;
import javax.swing.border.TitledBorder;

import cytoscape.CyNetwork;
import cytoscape.CyNode;
import cytoscape.Cytoscape;
import cytoscape.data.CyAttributes;
import cytoscape.view.CyNetworkView;
import cytoscape.view.NetworkViewManager;

public class MatchedNodesAttributeViewListener extends MouseAdapter {
	@Override
	public void mousePressed(MouseEvent mouseEvent) {
		int modifiers = mouseEvent.getModifiers();
		if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK
				&& mouseEvent.getClickCount() == 2) {
			CyNetwork cyNetwork = Cytoscape.getCurrentNetwork();
			// CyNetworkView view = Cytoscape.getCurrentNetworkView();
			Set<CyNode> nodes_set = cyNetwork.getSelectedNodes();

			// make sure if some node has been clicked
			if (nodes_set.isEmpty())
				return;

			Iterator<CyNode> itr_n = nodes_set.iterator();
			CyNode node_1 = itr_n.next();

			CyAttributes cyNodeAttributes = Cytoscape.getNodeAttributes();

			String[] attr_name = cyNodeAttributes.getAttributeNames();
			Arrays.sort(attr_name);

			// NodeView nv = view.getNodeView(node);

			// To see if this is the abstract node
			String node_id_1 = node_1.getIdentifier();
			if (node_id_1.contains("SubGraph")) {
				CyNetwork tmp_nw;

				tmp_nw = (CyNetwork) node_1.getNestedNetwork();
				NetworkViewManager nm = Cytoscape.getDesktop()
						.getNetworkViewManager();
				CyNetworkView nv = Cytoscape.getNetworkView(tmp_nw
						.getIdentifier());

				try {
					nm.getInternalFrame(nv).show();
					nm.getInternalFrame(nv).setSelected(true);

				} catch (Exception e1) {
					JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e1
							.toString());
				}

			} else {

				JFrame frame_1 = new JFrame("Node Attributes 1");
				try {
					// frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

					frame_1.setLocation(mouseEvent.getXOnScreen(), mouseEvent
							.getYOnScreen());

					int length = 0;

					JPanel panel_1 = new JPanel();
					panel_1.setLayout(new BoxLayout(panel_1, BoxLayout.Y_AXIS));

					/*
					 * hard code to rearrange the order of attributes
					 */
					List<JSplitPane> other1_jspanels = new ArrayList<JSplitPane>();
					List<JSplitPane> other2_jspanels = new ArrayList<JSplitPane>();

					for (int i = 0; i < attr_name.length; i++) {
						if (attr_name[i].contains("node_label")
								|| attr_name[i].contains("_reg_")) {
							// do not show the node_label attribute
							continue;
						}

						/*
						 * Skip some attributes
						 */
						if (attr_name[i].contains("detailLevel")
								|| attr_name[i].contains("workflowNodeID")
								|| attr_name[i].contains("timestep")
								|| attr_name[i].contains("Account")
								|| attr_name[i].contains("matching-node-id")
								|| attr_name[i].contains("matching-graph-id")
								|| attr_name[i].contains("sub-graph-match")) {
							// do not show the node_label attribute
							continue;
						}

						JLabel jlabel = new JLabel(attr_name[i]);
						jlabel.setForeground(Color.BLUE);
						jlabel.setSize(40, 80);
						// jlabel.setBorder(BorderFactory
						// .createLineBorder(Color.black));

						Object obj_attr = cyNodeAttributes.getAttribute(node_1
								.getIdentifier(), attr_name[i]);
						if (obj_attr != null) {
							JTextPane txtMyTextPane = new JTextPane();
							txtMyTextPane.setText(obj_attr.toString());
							txtMyTextPane.setBackground(null);
							txtMyTextPane.setEditable(false);
							txtMyTextPane.setBorder(null);
							txtMyTextPane
									.setAlignmentX(Component.LEFT_ALIGNMENT);

							JSplitPane panel_2 = new JSplitPane(
									JSplitPane.HORIZONTAL_SPLIT, jlabel,
									txtMyTextPane);
							panel_2.setBorder(BorderFactory
									.createLineBorder(Color.black));
							panel_2.setResizeWeight(0.5);
							panel_2.setDividerLocation(100);
							panel_2.setDividerSize(1);

							if (attr_name[i].contains("canonicalName")
									|| attr_name[i].contains("workflowID")
									|| attr_name[i].contains("serviceID")) {
								panel_1.add(panel_2);
								length++;
								continue;
							}

							if (attr_name[i].contains("type")
									|| attr_name[i].contains("Time")) {
								other1_jspanels.add(panel_2);
								continue;
							}

							other2_jspanels.add(panel_2);
						}

					}

					for (JSplitPane other : other1_jspanels) {
						panel_1.add(other);
						length++;
					}

					for (JSplitPane other : other2_jspanels) {
						panel_1.add(other);
						length++;
					}

					// frame.add(panel_1, BorderLayout.CENTER);
					panel_1.setBorder(BorderFactory.createTitledBorder(null,
							"Workflow Info",
							TitledBorder.DEFAULT_JUSTIFICATION,
							TitledBorder.DEFAULT_POSITION, new Font("Dialog",
									Font.BOLD, 12), new Color(51, 51, 51)));

					JPanel reg_panel = new JPanel();
					reg_panel.setLayout(new BoxLayout(reg_panel,
							BoxLayout.Y_AXIS));

					for (int i = 0; i < attr_name.length; i++) {
						if (attr_name[i].contains("node_label")
								|| !attr_name[i].contains("_reg_")) {
							// do not show the node_label attribute
							continue;
						}

						/*
						 * Skip some attributes
						 */
						if (attr_name[i].contains("_reg_subtype")
								|| attr_name[i].contains("_reg_creationTime")) {
							// do not show the node_label attribute
							continue;
						}

						JLabel jlabel = new JLabel(attr_name[i]);
						jlabel.setForeground(Color.BLUE);
						jlabel.setSize(40, 80);

						Object obj_attr = cyNodeAttributes.getAttribute(node_1
								.getIdentifier(), attr_name[i]);
						if (obj_attr != null) {
							JTextPane txtMyTextPane = new JTextPane();
							txtMyTextPane.setText(obj_attr.toString());
							txtMyTextPane.setBackground(null);
							txtMyTextPane.setEditable(false);
							txtMyTextPane.setBorder(null);
							txtMyTextPane
									.setAlignmentX(Component.LEFT_ALIGNMENT);

							JSplitPane panel_2 = new JSplitPane(
									JSplitPane.HORIZONTAL_SPLIT, jlabel,
									txtMyTextPane);
							panel_2.setBorder(BorderFactory
									.createLineBorder(Color.black));
							panel_2.setResizeWeight(0.5);
							panel_2.setDividerLocation(100);
							panel_2.setDividerSize(1);

							reg_panel.add(panel_2);
							length++;
						}

					}

					JScrollPane jsp = new JScrollPane(panel_1);
					frame_1.add(jsp, BorderLayout.CENTER);

					frame_1.add(reg_panel, BorderLayout.SOUTH);
					reg_panel.setBorder(BorderFactory.createTitledBorder(null,
							"Registry Info",
							TitledBorder.DEFAULT_JUSTIFICATION,
							TitledBorder.DEFAULT_POSITION, new Font("Dialog",
									Font.BOLD, 12), new Color(51, 51, 51)));

					length = length > 12 ? 12 : length;
					frame_1.setSize(400, 12 * length + 80);
					frame_1.setVisible(true);
					frame_1.getRootPane().setVisible(true);
				} catch (Exception e) {
					JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e
							.toString());
				}

				JFrame frame_2 = new JFrame("Node Attributes 2");
				try {
					Object obj_attr = cyNodeAttributes.getAttribute(node_1
							.getIdentifier(), "matching-graph-id");
					if (obj_attr == null) {
						JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
								"no matching graph");
						return;
						// throw (new Exception("no matching graph"));
					}

					cyNetwork = Cytoscape.getNetwork(obj_attr.toString());

					// nodes_set = cyNetwork.getSelectedNodes();
					cyNetwork.unselectAllNodes();

					obj_attr = cyNodeAttributes.getAttribute(node_1
							.getIdentifier(), "matching-node-id");
					if (obj_attr == null)
						throw (new Exception("no matching node"));

					CyNode node_2 = (CyNode) cyNetwork.getNode(Integer
							.parseInt(obj_attr.toString()));
					cyNetwork.setSelectedNodeState(node_2, true);
					Cytoscape.getNetworkView(cyNetwork.getIdentifier())
							.updateView();

					// frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

					frame_2.setLocation(mouseEvent.getXOnScreen()
							+ frame_1.getWidth(), mouseEvent.getYOnScreen());

					int length = 0;

					JPanel panel_1 = new JPanel();
					panel_1.setLayout(new BoxLayout(panel_1, BoxLayout.Y_AXIS));

					/*
					 * hard code to rearrange the order of attributes
					 */
					List<JSplitPane> other1_jspanels = new ArrayList<JSplitPane>();
					List<JSplitPane> other2_jspanels = new ArrayList<JSplitPane>();

					for (int i = 0; i < attr_name.length; i++) {
						if (attr_name[i].contains("node_label")
								|| attr_name[i].contains("_reg_")) {
							// do not show the node_label attribute
							continue;
						}

						/*
						 * Skip some attributes
						 */
						if (attr_name[i].contains("detailLevel")
								|| attr_name[i].contains("workflowNodeID")
								|| attr_name[i].contains("timestep")
								|| attr_name[i].contains("Account")
								|| attr_name[i].contains("matching-node-id")
								|| attr_name[i].contains("matching-graph-id")
								|| attr_name[i].contains("sub-graph-match")) {
							// do not show the node_label attribute
							continue;
						}

						JLabel jlabel = new JLabel(attr_name[i]);
						jlabel.setForeground(Color.BLUE);
						jlabel.setSize(40, 80);
						// jlabel.setBorder(BorderFactory
						// .createLineBorder(Color.black));

						obj_attr = cyNodeAttributes.getAttribute(node_2
								.getIdentifier(), attr_name[i]);
						if (obj_attr != null) {
							JTextPane txtMyTextPane = new JTextPane();
							txtMyTextPane.setText(obj_attr.toString());
							txtMyTextPane.setBackground(null);
							txtMyTextPane.setEditable(false);
							txtMyTextPane.setBorder(null);
							txtMyTextPane
									.setAlignmentX(Component.LEFT_ALIGNMENT);
							// txtMyTextPane.setBorder(BorderFactory
							// .createLineBorder(Color.black));

							JSplitPane panel_2 = new JSplitPane(
									JSplitPane.HORIZONTAL_SPLIT, jlabel,
									txtMyTextPane);
							panel_2.setBorder(BorderFactory
									.createLineBorder(Color.black));
							panel_2.setResizeWeight(0.5);
							panel_2.setDividerLocation(100);
							panel_2.setDividerSize(1);

							if (attr_name[i].contains("canonicalName")
									|| attr_name[i].contains("workflowID")
									|| attr_name[i].contains("serviceID")) {
								panel_1.add(panel_2);
								length++;
								continue;
							}

							if (attr_name[i].contains("type")
									|| attr_name[i].contains("Time")) {
								other1_jspanels.add(panel_2);
								continue;
							}

							other2_jspanels.add(panel_2);
						}

					}

					for (JSplitPane other : other1_jspanels) {
						panel_1.add(other);
						length++;
					}

					for (JSplitPane other : other2_jspanels) {
						panel_1.add(other);
						length++;
					}

					// frame.add(panel_1, BorderLayout.CENTER);
					panel_1.setBorder(BorderFactory.createTitledBorder(null,
							"Workflow Info",
							TitledBorder.DEFAULT_JUSTIFICATION,
							TitledBorder.DEFAULT_POSITION, new Font("Dialog",
									Font.BOLD, 12), new Color(51, 51, 51)));

					JPanel reg_panel = new JPanel();
					reg_panel.setLayout(new BoxLayout(reg_panel,
							BoxLayout.Y_AXIS));

					for (int i = 0; i < attr_name.length; i++) {
						if (attr_name[i].contains("node_label")
								|| !attr_name[i].contains("_reg_")) {
							// do not show the node_label attribute
							continue;
						}

						/*
						 * Skip some attributes
						 */
						if (attr_name[i].contains("_reg_subtype")
								|| attr_name[i].contains("_reg_creationTime")) {
							// do not show the node_label attribute
							continue;
						}

						JLabel jlabel = new JLabel(attr_name[i]);
						jlabel.setForeground(Color.BLUE);
						jlabel.setSize(40, 80);
						// jlabel.setBorder(BorderFactory
						// .createLineBorder(Color.black));

						obj_attr = cyNodeAttributes.getAttribute(node_2
								.getIdentifier(), attr_name[i]);
						if (obj_attr != null) {
							JTextPane txtMyTextPane = new JTextPane();
							txtMyTextPane.setText(obj_attr.toString());
							txtMyTextPane.setBackground(null);
							txtMyTextPane.setEditable(false);
							txtMyTextPane.setBorder(null);
							txtMyTextPane
									.setAlignmentX(Component.LEFT_ALIGNMENT);
							// txtMyTextPane.setBorder(BorderFactory
							// .createLineBorder(Color.black));

							JSplitPane panel_2 = new JSplitPane(
									JSplitPane.HORIZONTAL_SPLIT, jlabel,
									txtMyTextPane);
							panel_2.setBorder(BorderFactory
									.createLineBorder(Color.black));
							panel_2.setResizeWeight(0.5);
							panel_2.setDividerLocation(100);
							panel_2.setDividerSize(1);

							reg_panel.add(panel_2);
							length++;
						}

					}

					JScrollPane jsp = new JScrollPane(panel_1);
					frame_2.add(jsp, BorderLayout.CENTER);

					frame_2.add(reg_panel, BorderLayout.SOUTH);
					reg_panel.setBorder(BorderFactory.createTitledBorder(null,
							"Registry Info",
							TitledBorder.DEFAULT_JUSTIFICATION,
							TitledBorder.DEFAULT_POSITION, new Font("Dialog",
									Font.BOLD, 12), new Color(51, 51, 51)));

					length = length > 12 ? 12 : length;
					frame_2.setSize(400, 12 * length + 80);
					// frame.pack();
					frame_2.setVisible(true);
					// frame.getRootPane().setVisible(false);
					frame_2.getRootPane().setVisible(true);
				} catch (Exception e) {
					JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e
							.toString());
				}
			}
		}
	}
}
