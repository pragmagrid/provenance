package cytoscape.OPM_visualization.util;

import giny.model.Node;

import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.swing.JOptionPane;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

import cytoscape.Cytoscape;
import cytoscape.OPM_visualization.GraphConfigPanel;
import cytoscape.OPM_visualization.query.KarmaAxis2Query;
import cytoscape.OPM_visualization.query.RabbitmqQuery;
import cytoscape.data.CyAttributes;

public class DetailLoader implements Runnable {
	static String filename;
	static private ConfigurationReader conf_reader;

	private static KarmaAxis2Query axis2Client;
	private static RabbitmqQuery rqClient;

	static int method = -1;

	Collection<Node> nodes;

	public DetailLoader(Collection<Node> nodes) throws Exception {
		this.nodes = nodes;
		initialize();
	}

	public static void initialize() throws Exception {
		if (conf_reader == null)
			conf_reader = ConfigurationReader.getInstance();

		if (GraphConfigPanel.useAxis2) {
			if (axis2Client == null)
				axis2Client = new KarmaAxis2Query(
						ConfigurationReader.serviceURL);
		} else if (GraphConfigPanel.useRabbitmq) {
			if (rqClient == null)
				rqClient = new RabbitmqQuery();
		}
	}

	public static void store() {
		ConfigurationReader.store();
	}

	@Override
	public void run() {
		CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();

		Iterator<Node> itr_nodes = nodes.iterator();

		SAXBuilder builder = new SAXBuilder();

		try {
			List<String> process_id = new ArrayList<String>();
			List<String> artifact_id = new ArrayList<String>();

			while (itr_nodes.hasNext()) {
				Node temp = itr_nodes.next();
				String detailLevel = cyNodeAttrs.getStringAttribute(temp
						.getIdentifier(), "detailLevel");
				if (detailLevel != null
						&& detailLevel.equalsIgnoreCase("coarse")) {
					cyNodeAttrs.setAttribute(temp.getIdentifier(),
							"detailLevel", "fine");
				} else
					continue;

				String nodeType = cyNodeAttrs.getStringAttribute(temp
						.getIdentifier(), "NodeType");

				if (nodeType.contains("PROCESS")) {
					process_id.add(temp.getIdentifier());
					System.out.println("add process: " + temp.getIdentifier());
				} else if (nodeType.contains("ARTIFACT")) {
					artifact_id.add(temp.getIdentifier());
					System.out.println("add artifact: " + temp.getIdentifier());
				}
			}
			if (process_id.size() > 0) {
				String[] id = new String[process_id.size()];
				List<String> instanceOf = new ArrayList<String>();

				String graph_response = null;
				if (GraphConfigPanel.useAxis2) {
					graph_response = axis2Client
							.getServiceDetailByID(process_id.toArray(id));
				} else if (GraphConfigPanel.useRabbitmq) {
					graph_response = rqClient.getServiceDetailByID(process_id
							.toArray(id));
				}

				Reader reader = new StringReader(graph_response);
				System.out.println(graph_response);

				Document doc = builder.build(reader);
				Element root = doc.getRootElement();

				Element child = root.getChild("serviceDetailList", root
						.getNamespace());

				if (child != null) {
					List<Element> sec_child = child.getChildren(
							"serviceDetail", root.getNamespace());

					for (Element element : sec_child) {
						List<Element> ls = element.getChildren();
						for (Element tmp : ls) {
							if (!tmp.getName().equals("instanceOf"))
								cyNodeAttrs.setAttribute(element
										.getAttributeValue("id"),
										tmp.getName(), tmp.getValue());
						}

						if (element.getChild("instanceOf", root.getNamespace()) != null)
							instanceOf.add("Registry_process_"
									+ element.getChild("instanceOf",
											root.getNamespace()).getValue());
					}

				}

				if (instanceOf.size() > 0) {
					String[] instanceOf_ids = new String[instanceOf.size()];
					String graph_response_1 = null;
					if (GraphConfigPanel.useAxis2) {
						graph_response_1 = axis2Client
								.getAbstractServiceDetailByID(instanceOf
										.toArray(instanceOf_ids));
					} else if (GraphConfigPanel.useRabbitmq) {
						graph_response_1 = rqClient
								.getAbstractServiceDetailByID(instanceOf
										.toArray(instanceOf_ids));
					}

					Reader reader_1 = new StringReader(graph_response_1);
					System.out.println(graph_response_1);

					Document doc_1 = builder.build(reader_1);
					Element root_1 = doc_1.getRootElement();

					Element child_1 = root_1.getChild(
							"abstractServiceDetailListType", root_1
									.getNamespace());
					if (child_1 != null) {
						List<Element> sec_child_1 = child_1.getChildren(
								"abstractServiceDetail", root_1.getNamespace());

						for (int i = 0; i < sec_child_1.size(); i++) {
							List<Element> third_child_1 = sec_child_1.get(i)
									.getChildren();

							for (int j = 0; j < third_child_1.size(); j++) {
								cyNodeAttrs.setAttribute(id[i], "_reg_"
										+ third_child_1.get(j).getName(),
										third_child_1.get(j).getValue());
							}
						}

					}

				}
			}

			if (artifact_id.size() > 0) {
				String[] id = new String[artifact_id.size()];
				String graph_response = null;
				if (GraphConfigPanel.useAxis2) {
					graph_response = axis2Client
							.getDataProductDetail(artifact_id.toArray(id));
				} else if (GraphConfigPanel.useRabbitmq) {
					graph_response = rqClient.getDataProductDetail(artifact_id
							.toArray(id));
				}

				Reader reader = new StringReader(graph_response);

				Document doc = builder.build(reader);
				Element root = doc.getRootElement();
				Element child = root.getChild("dataProductDetailList", root
						.getNamespace());

				if (child != null) {
					List<Element> sec_child = child.getChildren(
							"dataProductDetail", root.getNamespace());

					for (Element element : sec_child) {
						List<Element> ls = element.getChildren();
						for (Element tmp : ls) {
							if (!tmp.getName().equals("blockContent"))
								cyNodeAttrs.setAttribute(element
										.getAttributeValue("id"),
										tmp.getName(), tmp.getValue());
						}

						Element blockContent = element.getChild("blockContent",
								root.getNamespace());

						System.out.println(element.getAttributeValue("id")
								.toString());

						if (blockContent == null)
							continue;
						Reader reader1 = new StringReader(blockContent
								.getValue());

						Document doc1 = builder.build(reader1);
						Element root1 = doc1.getRootElement();

						Element child1 = root1.getChild("block", root1
								.getNamespace());
						if (child1 == null)
							continue;

						List<Element> ls1 = child1.getChildren();
						for (Element tmp1 : ls1) {
							cyNodeAttrs.setAttribute(element
									.getAttributeValue("id"), tmp1.getName(),
									tmp1.getValue());
						}

						for (int i = 0; i < GraphBuilder.art_label.length; i++) {
							String attr = cyNodeAttrs.getStringAttribute(
									element.getAttributeValue("id"),
									GraphBuilder.art_label[i]);

							if (attr != null && !attr.isEmpty()) {
								cyNodeAttrs.setAttribute(element
										.getAttributeValue("id"), "node_label",
										attr);
								break;
							}
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e.toString());
		}
		Cytoscape.getCurrentNetworkView().redrawGraph(true, true);
	}
}