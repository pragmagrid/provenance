package cytoscape.OPM_visualization.actionListener;

import giny.model.Node;
import giny.view.EdgeView;
import giny.view.NodeView;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.data.CyAttributes;
import cytoscape.visual.ArrowShape;
import cytoscape.visual.CalculatorCatalog;
import cytoscape.visual.EdgeAppearanceCalculator;
import cytoscape.visual.GlobalAppearanceCalculator;
import cytoscape.visual.NodeAppearanceCalculator;
import cytoscape.visual.NodeShape;
import cytoscape.visual.VisualMappingManager;
import cytoscape.visual.VisualPropertyType;
import cytoscape.visual.VisualStyle;
import cytoscape.visual.calculators.BasicCalculator;
import cytoscape.visual.calculators.Calculator;
import cytoscape.visual.mappings.DiscreteMapping;
import cytoscape.visual.mappings.ObjectMapping;
import cytoscape.visual.mappings.PassThroughMapping;

public class WiMaxDosVisAction implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent arg0) {
		CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();
		CyAttributes cyEdgeAttrs = Cytoscape.getEdgeAttributes();
		Iterator<NodeView> iter = Cytoscape.getCurrentNetworkView()
				.getNodeViewsIterator();
		Node node = null;
		NodeView nodeView = null;
		Set<Integer> hasTravelled = new HashSet<Integer>();

		while (iter.hasNext()) {
			nodeView = iter.next();
			node = nodeView.getNode();

			if (hasTravelled.contains(node.getRootGraphIndex()))
				continue;

			/*
			 * Mark different nodes
			 */
			String process_serviceID = cyNodeAttrs.getStringAttribute(node
					.getIdentifier(), "process-serviceID");

			if (process_serviceID != null) {
				String[] index = process_serviceID.split("\\s");

				// mark attacker/normal nodes
				if (index.length > 2 && index[1].equals("Node")
						&& isInt(index[2])) {
					int node_id = Integer.parseInt(index[2]);

					String attacker_index = cyNodeAttrs.getStringAttribute(node
							.getIdentifier(), "attacker_index_");
					if (attacker_index != null
							&& node_id > Integer.parseInt(attacker_index)) {
						// mark attacker
						cyNodeAttrs.setAttribute(node.getIdentifier(),
								"VisRole", "AttackerNode");
						// mark attacker processes
						CyNetwork network = Cytoscape.getCurrentNetwork();
						
						int[] outgoing_edges = network
								.getAdjacentEdgeIndicesArray(node
										.getRootGraphIndex(), false, false,
										true);
						for (int edge : outgoing_edges) {
							cyEdgeAttrs.setAttribute(network.getEdge(edge)
									.getIdentifier(), "VisRole", "attacker");
						}
					}

					// mark normal nodes
					String nodeType = cyNodeAttrs.getStringAttribute(node
							.getIdentifier(), "NodeType");
					cyNodeAttrs.setAttribute(node.getIdentifier(), "VisRole",
							nodeType);

				} else {
					// mark experiment control nodes
					String nodeType = cyNodeAttrs.getStringAttribute(node
							.getIdentifier(), "NodeType");
					cyNodeAttrs.setAttribute(node.getIdentifier(), "VisRole",
							nodeType);
				}
			} else {
				// all other nodes
				String nodeType = cyNodeAttrs.getStringAttribute(node
						.getIdentifier(), "NodeType");
				if (nodeType.equalsIgnoreCase("ARTIFACT")) {
					String isReceived = cyNodeAttrs.getStringAttribute(node
							.getIdentifier(), "isReceived");
					if (isReceived != null && !isReceived.equalsIgnoreCase("")) {
						cyNodeAttrs.setAttribute(node.getIdentifier(),
								"VisRole", isReceived);
					}
				} else {
					cyNodeAttrs.setAttribute(node.getIdentifier(), "VisRole",
							nodeType);
				}
			}

		}

		Iterator<EdgeView> edge_iter = Cytoscape.getCurrentNetworkView()
				.getEdgeViewsIterator();
		while (edge_iter.hasNext()) {
			EdgeView edgeView = edge_iter.next();

			if (cyEdgeAttrs.getStringAttribute(edgeView.getEdge()
					.getIdentifier(), "VisRole") == null) {
				String interaction = cyEdgeAttrs.getStringAttribute(edgeView
						.getEdge().getIdentifier(), "interaction");
				cyEdgeAttrs.setAttribute(edgeView.getEdge().getIdentifier(),
						"VisRole", interaction);
			}
		}

		// get the VisualMappingManager and CalculatorCatalog
		VisualMappingManager manager = Cytoscape.getVisualMappingManager();
		CalculatorCatalog catalog = manager.getCalculatorCatalog();

		// check to see if a visual style with this name already exists
		VisualStyle vs = catalog.getVisualStyle("WiMaxDosVis");
		if (vs == null) {
			// if not, create it and add it to the catalog
			vs = createVisualStyle(Cytoscape.getCurrentNetwork(), "WiMaxDosVis");
			catalog.addVisualStyle(vs);
		} else {
			catalog.removeVisualStyle("WiMaxDosVis");
			vs = createVisualStyle(Cytoscape.getCurrentNetwork(), "WiMaxDosVis");
			catalog.addVisualStyle(vs);
		}

		manager.setVisualStyle(vs);
		Cytoscape.getCurrentNetworkView().redrawGraph(true, true);
	}

	public boolean isInt(String s) {
		try {
			Integer.parseInt(s);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	VisualStyle createVisualStyle(CyNetwork network, String vsName) {

		NodeAppearanceCalculator nodeAppCalc = new NodeAppearanceCalculator();
		EdgeAppearanceCalculator edgeAppCalc = new EdgeAppearanceCalculator();
		GlobalAppearanceCalculator globalAppCalc = new GlobalAppearanceCalculator();

		globalAppCalc.setDefaultBackgroundColor(new Color(153, 153, 153));

		// Passthrough Mapping - set node label
		PassThroughMapping pm1 = new PassThroughMapping(new String(),
				"node_label");

		BasicCalculator nlc = new BasicCalculator(
				"Example Node Label Calculator", pm1,
				VisualPropertyType.NODE_LABEL);

		nodeAppCalc.setCalculator(nlc);

		// Discrete Mapping - set node shapes
		DiscreteMapping disMapping = new DiscreteMapping(NodeShape.RECT,
				ObjectMapping.NODE_MAPPING);
		disMapping.setControllingAttributeName("NodeType", network, false);
		disMapping.putMapValue("PROCESS", NodeShape.ROUND_RECT);
		disMapping.putMapValue("ARTIFACT", NodeShape.ELLIPSE);
		disMapping.putMapValue("SUBNETWORK", NodeShape.OCTAGON);
		disMapping.putMapValue("AGENT", NodeShape.OCTAGON);

		Calculator shapeCalculator = new BasicCalculator(
				"Example Node Shape Calculator", disMapping,
				VisualPropertyType.NODE_SHAPE);
		nodeAppCalc.setCalculator(shapeCalculator);

		// Discrete Mapping - Set node color
		final Color NODE_COLOR = new Color(10, 10, 10);

		DiscreteMapping nodeColor = new DiscreteMapping(NODE_COLOR, "VisRole",
				ObjectMapping.NODE_MAPPING);

		nodeColor.putMapValue("PROCESS", new Color(50, 255, 50));
		nodeColor.putMapValue("ARTIFACT", new Color(255, 50, 255));
		nodeColor.putMapValue("SUBNETWORK", new Color(255, 255, 255));
		nodeColor.putMapValue("AGENT", new Color(255, 50, 50));
		nodeColor.putMapValue("true", Color.BLUE);
		nodeColor.putMapValue("false", Color.RED);

		Calculator nodeColorCalc = new BasicCalculator("EdgeColorMapping",
				nodeColor, VisualPropertyType.NODE_FILL_COLOR);

		nodeAppCalc.setCalculator(nodeColorCalc);

		// set edge label
		PassThroughMapping pm_e = new PassThroughMapping(new String(),
				"interaction");

		BasicCalculator edc = new BasicCalculator(
				"Example Edge Label Calculator", pm_e,
				VisualPropertyType.EDGE_LABEL);

		edgeAppCalc.setCalculator(edc);

		// Discrete Mapping - Set edge color
		final Color EDGE_COLOR = new Color(10, 10, 10);

		DiscreteMapping edgeColor = new DiscreteMapping(EDGE_COLOR, "VisRole",
				ObjectMapping.EDGE_MAPPING);

		edgeColor.putMapValue("used", new Color(100, 255, 100));
		edgeColor.putMapValue("wasTriggeredBy", Color.YELLOW);
		edgeColor.putMapValue("wasGeneratedBy", new Color(204, 204, 204));
		edgeColor.putMapValue("wasDerivedFrom", new Color(0, 200, 255));
		edgeColor.putMapValue("wasControlledBy", Color.WHITE);
		edgeColor.putMapValue("attacker", Color.RED);

		Calculator edgeColorCalc = new BasicCalculator("EdgeColorMapping",
				edgeColor, VisualPropertyType.EDGE_COLOR);

		edgeAppCalc.setCalculator(edgeColorCalc);

		// Discrete Mapping - Set edge target arrow shape
		DiscreteMapping arrowMapping = new DiscreteMapping(ArrowShape.NONE,
				ObjectMapping.EDGE_MAPPING);
		arrowMapping.setControllingAttributeName("interaction", network, false);
		arrowMapping.putMapValue("wasTriggeredBy", ArrowShape.ARROW);
		arrowMapping.putMapValue("wasGeneratedBy", ArrowShape.CIRCLE);
		arrowMapping.putMapValue("wasDerivedFrom", ArrowShape.CIRCLE);
		arrowMapping.putMapValue("used", ArrowShape.DELTA);
		arrowMapping.putMapValue("wasControlledBy", ArrowShape.DIAMOND);

		Calculator edgeArrowCalculator = new BasicCalculator(
				"Example Edge Arrow Shape Calculator", arrowMapping,
				VisualPropertyType.EDGE_TGTARROW_SHAPE);
		edgeAppCalc.setCalculator(edgeArrowCalculator);

		// Create the visual style
		VisualStyle visualStyle = new VisualStyle(vsName, nodeAppCalc,
				edgeAppCalc, globalAppCalc);

		return visualStyle;
	}
}
