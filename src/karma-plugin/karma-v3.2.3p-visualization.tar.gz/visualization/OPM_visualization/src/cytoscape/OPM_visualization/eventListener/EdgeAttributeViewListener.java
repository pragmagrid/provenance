package cytoscape.OPM_visualization.eventListener;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.InputEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextPane;

import cytoscape.CyEdge;
import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.data.CyAttributes;

public class EdgeAttributeViewListener extends MouseAdapter {
	@Override
	public void mousePressed(MouseEvent mouseEvent) {
		int modifiers = mouseEvent.getModifiers();
		if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK
				&& mouseEvent.getClickCount() == 2) {
			CyNetwork cyNetwork = Cytoscape.getCurrentNetwork();
			// CyNetworkView view = Cytoscape.getCurrentNetworkView();
			Set<CyEdge> edge_set = cyNetwork.getSelectedEdges();

			// make sure if some edge has been clicked
			if (edge_set.isEmpty())
				return;

			Iterator<CyEdge> itr_n = edge_set.iterator();
			CyEdge edge = itr_n.next();

			CyAttributes cyEdgeAttributes = Cytoscape.getEdgeAttributes();
			String[] attr_name = cyEdgeAttributes.getAttributeNames();

			// NodeView nv = view.getNodeView(node);

			// To see if this is the abstract node
			String edge_id = edge.getIdentifier();
			if (edge_id.contains("wasTriggeredBy")
					|| edge_id.contains("wasDerivedFrom")
					|| edge_id.contains("wasGeneratedBy")
					|| edge_id.contains("used")
					|| edge_id.contains("wasExecutedOn")
					|| edge_id.contains("wasConnectedTo")
					|| edge_id.contains("wasControlledBy")) {
				try {
					JFrame frame = new JFrame("Edge Attributes");
					// frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

					frame.setLocation(mouseEvent.getXOnScreen(), mouseEvent
							.getYOnScreen());

					int length = 0;
					JPanel panel_1 = new JPanel();
					panel_1.setLayout(new BoxLayout(panel_1, BoxLayout.Y_AXIS));

					/*
					 * hard code for rtt
					 */
					List<JSplitPane> other_jspanels = new ArrayList<JSplitPane>();

					/*
					 * hard code for rtt
					 */
					List<JSplitPane> rtt_jspanels = new ArrayList<JSplitPane>();

					/*
					 * hard code for ipd
					 */
					List<JSplitPane> ipd_jspanels = new ArrayList<JSplitPane>();

					for (int i = 0; i < attr_name.length; i++) {
						if (attr_name[i].contains("edge_label")) {
							// do not show the edge_label attribute
							continue;
						}

						/*
						 * skip some edge attributes
						 */
						if (attr_name[i].contains("NoEarlierThan")
								|| attr_name[i].contains("AccountRef")
								|| attr_name[i].contains("metaID")
								|| attr_name[i].contains("clp")) {
							// do not show the edge_label attribute
							continue;
						}

						JLabel jlabel = new JLabel(attr_name[i]);
						jlabel.setForeground(Color.BLUE);
						Object obj_attr = cyEdgeAttributes.getAttribute(edge
								.getIdentifier(), attr_name[i]);
						if (obj_attr != null) {
							JTextPane txtMyTextPane = new JTextPane();
							txtMyTextPane.setText(obj_attr.toString());
							txtMyTextPane.setBackground(null);
							txtMyTextPane.setEditable(false);
							txtMyTextPane.setBorder(null);
							txtMyTextPane
									.setAlignmentX(Component.LEFT_ALIGNMENT);

							JSplitPane panel_2 = new JSplitPane(
									JSplitPane.HORIZONTAL_SPLIT, jlabel,
									txtMyTextPane);
							panel_2.setBorder(BorderFactory
									.createLineBorder(Color.black));
							panel_2.setResizeWeight(0.5);
							panel_2.setDividerLocation(100);
							panel_2.setDividerSize(1);

							if (attr_name[i].contains("rtt")
									|| attr_name[i].contains("Rtt")) {
								rtt_jspanels.add(panel_2);
								continue;
							}

							if (attr_name[i].contains("Ipd")) {
								ipd_jspanels.add(panel_2);
								continue;
							}

							if (attr_name[i].contains("canonicalName")
									|| attr_name[i].contains("interaction")
									|| attr_name[i].contains("NoLaterThan")) {
								panel_1.add(panel_2);
								length++;
								continue;
							}

							other_jspanels.add(panel_2);
						}

					}

					for (JSplitPane other : other_jspanels) {
						panel_1.add(other);
						length++;
					}

					for (JSplitPane rtt : rtt_jspanels) {
						panel_1.add(rtt);
						length++;
					}

					for (JSplitPane ipd : ipd_jspanels) {
						panel_1.add(ipd);
						length++;
					}

					JScrollPane jsp = new JScrollPane(panel_1);
					frame.add(jsp, BorderLayout.CENTER);
					length = length > 24 ? 24 : length + 4;
					frame.setSize(400, length * 20);
					// frame.pack();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
					JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e
							.toString());
				}

			}
		}
	}

}
