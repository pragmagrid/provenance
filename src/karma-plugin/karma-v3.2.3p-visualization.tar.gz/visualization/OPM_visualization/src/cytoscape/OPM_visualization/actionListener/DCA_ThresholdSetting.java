package cytoscape.OPM_visualization.actionListener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import cytoscape.Cytoscape;

public class DCA_ThresholdSetting implements ActionListener {
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		try {
			String threshold = JOptionPane.showInputDialog(Cytoscape
					.getDesktop(), "Enter the matching threshold");

			if (threshold != null)
				GraphMatchingAction.THRESHOLD = Double.parseDouble(threshold);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e.toString());
		}
	}
}
