package cytoscape.OPM_visualization.layout;

import giny.view.NodeView;

import java.util.ArrayList;
import java.util.List;
import cytoscape.Cytoscape;
import cytoscape.data.CyAttributes;
import cytoscape.layout.AbstractLayout;

import csplugins.layout.algorithms.bioLayout.BioLayoutKKAlgorithm;
import csplugins.layout.algorithms.force.ForceDirectedLayout;

public class ForceDirectedProvenanceHistoryLayout extends AbstractLayout {
	final static double radius = 100;

	@Override
	public void construct() {
		CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();
		int[] node_ids = Cytoscape.getCurrentNetwork().getNodeIndicesArray();

		List<Integer> node_ids_list = new ArrayList<Integer>();
		for (int node_id : node_ids) {
			if (cyNodeAttrs.getAttribute(
					Cytoscape.getCurrentNetwork().getNode(node_id)
							.getIdentifier(), "NodeType").toString()
					.equalsIgnoreCase("PROCESS")) {
				node_ids_list.add(node_id);
				Cytoscape.getCurrentNetwork().setSelectedNodeState(
						Cytoscape.getCurrentNetwork().getNode(node_id), true);
			}
		}

		int[] selected_node_ids = new int[node_ids_list.size()];
		for (int i = 0; i < node_ids_list.size(); i++) {
			selected_node_ids[i] = node_ids_list.get(i);
		}

		// AbstractLayout springLayout = new JGraphLayoutWrapper(
		// JGraphLayoutWrapper.SPRING_EMBEDDED);

		BioLayoutKKAlgorithm spring_layout = new BioLayoutKKAlgorithm(false);
		spring_layout.setDistanceSpringStrength(150);
		spring_layout.setDisconnectedRestLength(7000);
		int[] edges = new int[0];
		// networkView.applyLayout(spring_layout);
		networkView.applyLayout(spring_layout, selected_node_ids, edges);

		Cytoscape.getCurrentNetwork().unselectAllNodes();

		// networkView.applyLockedLayout(force_layout, nodes, edges);

		List<List<Integer>> rearrangeNodes = new ArrayList<List<Integer>>();
		for (int selected_node_id : selected_node_ids) {
			NodeView nodeView = networkView.getNodeView(selected_node_id);

			double center_X = nodeView.getXPosition();
			double center_Y = nodeView.getYPosition();

			int[] outgoing_edges = network.getAdjacentEdgeIndicesArray(
					selected_node_id, false, false, true);
			CyAttributes edge_attribute = Cytoscape.getEdgeAttributes();

			int[] incoming_edges = network.getAdjacentEdgeIndicesArray(
					selected_node_id, false, true, false);

			List<Integer> ls_rearrangeNodes = new ArrayList<Integer>();

			List<Integer> ls_out_process = new ArrayList<Integer>();
			List<Integer> ls_out_artifact = new ArrayList<Integer>();
			List<Integer> ls_in_artifact = new ArrayList<Integer>();

			for (int edge : outgoing_edges) {
				if (edge_attribute.getStringAttribute(
						network.getEdge(edge).getIdentifier(), "interaction")
						.equalsIgnoreCase("wasTriggeredBy")) {

					int target_node = network.getEdgeTargetIndex(edge);

					if (network.getAdjacentEdgeIndicesArray(target_node, false,
							false, true).length == 0)
						ls_out_process.add(target_node);
				} else if (edge_attribute.getStringAttribute(
						network.getEdge(edge).getIdentifier(), "interaction")
						.equalsIgnoreCase("used")) {

					int target_node = network.getEdgeTargetIndex(edge);

					if (network.getAdjacentEdgeIndicesArray(target_node, false,
							false, true).length == 0)
						ls_out_artifact.add(target_node);

				}

			}

			for (int edge : incoming_edges) {
				if (edge_attribute.getStringAttribute(
						network.getEdge(edge).getIdentifier(), "interaction")
						.equalsIgnoreCase("wasGeneratedBy")) {

					int source_node = network.getEdgeSourceIndex(edge);
					ls_in_artifact.add(source_node);
				}

			}

			ls_rearrangeNodes.add(selected_node_id);
			ls_rearrangeNodes.addAll(ls_out_process);
			ls_rearrangeNodes.addAll(ls_out_artifact);
			ls_rearrangeNodes.addAll(ls_in_artifact);
			rearrangeNodes.add(ls_rearrangeNodes);

			// Compute angle step
			int inCircle = ls_out_artifact.size() / 3;
			int outCircle = ls_out_artifact.size() - inCircle;

			double phi = (2 * Math.PI) / inCircle;

			for (int i = 0; i < inCircle; i++) {
				networkView.getNodeView(ls_out_artifact.get(i)).setXPosition(
						center_X + radius / 2 * Math.sin(phi * i));
				networkView.getNodeView(ls_out_artifact.get(i)).setYPosition(
						center_Y + radius / 2 * Math.cos(phi * i));
			}

			phi = (2 * Math.PI) / outCircle;

			for (int i = inCircle; i < ls_out_artifact.size(); i++) {
				networkView.getNodeView(ls_out_artifact.get(i)).setXPosition(
						center_X + radius * Math.sin(phi * i));
				networkView.getNodeView(ls_out_artifact.get(i)).setYPosition(
						center_Y + radius * Math.cos(phi * i));
			}

			phi = (2 * Math.PI) / ls_out_process.size();

			for (int i = 0; i < ls_out_process.size(); i++) {
				networkView.getNodeView(ls_out_process.get(i)).setXPosition(
						center_X + radius * 1.5 * Math.sin(Math.PI - phi * i));
				networkView.getNodeView(ls_out_process.get(i)).setYPosition(
						center_Y + radius * 1.5 * Math.cos(Math.PI - phi * i));
			}

			phi = (2 * Math.PI) / ls_in_artifact.size();

			for (int i = 0; i < ls_in_artifact.size(); i++) {
				networkView.getNodeView(ls_in_artifact.get(i)).setXPosition(
						center_X + radius * 2 * Math.sin(phi * i));
				networkView.getNodeView(ls_in_artifact.get(i)).setYPosition(
						center_Y + radius * 2 * Math.cos(phi * i));
			}
		}

		for (List<Integer> nodes : rearrangeNodes) {
			if (nodes.size() == 1)
				continue;

			for (int node : nodes) {
				networkView.getNodeView(node).setSelected(true);
			}

			ForceDirectedLayout force_layout = new ForceDirectedLayout();
			force_layout.setPartition(false);
			force_layout.setSelectedOnly(true);
			force_layout.doLayout();

			Cytoscape.getCurrentNetwork().unselectAllNodes();
		}

	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Forced Refine Provenance History Layout";
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Forced Refine Provenance History Layout";
	}
}
