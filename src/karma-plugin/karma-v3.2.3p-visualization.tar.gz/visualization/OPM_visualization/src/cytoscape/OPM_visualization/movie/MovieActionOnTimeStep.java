package cytoscape.OPM_visualization.movie;

import giny.model.Edge;
import giny.model.Node;
import giny.view.NodeView;

import java.awt.event.ActionEvent;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.data.CyAttributes;
import cytoscape.view.CyNetworkView;

/**
 * @author Peng
 */
/*
 * First hide all the nodes, and then show each node by the order of the
 * "time_step" attribute
 */
public class MovieActionOnTimeStep extends Movie {
	NodeView nodeView;

	public MovieActionOnTimeStep(NodeView pNodeView) {
		nodeView = pNodeView;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Thread t = new Thread(new Movie());
		t.start();
	}

	class Movie implements Runnable {

		@Override
		public void run() {
			CyNetwork network = Cytoscape.getCurrentNetwork();
			CyNetworkView networkView = Cytoscape.getCurrentNetworkView();
			CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();

			List<Node> nodes = network.nodesList();
			List<Node> visable_nodes = new LinkedList<Node>();

			Map<Integer, List<Integer>> nodes_step = new HashMap<Integer, List<Integer>>();

			Iterator<Node> itr_nodes = nodes.iterator();

			while (itr_nodes.hasNext()) {
				Node temp = itr_nodes.next();
				String timeStep = cyNodeAttrs.getStringAttribute(temp
						.getIdentifier(), "timestep");

				if (timeStep == null || timeStep.equals("")
						|| timeStep.equals("-1")) {
					visable_nodes.add(temp);
					continue;
				}
				// networkView.hideGraphObject(networkView.getNodeView(temp));
				NodeView nv = networkView.getNodeView(temp);
				networkView.hideGraphObject(nv);
				
				// network.hideNode(temp);

				Integer time = Integer.parseInt(timeStep);

				if (nodes_step.containsKey(time)) {
					List<Integer> ls = nodes_step.get(time);
					ls.add(temp.getRootGraphIndex());
				} else {
					List<Integer> ls = new LinkedList<Integer>();
					ls.add(temp.getRootGraphIndex());
					nodes_step.put(time, ls);
				}

			}

			networkView.redrawGraph(true, true);

			try {
				Thread.sleep(timeInterval);

				for (int i = 1;; i++) {
					if (nodes_step.containsKey(new Integer(i))) {
						List<Integer> ls = nodes_step.get(new Integer(i));
						// network.restoreNodes(ls);
						Iterator<Integer> itr_index = ls.iterator();
						while (itr_index.hasNext()) {
							int index = itr_index.next();
							networkView.showGraphObject(networkView
									.getNodeView(index));
							visable_nodes.add(network.getNode(index));
							List<Edge> edges_list = network
									.getConnectingEdges(visable_nodes);

							Iterator<Edge> itr_edge = edges_list.iterator();
							while (itr_edge.hasNext()) {
								Edge edge = itr_edge.next();
								networkView.showGraphObject(networkView
										.getEdgeView(edge));
							}
						}
						networkView.redrawGraph(true, true);
						Thread.sleep(timeInterval);
					} else
						break;
				}
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		}

	}
}
