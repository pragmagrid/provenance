package cytoscape.OPM_visualization.layout;

import giny.model.Node;
import giny.view.NodeView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import cytoscape.Cytoscape;
import cytoscape.data.CyAttributes;
import cytoscape.layout.AbstractLayout;

public class NSLayoutExtRD_Circle extends AbstractLayout {
	static final double aug_scale = 10;
	static final double shift = 10;

	@Override
	public void construct() {
		// TODO Auto-generated method stub
		CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();

		Iterator<NodeView> iter = networkView.getNodeViewsIterator();

		Map<Integer, Boolean> isTravelled = new HashMap<Integer, Boolean>();
		Node node = null;
		NodeView nodeView = null;

		while (iter.hasNext()) {
			if (canceled)
				return;
			
			nodeView = iter.next();
			node = nodeView.getNode();

			String x_coor = cyNodeAttrs.getStringAttribute(
					node.getIdentifier(), "X_");
			String y_coor = cyNodeAttrs.getStringAttribute(
					node.getIdentifier(), "Y_");
			if (x_coor != null && y_coor != null) {
				double x = Double.parseDouble(x_coor);
				double y = Double.parseDouble(y_coor);

				nodeView.setXPosition(x * aug_scale);
				nodeView.setYPosition(y * aug_scale);

				isTravelled.put(new Integer(node.getRootGraphIndex()), true);
			} else
				isTravelled.put(new Integer(node.getRootGraphIndex()), false);
		}

		Map<Integer, Double> node_margin = new HashMap<Integer, Double>();

		iter = networkView.getNodeViewsIterator();
		while (iter.hasNext()) {
			if (canceled)
				return;

			nodeView = iter.next();
			node = nodeView.getNode();

			if (!isTravelled.get(node.getRootGraphIndex()))
				continue;

			double x = nodeView.getXPosition();
			double y = nodeView.getYPosition();
			double margin = Double.MAX_VALUE;

			Iterator<NodeView> tmp_iter = networkView.getNodeViewsIterator();
			while (tmp_iter.hasNext()) {
				NodeView tmpNodeView = tmp_iter.next();
				if (tmpNodeView.getNode().getIdentifier().equals(
						node.getIdentifier()))
					continue;
				if (!isTravelled.get(tmpNodeView.getNode().getRootGraphIndex()))
					continue;

				double tmp_x = tmpNodeView.getXPosition();
				double tmp_y = tmpNodeView.getYPosition();

				double dis = Math.sqrt((x - tmp_x) * (x - tmp_x) + (y - tmp_y)
						* (y - tmp_y));
				if (margin > dis)
					margin = dis;
			}

			node_margin.put(node.getRootGraphIndex(), margin);
		}

		Iterator<Integer> itr = node_margin.keySet().iterator();
		while (itr.hasNext()) {
			if (canceled)
				return;

			int node_id = itr.next();

			double center_X = networkView.getNodeView(node_id).getXPosition();
			double center_Y = networkView.getNodeView(node_id).getYPosition();

			double radius = node_margin.get(node_id).doubleValue();
			radius = radius / 4 * 0.8;

			int[] incoming_edges = network.getAdjacentEdgeIndicesArray(node_id,
					false, true, false);
			CyAttributes edge_attribute = Cytoscape.getEdgeAttributes();

			List<Integer> ls_process = new ArrayList<Integer>();
			List<Integer> ls_artifact_drop = new ArrayList<Integer>();
			List<Integer> ls_artifact_send = new ArrayList<Integer>();

			for (int edge : incoming_edges) {
				if (edge_attribute.getStringAttribute(
						network.getEdge(edge).getIdentifier(), "interaction")
						.equalsIgnoreCase("wasTriggeredBy")) {

					int source_node = network.getEdgeSourceIndex(edge);
					if (isTravelled.get(source_node))
						continue;
					else {
						isTravelled.put(source_node, true);
						ls_process.add(source_node);
					}
				} else if (edge_attribute.getStringAttribute(
						network.getEdge(edge).getIdentifier(), "interaction")
						.equalsIgnoreCase("wasGeneratedBy")) {

					int source_node = network.getEdgeSourceIndex(edge);
					if (isTravelled.get(source_node))
						continue;
					else {
						isTravelled.put(source_node, true);
						if (!cyNodeAttrs.getStringAttribute(
								network.getNode(source_node).getIdentifier(),
								"isReceived").equalsIgnoreCase("true"))
							ls_artifact_drop.add(source_node);
						else
							ls_artifact_send.add(source_node);
					}
				}

			}

			// Compute angle step
			double phi = (2 * Math.PI) / ls_process.size();

			for (int i = 0; i < ls_process.size(); i++) {
				networkView.getNodeView(ls_process.get(i)).setXPosition(
						center_X + radius * Math.sin(phi * i));
				networkView.getNodeView(ls_process.get(i)).setYPosition(
						center_Y + radius * Math.cos(phi * i));
			}

			radius *= 2;
			phi = (2 * Math.PI)
					/ (ls_artifact_send.size() + ls_artifact_drop.size());

			for (int i = 0; i < ls_artifact_send.size()
					+ ls_artifact_drop.size(); i++) {
				if (i < ls_artifact_send.size()) {
					networkView.showGraphObject(networkView
							.getNodeView(ls_artifact_send.get(i)));
					networkView
							.getNodeView(ls_artifact_send.get(i))
							.setXPosition(center_X + radius * Math.sin(phi * i));
					networkView
							.getNodeView(ls_artifact_send.get(i))
							.setYPosition(center_Y + radius * Math.cos(phi * i));
				} else {
					networkView.showGraphObject(networkView
							.getNodeView(ls_artifact_drop.get(i
									- ls_artifact_send.size())));
					networkView
							.getNodeView(
									ls_artifact_drop.get(i
											- ls_artifact_send.size()))
							.setXPosition(center_X + radius * Math.sin(phi * i));
					networkView
							.getNodeView(
									ls_artifact_drop.get(i
											- ls_artifact_send.size()))
							.setYPosition(center_Y + radius * Math.cos(phi * i));
				}
			}
		}

	}

	@Override
	public String getName() {
		return "NS Layout Packet Receive and Drop Circle";
	}

	@Override
	public String toString() {
		return "NS Layout Packet Receive and Drop Circle";
	}
}
