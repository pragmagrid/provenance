package cytoscape.OPM_visualization.actionListener;

import giny.model.Node;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.data.CyAttributes;
import cytoscape.visual.ArrowShape;
import cytoscape.visual.CalculatorCatalog;
import cytoscape.visual.EdgeAppearanceCalculator;
import cytoscape.visual.GlobalAppearanceCalculator;
import cytoscape.visual.NodeAppearanceCalculator;
import cytoscape.visual.NodeShape;
import cytoscape.visual.VisualMappingManager;
import cytoscape.visual.VisualPropertyType;
import cytoscape.visual.VisualStyle;
import cytoscape.visual.calculators.BasicCalculator;
import cytoscape.visual.calculators.Calculator;
import cytoscape.visual.mappings.DiscreteMapping;
import cytoscape.visual.mappings.ObjectMapping;
import cytoscape.visual.mappings.PassThroughMapping;
import cytoscape.visual.ui.MappingKeyFactory;

public class ComparingTwoNetworkAction implements ActionListener {
	final static double threshold = 0.7;
	final static String vsName = "OPM Comparison";

	Map<Node, NodePair> nm = new HashMap<Node, NodePair>();
	List<Set<Node>> subGraphs = new ArrayList<Set<Node>>();

	CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();

	@Override
	public void actionPerformed(ActionEvent arg0) {
		final List<CyNetwork> selected = Cytoscape.getSelectedNetworks();

		if (selected == null || selected.size() != 2)
			return;

		CyNetwork network_1 = selected.get(0);
		CyNetwork network_2 = selected.get(1);

		int[] nodes_1 = network_1.getNodeIndicesArray();
		int[] nodes_2 = network_2.getNodeIndicesArray();

		for (int node : nodes_1) {
			cyNodeAttrs.setAttribute(network_1.getNode(node).getIdentifier(),
					"sub-graph-match", -1);
		}
		for (int node : nodes_2) {
			cyNodeAttrs.setAttribute(network_2.getNode(node).getIdentifier(),
					"sub-graph-match", -2);
		}

		/*
		 * Calculate the similarity between each <node,node> pair. Keep those
		 * with similarity larger than threshold.For non-121 mapping, drop the
		 * pair with lower similarity.
		 */
		for (int i = 0; i < nodes_1.length; i++) {
			for (int j = 0; j < nodes_2.length; j++) {
				double sim = computeSimilarity(network_1, network_2, network_1
						.getNode(nodes_1[i]), network_2.getNode(nodes_2[j]));

				if (sim > threshold
						&& (!(nm.containsKey(network_1.getNode(nodes_1[i]))) || sim > nm
								.get(network_1.getNode(nodes_1[i]))
								.getSimilarity())) {

					NodePair np = new NodePair(network_1.getNode(nodes_1[i]),
							network_2.getNode(nodes_2[j]), sim);

					nm.put(network_1.getNode(nodes_1[i]), np);
				}

			}
		}

		/*
		 * for each node, if it's dest node belongs to any of the sub-graph,
		 * then classify it to that sub-graph; so is the src node. If there is
		 * no assignment, create a subgraph that contains this node. But if it
		 * is assigned to two different sub-graphs, then we merge these two into
		 * a new sub-graph.
		 */
		Set<Node> qualified_nodes = nm.keySet();
		// System.out.println("size:" + qualified_nodes.size());
		for (Node node : qualified_nodes) {
			int[] neighbors = network_1
					.neighborsArray(node.getRootGraphIndex());

			Set<Node> first_subGraph = null;

			for (int j = 0; j < subGraphs.size(); j++) {
				Set<Node> subGraph = subGraphs.get(j);
				for (int neighbor : neighbors) {
					if (subGraph.contains(network_1.getNode(neighbor))) {
						subGraph.add(node);

						if (first_subGraph == null) {
							first_subGraph = subGraph;
						} else {
							first_subGraph.addAll(subGraph);
							subGraphs.remove(subGraph);
							j--;
						}

						break;
					}
				}
			}

			if (first_subGraph == null) {
				first_subGraph = new HashSet<Node>();
				first_subGraph.add(node);
				subGraphs.add(first_subGraph);
			}
		}

		/*
		 * Set the sub-graph number
		 */

		for (int i = 0; i < subGraphs.size(); i++) {
			Set<Node> subGraph = subGraphs.get(i);
			for (Node node : subGraph) {
				cyNodeAttrs.setAttribute(node.getIdentifier(),
						"sub-graph-match", i);
				cyNodeAttrs.setAttribute(nm.get(node).getNode_2()
						.getIdentifier(), "sub-graph-match", i);
			}
		}

		/*
		 * coloring the sub-graphs with different colors
		 * */
		
		// get the VisualMappingManager and CalculatorCatalog
		VisualMappingManager manager = Cytoscape.getVisualMappingManager();
		CalculatorCatalog catalog = manager.getCalculatorCatalog();

		// check to see if a visual style with this name already exists
		VisualStyle vs = catalog.getVisualStyle(vsName);
		if (vs == null) {
			// if not, create it and add it to the catalog
			vs = createVisualStyle(network_1, vsName);
			catalog.addVisualStyle(vs);
		}else{
			catalog.removeVisualStyle(vs.getName());
			vs = createVisualStyle(network_1, vsName);
			catalog.addVisualStyle(vs);
		}

		Cytoscape.getNetworkView(network_1.getIdentifier()).setVisualStyle(
				vs.getName());
		Cytoscape.getNetworkView(network_2.getIdentifier()).setVisualStyle(
				vs.getName());

		// actually apply the visual style
		manager.setVisualStyle(vs);
		Cytoscape.getNetworkView(network_1.getIdentifier()).redrawGraph(true,
				true);
		Cytoscape.getNetworkView(network_2.getIdentifier()).redrawGraph(true,
				true);
	}

	public double computeSimilarity(CyNetwork network_1, CyNetwork network_2,
			Node node1, Node node2) {
		CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();

		String label1 = cyNodeAttrs.getStringAttribute(node1.getIdentifier(),
				"node_label");
		String label2 = cyNodeAttrs.getStringAttribute(node2.getIdentifier(),
				"node_label");

		double similarity = 0;

		if (label1.equalsIgnoreCase(label2)) {
			similarity += 1.0 / 2;
		}

		int[] neighbors_1 = network_1.neighborsArray(node1.getRootGraphIndex());
		int[] neighbors_2 = network_2.neighborsArray(node2.getRootGraphIndex());

		for (int neighbor_1 : neighbors_1) {
			for (int neighbor_2 : neighbors_2) {
				label1 = cyNodeAttrs.getStringAttribute(network_1.getNode(
						neighbor_1).getIdentifier(), "node_label");
				label2 = cyNodeAttrs.getStringAttribute(network_2.getNode(
						neighbor_2).getIdentifier(), "node_label");

				if (label1.equalsIgnoreCase(label2)) {
					similarity += 1.0 / (neighbors_1.length + neighbors_2.length) * 2;
					break;
				}
			}
		}

		for (int neighbor_2 : neighbors_2) {
			for (int neighbor_1 : neighbors_1) {
				label1 = cyNodeAttrs.getStringAttribute(network_1.getNode(
						neighbor_1).getIdentifier(), "node_label");
				label2 = cyNodeAttrs.getStringAttribute(network_2.getNode(
						neighbor_2).getIdentifier(), "node_label");

				if (label1.equalsIgnoreCase(label2)) {
					similarity += 1.0 / (neighbors_1.length + neighbors_2.length) * 2;
					break;
				}
			}
		}

		return similarity;
	}

	VisualStyle createVisualStyle(CyNetwork network, String vsName) {

		NodeAppearanceCalculator nodeAppCalc = new NodeAppearanceCalculator();
		EdgeAppearanceCalculator edgeAppCalc = new EdgeAppearanceCalculator();
		GlobalAppearanceCalculator globalAppCalc = new GlobalAppearanceCalculator();

		globalAppCalc.setDefaultBackgroundColor(new Color(153, 153, 153));

		// Passthrough Mapping - set node label
		PassThroughMapping pm1 = new PassThroughMapping(new String(),
				"node_label");

		BasicCalculator nlc = new BasicCalculator(
				"Example Node Label Calculator", pm1,
				VisualPropertyType.NODE_LABEL);

		nodeAppCalc.setCalculator(nlc);

		// Discrete Mapping - set node shapes
		DiscreteMapping disMapping = new DiscreteMapping(NodeShape.RECT,
				ObjectMapping.NODE_MAPPING);
		disMapping.setControllingAttributeName("NodeType", network, false);
		disMapping.putMapValue("PROCESS", NodeShape.ROUND_RECT);
		disMapping.putMapValue("ARTIFACT", NodeShape.ELLIPSE);
		disMapping.putMapValue("SUBNETWORK", NodeShape.OCTAGON);
		disMapping.putMapValue("AGENT", NodeShape.OCTAGON);

		Calculator shapeCalculator = new BasicCalculator(
				"Example Node Shape Calculator", disMapping,
				VisualPropertyType.NODE_SHAPE);
		nodeAppCalc.setCalculator(shapeCalculator);

		final Color NODE_COLOR = new Color(0,0,0);
		DiscreteMapping nodeColor = new DiscreteMapping(NODE_COLOR,
				"sub-graph-match", ObjectMapping.NODE_MAPPING);

		final Set<Object> attrSet = MappingKeyFactory.getKeySet(nodeColor
				.getControllingAttributeName(), Cytoscape.getNodeAttributes(),
				nodeColor, true);

		final Map<Object, Color> valueMap = new HashMap<Object, Color>();
		/*
		 * Create rainbow colors
		 */
		final float increment = 1f / ((Number) attrSet.size()).floatValue();

		float hue = 0;

		for (Object key : attrSet) {
			hue = hue + increment;
			valueMap.put(key, new Color(Color.HSBtoRGB(hue, 1f, 1f)));
		}

		nodeColor.putAll(valueMap);

		Calculator nodeColorCalc = new BasicCalculator("NodeColorMapping",
				nodeColor, VisualPropertyType.NODE_FILL_COLOR);

		nodeAppCalc.setCalculator(nodeColorCalc);

		// set edge label
		PassThroughMapping pm_e = new PassThroughMapping(new String(),
				"interaction");

		BasicCalculator edc = new BasicCalculator(
				"Example Edge Label Calculator", pm_e,
				VisualPropertyType.EDGE_LABEL);

		edgeAppCalc.setCalculator(edc);

		// Discrete Mapping - Set edge color
		final Color EDGE_COLOR = new Color(10, 10, 10);

		DiscreteMapping edgeColor = new DiscreteMapping(EDGE_COLOR,
				"interaction", ObjectMapping.EDGE_MAPPING);

		edgeColor.putMapValue("used", new Color(100, 255, 100));
		edgeColor.putMapValue("wasTriggeredBy", Color.YELLOW);
		edgeColor.putMapValue("wasGeneratedBy", new Color(204, 204, 204));
		edgeColor.putMapValue("wasDerivedFrom", new Color(0, 200, 255));
		edgeColor.putMapValue("wasControlledBy", Color.WHITE);

		Calculator edgeColorCalc = new BasicCalculator("EdgeColorMapping",
				edgeColor, VisualPropertyType.EDGE_COLOR);

		edgeAppCalc.setCalculator(edgeColorCalc);

		// Discrete Mapping - Set edge target arrow shape
		DiscreteMapping arrowMapping = new DiscreteMapping(ArrowShape.NONE,
				ObjectMapping.EDGE_MAPPING);
		arrowMapping.setControllingAttributeName("interaction", network, false);
		arrowMapping.putMapValue("wasTriggeredBy", ArrowShape.ARROW);
		arrowMapping.putMapValue("wasGeneratedBy", ArrowShape.CIRCLE);
		arrowMapping.putMapValue("wasDerivedFrom", ArrowShape.CIRCLE);
		arrowMapping.putMapValue("used", ArrowShape.DELTA);
		arrowMapping.putMapValue("wasControlledBy", ArrowShape.DIAMOND);

		Calculator edgeArrowCalculator = new BasicCalculator(
				"Example Edge Arrow Shape Calculator", arrowMapping,
				VisualPropertyType.EDGE_TGTARROW_SHAPE);
		edgeAppCalc.setCalculator(edgeArrowCalculator);

		// Create the visual style
		VisualStyle visualStyle = new VisualStyle(vsName, nodeAppCalc,
				edgeAppCalc, globalAppCalc);

		return visualStyle;
	}

	class NodePair {
		private Node node_1, node_2;
		private double similarity = -1;

		public NodePair(Node node_1, Node node_2, double sim) {
			this.node_1 = node_1;
			this.node_2 = node_2;
			this.similarity = sim;
		}

		public Node getNode_1() {
			return this.node_1;
		}

		public Node getNode_2() {
			return this.node_2;
		}

		public double getSimilarity() {
			return this.similarity;
		}
	}
}
