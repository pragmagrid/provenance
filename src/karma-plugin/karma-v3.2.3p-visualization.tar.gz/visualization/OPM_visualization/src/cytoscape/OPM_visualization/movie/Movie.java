package cytoscape.OPM_visualization.movie;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import cytoscape.Cytoscape;

public class Movie implements ActionListener {
	public static int timeInterval = 1000;

	@Override
	public void actionPerformed(ActionEvent arg0) {
		try{
		String time_interval = JOptionPane.showInputDialog(Cytoscape
				.getDesktop(), "Enter time interval in milliseconds");
		
		if(time_interval != null)
		timeInterval = Integer.parseInt(time_interval);
		}catch(Exception e){
			JOptionPane.showMessageDialog(Cytoscape
					.getDesktop(), e.toString());
		}
	}
}
