package cytoscape.OPM_visualization.layout;

import giny.model.Node;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import cytoscape.Cytoscape;
import cytoscape.data.CyAttributes;
import cytoscape.layout.AbstractLayout;

/**
 * @author Peng
 */
/*
 * An after layout algorithm developed by Peng, to travel the nodes by level
 * order. During each level, sort the nodes based on its "Time" attribute
 */

public class MyLayout extends AbstractLayout {
	private Map<Integer, Boolean> isTravelled;

	/**
	 * Creates a new layout object.
	 */
	public MyLayout() {
		super();
		initialize_properties();
	}

	protected void initialize_properties() {
		updateSettings(true);
	}

	/**
	 * DOCUMENT ME!
	 */
	@Override
	public void updateSettings() {
		updateSettings(false);
	}

	public void updateSettings(boolean force) {
	}

	@Override
	public void construct() {
		taskMonitor.setStatus("Initializing");
		initialize(); // Calls initialize_local

		isTravelled = new HashMap<Integer, Boolean>();

		CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();
		Iterator<Node> it = network.nodesIterator();

		Node node = null, rootNode = null;

		while (it.hasNext()) {
			if (canceled)
				return;

			node = it.next();

			isTravelled.put(new Integer(node.getRootGraphIndex()), false);

			if (cyNodeAttrs.getStringAttribute(node.getIdentifier(), "Time") == null) {
				rootNode = node;
			}
		}

		if (rootNode != null) {
			sort_X(rootNode.getRootGraphIndex(), 0);
		}
	}

	private double horizontal_space = 64.0;

	/**
	 * getName is used to construct property strings for this layout.
	 */
	@Override
	public String getName() {
		return "X sort";
	}

	/**
	 * toString is used to get the user-visible name of the layout
	 */
	@Override
	public String toString() {
		return "OPM X sort";
	}

	private void sort_X(int node, double offset) {

		CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();

		int[] incoming_edges = network.getAdjacentEdgeIndicesArray(node, false,
				true, false);
		if (incoming_edges.length == 0)
			return;
		else {
			SortNode[] sort_nodes = new SortNode[incoming_edges.length];

			for (int i = 0; i < sort_nodes.length; i++) {
				sort_nodes[i] = new SortNode(network
						.getEdgeSourceIndex(incoming_edges[i]), cyNodeAttrs
						.getStringAttribute(network.getNode(
								network.getEdgeSourceIndex(incoming_edges[i]))
								.getIdentifier(), "Time"));
			}

			Arrays.sort(sort_nodes);

			// get the leftMost of the the children, as the base for re-layout
			double leftMost = leftMostX_Child(node);

			double[] X_afterSorting = new double[sort_nodes.length];
			double[] child_offset = new double[sort_nodes.length];

			X_afterSorting[0] = leftMost
					+ (networkView.getNodeView(sort_nodes[0].node_id)
							.getXPosition() - leftMostX(sort_nodes[0].node_id));
			child_offset[0] = X_afterSorting[0]
					- networkView.getNodeView(sort_nodes[0].node_id)
							.getXPosition();

			for (int i = 1; i < sort_nodes.length; i++) {
				double rightMostX_pre = rightMostX(sort_nodes[i - 1].node_id);
				double leftMostX_cur = leftMostX(sort_nodes[i].node_id);

				if (rightMostX_pre == leftMostX_cur) {
					X_afterSorting[i] = X_afterSorting[i - 1]
							+ (rightMostX_pre - networkView.getNodeView(
									sort_nodes[i - 1].node_id).getXPosition())
							+ (networkView.getNodeView(sort_nodes[i].node_id)
									.getXPosition() - leftMostX_cur);
				} else {
					X_afterSorting[i] = X_afterSorting[i - 1]
							+ (rightMostX_pre - networkView.getNodeView(
									sort_nodes[i - 1].node_id).getXPosition())
							+ (networkView.getNodeView(sort_nodes[i].node_id)
									.getXPosition() - leftMostX_cur)
							+ horizontal_space;
				}

				child_offset[i] = X_afterSorting[i]
						- networkView.getNodeView(sort_nodes[i].node_id)
								.getXPosition();
			}

			for (int i = 0; i < sort_nodes.length; i++) {
				double new_pos = networkView.getNodeView(sort_nodes[i].node_id)
						.getXPosition();
				new_pos += offset + child_offset[i];

				if (isTravelled.get(new Integer(sort_nodes[i].node_id))
						.booleanValue()) {
					return;
				} else {
					isTravelled.put(new Integer(sort_nodes[i].node_id), true);
				}

				networkView.getNodeView(sort_nodes[i].node_id).setXPosition(
						new_pos);

				sort_X(sort_nodes[i].node_id, offset + child_offset[i]);
			}

		}
	}

	// get the leftMost x position of a given sub-tree
	private double leftMostX(int node) {
		int[] incoming_edges = network.getAdjacentEdgeIndicesArray(node, false,
				true, false);
		if (incoming_edges.length == 0)
			return networkView.getNodeView(node).getXPosition();
		else {
			// int leftMost_index = 0;
			double leftMost = networkView.getNodeView(node).getXPosition();

			for (int i = 0; i < incoming_edges.length; i++) {

				double tmp = leftMostX(network
						.getEdgeSourceIndex(incoming_edges[i]));

				if (tmp < leftMost) {
					leftMost = tmp;
					// leftMost_index = i;
				}
			}

			return leftMost;
		}
	}

	// get the rightMost x position of a given sub-tree
	private double rightMostX(int node) {
		int[] incoming_edges = network.getAdjacentEdgeIndicesArray(node, false,
				true, false);
		if (incoming_edges.length == 0)
			return networkView.getNodeView(node).getXPosition();
		else {
			double rightMostX = networkView.getNodeView(node).getXPosition();

			for (int i = 0; i < incoming_edges.length; i++) {

				double tmp = rightMostX(network
						.getEdgeSourceIndex(incoming_edges[i]));

				if (tmp > rightMostX) {
					rightMostX = tmp;
				}
			}

			return rightMostX;
		}
	}

	// get the leftMost x position of all the descenders of a given node
	private double leftMostX_Child(int node) {
		int[] incoming_edges = network.getAdjacentEdgeIndicesArray(node, false,
				true, false);
		if (incoming_edges.length == 0)
			return networkView.getNodeView(node).getXPosition();
		else {
			// int leftMost_index = 0;
			double leftMost = leftMostX(network
					.getEdgeSourceIndex(incoming_edges[0]));

			for (int i = 1; i < incoming_edges.length; i++) {

				double tmp = leftMostX(network
						.getEdgeSourceIndex(incoming_edges[i]));

				if (tmp < leftMost) {
					leftMost = tmp;
					// leftMost_index = i;
				}
			}

			return leftMost;
		}
	}
}

class SortNode implements Comparable<SortNode> {
	public String time;
	public int node_id;

	SortNode(int node_id, String time) {
		this.node_id = node_id;
		this.time = time;
	}

	@Override
	public int compareTo(SortNode arg0) {
		return this.time.compareTo(((SortNode) arg0).time);
	}
}