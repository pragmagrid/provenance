package cytoscape.OPM_visualization.actionListener;

import giny.model.Node;
import giny.view.NodeView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Reader;
import java.io.StringReader;
import java.util.Iterator;
import java.util.Set;

import javax.swing.JOptionPane;

import org.openprovenance.model.v1_1_a.OpmGraphDocument;

import csplugins.layout.algorithms.hierarchicalLayout.HierarchicalLayoutAlgorithm;
import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.OPM_visualization.GraphConfigPanel;
import cytoscape.OPM_visualization.OPM_visualization;
import cytoscape.OPM_visualization.query.KarmaAxis2Query;
import cytoscape.OPM_visualization.query.RabbitmqQuery;
import cytoscape.OPM_visualization.util.ConfigurationReader;
import cytoscape.OPM_visualization.util.GraphBuilder;
import cytoscape.data.CyAttributes;
import cytoscape.view.CyNetworkView;

public class DataForwardGraphAction implements ActionListener {
	NodeView nodeView;
	static String filename;

	static int method = -1;

	public DataForwardGraphAction(NodeView pNodeView) {
		nodeView = pNodeView;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		try {

			Set<Node> nodes = Cytoscape.getCurrentNetwork().getSelectedNodes();

			ForwardGraphLoader dl = new ForwardGraphLoader(nodes);
			Thread t = new Thread(dl);
			t.start();

		} catch (Exception e) {
			JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e.toString());
			e.printStackTrace();
		}
	}
}

class ForwardGraphLoader implements Runnable {
	Set<Node> nodes;

	public ForwardGraphLoader(Set<Node> nodes) {
		this.nodes = nodes;
	}

	@Override
	public void run() {
		Iterator<Node> itr_nodes = nodes.iterator();
		try {
			while (itr_nodes.hasNext()) {
				Node temp = itr_nodes.next();

				CyAttributes formerCyNodeAttrs = Cytoscape.getNodeAttributes();
				String nodeType = formerCyNodeAttrs.getStringAttribute(temp
						.getIdentifier(), "NodeType");
				if (nodeType.contains("ARTIFACT")) {

					// Cytoscape.createNewSession();
					CyNetwork network = Cytoscape.createNetwork(temp
							.getIdentifier()
							+ "_dataForward", true);
					CyNetworkView new_networkView = Cytoscape
							.getNetworkView(network.getIdentifier());
					CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();
					CyAttributes cyEdgeAttrs = Cytoscape.getEdgeAttributes();

					String graph_response = null;

					KarmaAxis2Query axis2Client = null;
					RabbitmqQuery rqClient = null;

					/*
					 * use the method configured in configuration panel Or try
					 * to use the Axis2 by default
					 */
					if (GraphConfigPanel.useRabbitmq) {
						rqClient = new RabbitmqQuery();
						if (rqClient != null) {
							graph_response = rqClient.getDataForwardFlow(temp
									.getIdentifier());
						}
					} else {
						axis2Client = new KarmaAxis2Query(
								ConfigurationReader.serviceURL);
						if (axis2Client != null) {
							graph_response = axis2Client
									.getDataForwardFlow(temp.getIdentifier());
						} else {
							return;
						}
					}

					// axis2Tester = new KarmaAxis2Query(ConfigurationReader
					// .getInstance().serviceURL);

					// System.out.println("#####################\n"
					// + graph_response);

					String graph;
					/*
					 * Re-organize the result xml into a opm xml
					 */
					int start = graph_response.lastIndexOf("<v1:opmGraph");
					int end = graph_response.lastIndexOf("<");

					if (start == -1 || end == -1) {
						graph = graph_response;

						JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
								"An invalid OPM graph returned");
					} else
						graph = graph_response.substring(start, end);

					Reader reader = new StringReader(graph);

					OpmGraphDocument doc = OpmGraphDocument.Factory
							.parse(reader);

					GraphBuilder gbuilder = new GraphBuilder();
					gbuilder.build(doc, network, cyNodeAttrs, cyEdgeAttrs);

					// GroupAttributesLayout gal = new GroupAttributesLayout();
					// gal.setLayoutAttribute("NodeType");
					// HierarchicalLayoutAlgorithm hl = new
					// HierarchicalLayoutAlgorithm();
					// new_networkView.applyLayout(hl);

					/*
					 * delete all processes
					 */
					Iterator<Node> nodes = network.nodesIterator();
					while (nodes.hasNext()) {
						Node tmp = nodes.next();
						if (cyNodeAttrs.getStringAttribute(tmp.getIdentifier(),
								"NodeType").equalsIgnoreCase("PROCESS"))
							network.hideNode(tmp);
					}

					HierarchicalLayoutAlgorithm hl = new HierarchicalLayoutAlgorithm();
					new_networkView.applyLayout(hl);

					OPM_visualization.registerListenerForCurrentView();
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e.toString());
		}
		Cytoscape.getCurrentNetworkView().redrawGraph(true, true);
	}
}
