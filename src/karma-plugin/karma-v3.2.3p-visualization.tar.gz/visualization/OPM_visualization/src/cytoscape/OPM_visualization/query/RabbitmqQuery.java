/**
 * 
 */
package cytoscape.OPM_visualization.query;

import cytoscape.OPM_visualization.util.ConfigurationReader;
import edu.indiana.d2i.karma.client.messaging.Query;
import edu.indiana.dsi.karma.messaging.MessageConfig;

/**
 * @author peng A facade for query Karma database using rabbitMQ client
 */
public class RabbitmqQuery {

	// static String queryXML_before =
	// "<q0:getWorkflowGraphRequest xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:q0=\"http://www.dataandsearch.org/karma/query/2010/10/\" xmlns:xsi =\"http://www.w3.org/2001/XMLSchema-instance\"><q0:workflowID>";
	static String workflow = "urn:tool:gush:peng-virtual-machine-10719-1310833557";
	// static String queryXML_after_withAnnotation =
	// "</q0:workflowID><q0:format>OPM</q0:format><q0:informationDetailLevel>FINE</q0:informationDetailLevel></q0:getWorkflowGraphRequest>";
	// static String queryXML_after_withoutAnnotation =
	// "</q0:workflowID><q0:format>OPM</q0:format></q0:getWorkflowGraphRequest>";

	static private MessageConfig msgconf;

	public RabbitmqQuery() {

		if (msgconf == null)
			msgconf = new MessageConfig(ConfigurationReader.username,
					ConfigurationReader.password, ConfigurationReader.hostname,
					Integer.parseInt(ConfigurationReader.hostport),
					ConfigurationReader.virtualhost,
					ConfigurationReader.exchangename,
					ConfigurationReader.queuename,
					ConfigurationReader.routingkey, 0, 0);

	}

	public RabbitmqQuery(String username, String password, String hostname,
			String hostport, String virtualhost, String exchangename,
			String queuename, String routingkey) {

		if (msgconf == null)
			msgconf = new MessageConfig(username, password, hostname, Integer
					.parseInt(hostport), virtualhost, exchangename, queuename,
					routingkey, 0, 0);

	}
	
	public String getWorkflowGraphWithAnnotation(String workflowID) {
		Query query = new Query(msgconf);

		String OPM_xml = query
				.query("<q0:getWorkflowGraphRequest xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:q0=\"http://www.dataandsearch.org/karma/query/2010/10/\" xmlns:xsi =\"http://www.w3.org/2001/XMLSchema-instance\"><q0:workflowID>"
						+ workflowID
						+ "</q0:workflowID><q0:format>OPM</q0:format><q0:informationDetailLevel>FINE</q0:informationDetailLevel></q0:getWorkflowGraphRequest>");

		query.closeConnection();

		return OPM_xml;
	}

	public String getWorkflowGraphWithoutAnnotation(String workflowID) {
		Query query = new Query(msgconf);

		String OPM_xml = query
				.query("<q0:getWorkflowGraphRequest xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:q0=\"http://www.dataandsearch.org/karma/query/2010/10/\" xmlns:xsi =\"http://www.w3.org/2001/XMLSchema-instance\"><q0:workflowID>"
						+ workflowID
						+ "</q0:workflowID><q0:format>OPM</q0:format><q0:informationDetailLevel>COARSE</q0:informationDetailLevel></q0:getWorkflowGraphRequest>");

		query.closeConnection();

		return OPM_xml;
	}

	public String findAllAbstractService() {
		Query query = new Query(msgconf);

		String OPM_xml = query
				.query("<findAbstractServiceRequest xmlns=\"http://www.dataandsearch.org/karma/query/2010/10/\">"
						+ "<returnAll>true</returnAll>"
						+ "</findAbstractServiceRequest>");

		query.closeConnection();

		return OPM_xml;
	}

	public String findServiceByName(String name) {
		Query query = new Query(msgconf);

		String OPM_xml = query
				.query("<findServiceRequest xmlns=\"http://www.dataandsearch.org/karma/query/2010/10/\">  "
						+ "<name>" + name + "</name>" + "</findServiceRequest>");

		query.closeConnection();

		return OPM_xml;
	}

	public String getAbstractServiceDetailByID(String[] serviceID) {
		Query query = new Query(msgconf);
		StringBuffer query_xml = new StringBuffer();

		query_xml
				.append("<getAbstractServiceDetailRequest xmlns=\"http://www.dataandsearch.org/karma/query/2010/10/\"><uniqueIDList>");

		for (String tmp : serviceID) {
			query_xml.append("<uniqueID>" + tmp + "</uniqueID>");
		}

		query_xml.append("</uniqueIDList></getAbstractServiceDetailRequest>");

		String OPM_xml = query.query(query_xml.toString());

		query.closeConnection();

		return OPM_xml;
	}

	public String getServiceDetailByURI(String[] serviceUri) {
		Query query = new Query(msgconf);
		StringBuffer query_xml = new StringBuffer();

		query_xml
				.append("<getServiceDetailRequest xmlns=\"http://www.dataandsearch.org/karma/query/2010/10/\"><uniqueURIList>");

		for (String tmp : serviceUri) {
			query_xml.append("<uniqueURI>" + tmp + "</uniqueURI>");
		}

		query_xml.append("</uniqueURIList></getServiceDetailRequest>");

		String OPM_xml = query.query(query_xml.toString());

		query.closeConnection();

		return OPM_xml;
	}

	public String getServiceDetailByID(String[] serviceID) {
		Query query = new Query(msgconf);
		StringBuffer query_xml = new StringBuffer();

		query_xml
				.append("<ns:getServiceDetailRequest xmlns:ns=\"http://www.dataandsearch.org/karma/query/2010/10/\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"><ns:uniqueIDList>");

		for (String tmp : serviceID) {
			query_xml.append("<ns:uniqueID>" + tmp + "</ns:uniqueID>");
		}

		query_xml.append("</ns:uniqueIDList></ns:getServiceDetailRequest>");

		String OPM_xml = query.query(query_xml.toString());

		query.closeConnection();

		return OPM_xml;
	}

	public String getDataProductDetail(String[] productID) {
		Query query = new Query(msgconf);
		StringBuffer query_xml = new StringBuffer();

		query_xml
				.append("<ns:getDataProductDetailRequest xmlns:ns=\"http://www.dataandsearch.org/karma/query/2010/10/\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"><ns:dataProductIDList>");

		for (String tmp : productID) {
			query_xml
					.append("<ns:dataProductID>" + tmp + "</ns:dataProductID>");
		}

		query_xml
				.append("</ns:dataProductIDList></ns:getDataProductDetailRequest>");

		String OPM_xml = query.query(query_xml.toString());

		query.closeConnection();

		return OPM_xml;
	}

	public String getProvenanceHistory(String ID) {
		Query query = new Query(msgconf);
		StringBuffer query_xml = new StringBuffer();

		query_xml
				.append("<getProvenanceHistoryRequest xmlns=\"http://www.dataandsearch.org/karma/query/2010/10/\">");

		query_xml.append("<artifactID>" + ID + "</artifactID>");

		query_xml
				.append("<format>OPM</format><timeRange>0</timeRange><informationDetailLevel>FINE</informationDetailLevel></getProvenanceHistoryRequest>");

		String OPM_xml = query.query(query_xml.toString());

		query.closeConnection();

		return OPM_xml;
	}

	public String getDataForwardFlow(String ID) {
		Query query = new Query(msgconf);
		StringBuffer query_xml = new StringBuffer();

		query_xml
				.append("<getDataForwardFlowRequest xmlns=\"http://www.dataandsearch.org/karma/query/2010/10/\">");

		query_xml.append("<artifactID>" + ID + "</artifactID>");

		query_xml
				.append("<format>OPM</format><timeRange>0</timeRange><informationDetailLevel>FINE</informationDetailLevel></getDataForwardFlowRequest>");

		String OPM_xml = query.query(query_xml.toString());

		query.closeConnection();

		return OPM_xml;
	}

	public static void main(String[] args) {
		RabbitmqQuery rq = new RabbitmqQuery("guest", "guest", "192.168.255.162",
				"5672", "/", "KarmaExchange", "KarmaQueue", "KarmaKey");

		String[] serviceID = new String[1];
		serviceID[0] = "File_4562";
		String OPM_xml = rq.getDataForwardFlow(serviceID[0]);

		System.out.println(OPM_xml);
	}
}
