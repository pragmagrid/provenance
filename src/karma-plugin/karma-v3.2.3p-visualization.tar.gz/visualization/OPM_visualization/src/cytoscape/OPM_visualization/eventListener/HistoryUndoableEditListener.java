package cytoscape.OPM_visualization.eventListener;

import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;

import cytoscape.OPM_visualization.OPM_visualization;
import cytoscape.util.undo.UndoAction;

public class HistoryUndoableEditListener implements UndoableEditListener {

	@Override
	public void undoableEditHappened(UndoableEditEvent arg0) {
		System.out.println("undoableEditHappened:" + arg0.toString());

		if (arg0.toString().contains("UndoableEditEvent")) {
			if (arg0.toString().contains("DeleteEdit")) {
				System.out.println("DeleteEdit added");
				OPM_visualization.undoActionList.put(
						OPM_visualization.currentNavState.getIdentifier(), arg0
								.getEdit());
			}

		}
		new UndoAction().actionPerformed(null);
	}

}
