package cytoscape.OPM_visualization;

import java.awt.event.ActionEvent;
import cytoscape.Cytoscape;
import cytoscape.plugin.CytoscapePlugin;
import cytoscape.util.CytoscapeAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import cytoscape.CyNetwork;
import cytoscape.CyNode;
import cytoscape.OPM_visualization.actionListener.EdgeExpendAction;
import cytoscape.OPM_visualization.eventListener.AttributeModificationListener;
import cytoscape.OPM_visualization.eventListener.AutomaticalLoadingEventListener;
import cytoscape.OPM_visualization.eventListener.EdgeAttributeViewListener;
import cytoscape.OPM_visualization.eventListener.FilteredPaletteNetworkEditEventHandler;
import cytoscape.OPM_visualization.eventListener.MyNodeContextMenuListener;
import cytoscape.OPM_visualization.eventListener.NetworkViewModificationListener;
import cytoscape.OPM_visualization.eventListener.NodeAttributeViewListener;
import cytoscape.OPM_visualization.layout.ClockwiseAttributeCircleLayout;
import cytoscape.OPM_visualization.layout.ForceDirectedProvenanceHistoryLayout;
import cytoscape.OPM_visualization.layout.MyLayout;
import cytoscape.OPM_visualization.layout.NSLayout;
import cytoscape.OPM_visualization.layout.NSLayoutExtD_Circle;
import cytoscape.OPM_visualization.layout.NSLayoutExtNode;
import cytoscape.OPM_visualization.layout.NSLayoutExtRD_Circle;
import cytoscape.OPM_visualization.layout.NSLayoutExtR_Circle;
import cytoscape.OPM_visualization.layout.StringEmbededProvenanceHistoryLayout;
import cytoscape.OPM_visualization.util.DetailLoader;
import cytoscape.OPM_visualization.util.GraphBuilder;
import cytoscape.data.CyAttributes;

import java.io.File;
import cytoscape.view.CyNetworkView;
import cytoscape.visual.ArrowShape;
import cytoscape.visual.CalculatorCatalog;
import cytoscape.visual.EdgeAppearanceCalculator;
import cytoscape.visual.GlobalAppearanceCalculator;
import cytoscape.visual.NodeAppearanceCalculator;
import cytoscape.visual.NodeShape;
import cytoscape.visual.VisualMappingManager;
import cytoscape.visual.VisualPropertyType;
import cytoscape.visual.VisualStyle;
import cytoscape.visual.calculators.BasicCalculator;
import cytoscape.visual.calculators.Calculator;
import cytoscape.visual.mappings.DiscreteMapping;
import cytoscape.visual.mappings.ObjectMapping;
import cytoscape.visual.mappings.PassThroughMapping;
import java.awt.Color;

import cytoscape.layout.CyLayoutAlgorithm;
import cytoscape.layout.CyLayouts;

import java.awt.event.WindowEvent;

import org.freehep.swing.ExtensionFileFilter;
import java.util.HashMap;
import csplugins.layout.algorithms.GroupAttributesLayout;

import org.openprovenance.model.v1_1_a.*;
import javax.swing.undo.UndoableEdit;
import java.awt.event.*;

/**
 * @author Peng
 */

/*
 * A simple plugin to visualize OPM graph. Deploy this plugin (KarmaGraph.jar)
 * to the plugins directory. An image icon (geni logo) will show up on the
 * toolbar. Click on the icon will trigger a message box.
 */
public class OPM_visualization extends CytoscapePlugin {

	public static String filename;
	GraphConfigPanel gp = null;
	public static boolean useAutomaticLoading = false;

	protected ImageIcon icon_geni = new ImageIcon(getClass().getResource(
			"/geni_logo.jpg"));

	// This network is used to hold the provenance information of navigating the
	// graph
	public static CyNetwork historyNetwork = null;
	public static CyNode currentNavState = null;

	public static HashMap<String, UndoableEdit> undoActionList = new HashMap<String, UndoableEdit>();

	// static{
	// historyNetwork = Cytoscape.createNetwork("Navigate History Provenance",
	// true);
	// currentNavState = Cytoscape.getCyNode("Navigation Root", true);
	// historyNetwork.addNode(currentNavState);
	// }

	public OPM_visualization() {

		CyLayoutAlgorithm layout = new ClockwiseAttributeCircleLayout();
		// layout.setLayoutAttribute("timestep");
		MyLayout layout2 = new MyLayout();
		NSLayout nslayout = new NSLayout();
		NSLayoutExtNode nslayoutext1 = new NSLayoutExtNode();
		// NSLayoutExtRD_Square nslayoutext2 = new NSLayoutExtRD_Square();
		NSLayoutExtRD_Circle nslayoutext3 = new NSLayoutExtRD_Circle();
		NSLayoutExtR_Circle nslayoutext4 = new NSLayoutExtR_Circle();
		NSLayoutExtD_Circle nslayoutext5 = new NSLayoutExtD_Circle();
		StringEmbededProvenanceHistoryLayout provenancelayout1 = new StringEmbededProvenanceHistoryLayout();
		ForceDirectedProvenanceHistoryLayout provenancelayout2 = new ForceDirectedProvenanceHistoryLayout();

		CyLayouts.addLayout(layout, "GENI OPMLayout");
		CyLayouts.addLayout(layout2, "GENI OPMLayout");
		CyLayouts.addLayout(nslayout, "GENI OPMLayout");
		CyLayouts.addLayout(nslayoutext1, "GENI OPMLayout");
		// CyLayouts.addLayout(nslayoutext2, "GENI OPMLayout");
		CyLayouts.addLayout(nslayoutext3, "GENI OPMLayout");
		CyLayouts.addLayout(nslayoutext4, "GENI OPMLayout");
		CyLayouts.addLayout(nslayoutext5, "GENI OPMLayout");
		CyLayouts.addLayout(provenancelayout1, "GENI OPMLayout");
		CyLayouts.addLayout(provenancelayout2, "GENI OPMLayout");

		// (1) Create an toolbarAction
		MyPluginToolBarAction toolbarAction = new MyPluginToolBarAction(
				icon_geni, this);
		// (2) add the action to Cytoscape toolbar
		Cytoscape.getDesktop().getCyMenus().addCytoscapeAction(
				(CytoscapeAction) toolbarAction);

	}

	public static final String OPM_VsName = "OPM Visual Style";
	public static final String W3C_VsName = "W3C Prov Visual Style";

	public class MyPluginToolBarAction extends CytoscapeAction implements
			WindowListener {

		/**
		 * 
		 */
		private static final long serialVersionUID = 7009055641207623850L;

		public MyPluginToolBarAction(ImageIcon icon, OPM_visualization myPlugin) {
			super("", icon);
			// Set SHORT_DESCRIPTION; used to create tool-tip
			this.putValue(Action.SHORT_DESCRIPTION,
					"OPM Visulization Plugin tool tip");
		}

		public void actionPerformed(ActionEvent e) {
			try {

				DetailLoader.initialize();

				gp = new GraphConfigPanel(null);
				gp.addWindowListener(this);
				gp.setDefaultCloseOperation(GraphConfigPanel.DISPOSE_ON_CLOSE);
				double x = Cytoscape.getDesktop().getX()
						+ Cytoscape.getDesktop().getWidth() / 3;
				double y = Cytoscape.getDesktop().getY()
						+ Cytoscape.getDesktop().getHeight() / 5;
				gp.setLocation((int) x, (int) y);

				gp.pack();
				gp.setVisible(true);

			} catch (Exception e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e1
						.toString());
			} finally {
				registerListenerForCurrentView();
			}
		}

		/**
		 * DOCUMENT ME!
		 * 
		 * @return DOCUMENT ME!
		 */
		public boolean isInToolBar() {
			return true;
		}

		/**
		 * DOCUMENT ME!
		 * 
		 * @return DOCUMENT ME!
		 */
		public boolean isInMenuBar() {
			return true;
		}

		@Override
		public void windowActivated(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowClosed(WindowEvent arg0) {
			if (!gp.createNewGraph) {
				return;
			}

			useAutomaticLoading = !gp.withAnnotation;

			CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();
			CyAttributes cyEdgeAttrs = Cytoscape.getEdgeAttributes();

			// //////////////////////

			JFileChooser fileChooser = new JFileChooser();

			ExtensionFileFilter filter = new ExtensionFileFilter();
			filter.addExtension("xml");
			filter.setDescription("xml files");
			fileChooser.setFileFilter(filter);

			// if set to null, will be displayed in the middle of window
			int returnVal = fileChooser.showOpenDialog(Cytoscape.getDesktop());
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				String filePath = fileChooser.getSelectedFile()
						.getAbsolutePath();

				filename = filePath;
			} else {
				return;
			}

			// create a network without a view; boolean indicate whether to
			// create the view at the same time
			CyNetwork cyNetwork = Cytoscape.createNetwork(
					"network:" + filename, true);

			try {

				File xmlFile = new File(filename);
				OpmGraphDocument doc = OpmGraphDocument.Factory.parse(xmlFile);

				{
					GraphBuilder gbuilder = new GraphBuilder();
					gbuilder.build(doc, cyNetwork, cyNodeAttrs, cyEdgeAttrs);
				}
			} catch (Exception ex) {
				JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
						"Exception!" + ex.getMessage());
				ex.printStackTrace();

			}

			// /////////////////////////////////
			// //////////////////////////////

			if (cyNetwork.getNodeCount() == 0) {
				JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
						"There is no node!");
				return;
			}

			// Inform others via property change event.
			Cytoscape.firePropertyChange(Cytoscape.ATTRIBUTES_CHANGED, null,
					null);

			// ///////////////////////////
			// ///////////////////////////

			CyNetworkView networkView = Cytoscape.getCurrentNetworkView();
			// networkView.applyLayout(new HierarchicalLayoutAlgorithm());
			// networkView.applyLayout(new CircularLayoutAlgorithm());
			GroupAttributesLayout gal = new GroupAttributesLayout();
			gal.setLayoutAttribute("NodeType");
			networkView.applyLayout(gal);

			// get the VisualMappingManager and CalculatorCatalog
			VisualMappingManager manager = Cytoscape.getVisualMappingManager();
			CalculatorCatalog catalog = manager.getCalculatorCatalog();

			// check to see if a visual style with this name already exists
			VisualStyle vs = catalog.getVisualStyle(OPM_VsName);
			if (vs == null) {
				// if not, create it and add it to the catalog
				vs = createOPMVisualStyle(cyNetwork);
				catalog.addVisualStyle(vs);
			}

			networkView.setVisualStyle(vs.getName()); // not strictly necessary

			// actually apply the visual style
			manager.setVisualStyle(vs);
			networkView.redrawGraph(true, true);

			// ///////////////////////////////////
			// //////////////////////////////////
			if (Cytoscape.getCurrentNetworkView().getTitle() == null
					|| Cytoscape.getCurrentNetworkView().getTitle()
							.equalsIgnoreCase("null")) {
				JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
						"No network view!");
				return;
			}

			{
				registerListenerForCurrentView();
			}
		}

		@Override
		public void windowClosing(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowDeactivated(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowDeiconified(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowIconified(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowOpened(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}
	}

	public static VisualStyle createOPMVisualStyle(CyNetwork network) {

		NodeAppearanceCalculator nodeAppCalc = new NodeAppearanceCalculator();
		EdgeAppearanceCalculator edgeAppCalc = new EdgeAppearanceCalculator();
		GlobalAppearanceCalculator globalAppCalc = new GlobalAppearanceCalculator();

		globalAppCalc.setDefaultBackgroundColor(new Color(153, 153, 153));

		// Passthrough Mapping - set node label
		PassThroughMapping pm1 = new PassThroughMapping(new String(),
				"node_label");

		BasicCalculator nlc = new BasicCalculator(
				"Example Node Label Calculator", pm1,
				VisualPropertyType.NODE_LABEL);

		nodeAppCalc.setCalculator(nlc);

		// Discrete Mapping - set node shapes
		DiscreteMapping disMapping = new DiscreteMapping(NodeShape.RECT,
				ObjectMapping.NODE_MAPPING);
		disMapping.setControllingAttributeName("NodeType", network, false);
		disMapping.putMapValue("PROCESS", NodeShape.ROUND_RECT);
		disMapping.putMapValue("ARTIFACT", NodeShape.ELLIPSE);
		disMapping.putMapValue("SUBNETWORK", NodeShape.OCTAGON);
		disMapping.putMapValue("AGENT", NodeShape.OCTAGON);

		Calculator shapeCalculator = new BasicCalculator(
				"Example Node Shape Calculator", disMapping,
				VisualPropertyType.NODE_SHAPE);
		nodeAppCalc.setCalculator(shapeCalculator);

		// Discrete Mapping - Set node color
		final Color NODE_COLOR = new Color(10, 10, 10);

		DiscreteMapping nodeColor = new DiscreteMapping(NODE_COLOR, "NodeType",
				ObjectMapping.NODE_MAPPING);

		nodeColor.putMapValue("PROCESS", new Color(50, 255, 50));
		nodeColor.putMapValue("ARTIFACT", new Color(255, 50, 255));
		nodeColor.putMapValue("SUBNETWORK", new Color(255, 255, 255));
		nodeColor.putMapValue("AGENT", new Color(255, 50, 50));

		Calculator nodeColorCalc = new BasicCalculator("EdgeColorMapping",
				nodeColor, VisualPropertyType.NODE_FILL_COLOR);

		nodeAppCalc.setCalculator(nodeColorCalc);

		// set edge label
		PassThroughMapping pm_e = new PassThroughMapping(new String(),
				"interaction");

		BasicCalculator edc = new BasicCalculator(
				"Example Edge Label Calculator", pm_e,
				VisualPropertyType.EDGE_LABEL);

		edgeAppCalc.setCalculator(edc);

		// Discrete Mapping - Set edge color
		final Color EDGE_COLOR = new Color(10, 10, 10);

		DiscreteMapping edgeColor = new DiscreteMapping(EDGE_COLOR,
				"interaction", ObjectMapping.EDGE_MAPPING);

		edgeColor.putMapValue("used", new Color(100, 255, 100));
		edgeColor.putMapValue("wasTriggeredBy", Color.YELLOW);
		edgeColor.putMapValue("wasGeneratedBy", new Color(204, 204, 204));
		edgeColor.putMapValue("wasDerivedFrom", new Color(0, 200, 255));
		edgeColor.putMapValue("wasControlledBy", Color.WHITE);
		edgeColor.putMapValue("wasExecutedOn", Color.magenta);
		edgeColor.putMapValue("wasConnectedTo", Color.lightGray);

		Calculator edgeColorCalc = new BasicCalculator("EdgeColorMapping",
				edgeColor, VisualPropertyType.EDGE_COLOR);

		edgeAppCalc.setCalculator(edgeColorCalc);

		// Discrete Mapping - Set edge target arrow shape
		DiscreteMapping arrowMapping = new DiscreteMapping(ArrowShape.NONE,
				ObjectMapping.EDGE_MAPPING);
		arrowMapping.setControllingAttributeName("interaction", network, false);
		arrowMapping.putMapValue("wasTriggeredBy", ArrowShape.ARROW);
		arrowMapping.putMapValue("wasGeneratedBy", ArrowShape.CIRCLE);
		arrowMapping.putMapValue("wasDerivedFrom", ArrowShape.CIRCLE);
		arrowMapping.putMapValue("used", ArrowShape.DELTA);
		arrowMapping.putMapValue("wasControlledBy", ArrowShape.DIAMOND);
		arrowMapping.putMapValue("wasExecutedOn", ArrowShape.ARROW);
		arrowMapping.putMapValue("wasConnectedTo", ArrowShape.ARROW);

		Calculator edgeArrowCalculator = new BasicCalculator(
				"Example Edge Arrow Shape Calculator", arrowMapping,
				VisualPropertyType.EDGE_TGTARROW_SHAPE);
		edgeAppCalc.setCalculator(edgeArrowCalculator);

		// Create the visual style
		VisualStyle visualStyle = new VisualStyle(OPM_VsName, nodeAppCalc,
				edgeAppCalc, globalAppCalc);

		return visualStyle;
	}

	public static VisualStyle createW3CProvVisualStyle(CyNetwork network) {

		NodeAppearanceCalculator nodeAppCalc = new NodeAppearanceCalculator();
		EdgeAppearanceCalculator edgeAppCalc = new EdgeAppearanceCalculator();
		GlobalAppearanceCalculator globalAppCalc = new GlobalAppearanceCalculator();

		globalAppCalc.setDefaultBackgroundColor(new Color(153, 153, 153));

		// Passthrough Mapping - set node label
		PassThroughMapping pm1 = new PassThroughMapping(new String(),
				"node_label");

		BasicCalculator nlc = new BasicCalculator(
				"Example Node Label Calculator", pm1,
				VisualPropertyType.NODE_LABEL);

		nodeAppCalc.setCalculator(nlc);

		// Discrete Mapping - set node shapes
		DiscreteMapping disMapping = new DiscreteMapping(NodeShape.RECT,
				ObjectMapping.NODE_MAPPING);
		disMapping.setControllingAttributeName("NodeType", network, false);
		disMapping.putMapValue("ACTIVITY", NodeShape.RECT);
		disMapping.putMapValue("ENTITY", NodeShape.ELLIPSE);
		disMapping.putMapValue("SUBNETWORK", NodeShape.OCTAGON);
		disMapping.putMapValue("AGENT", NodeShape.TRIANGLE);

		Calculator shapeCalculator = new BasicCalculator(
				"Example Node Shape Calculator", disMapping,
				VisualPropertyType.NODE_SHAPE);
		nodeAppCalc.setCalculator(shapeCalculator);

		// Discrete Mapping - Set node color
		final Color NODE_COLOR = new Color(10, 10, 10);

		DiscreteMapping nodeColor = new DiscreteMapping(NODE_COLOR, "NodeType",
				ObjectMapping.NODE_MAPPING);

		nodeColor.putMapValue("ACTIVITY", new Color(159, 177, 252));
		nodeColor.putMapValue("ENTITY", new Color(255, 252, 135));
		nodeColor.putMapValue("SUBNETWORK", new Color(255, 255, 255));
		nodeColor.putMapValue("AGENT", new Color(253, 178, 102));

		Calculator nodeColorCalc = new BasicCalculator("EdgeColorMapping",
				nodeColor, VisualPropertyType.NODE_FILL_COLOR);

		nodeAppCalc.setCalculator(nodeColorCalc);

		// set edge label
		PassThroughMapping pm_e = new PassThroughMapping(new String(),
				"interaction");

		BasicCalculator edc = new BasicCalculator(
				"Example Edge Label Calculator", pm_e,
				VisualPropertyType.EDGE_LABEL);

		edgeAppCalc.setCalculator(edc);

		// Discrete Mapping - Set edge color
		final Color EDGE_COLOR = new Color(10, 10, 10);

		DiscreteMapping edgeColor = new DiscreteMapping(EDGE_COLOR,
				"interaction", ObjectMapping.EDGE_MAPPING);

		edgeColor.putMapValue("used", new Color(100, 255, 100));
		edgeColor.putMapValue("wasInformedBy", Color.YELLOW);
		edgeColor.putMapValue("wasGeneratedBy", new Color(204, 204, 204));
		edgeColor.putMapValue("wasDerivedFrom", new Color(0, 200, 255));
		edgeColor.putMapValue("wasAssociatedWith", Color.orange);
		edgeColor.putMapValue("wasAttributedTo", Color.magenta);
		edgeColor.putMapValue("actedOnBehalfOf", Color.lightGray);
		edgeColor.putMapValue("wasRevisionOf", Color.cyan);
		edgeColor.putMapValue("wasQuotedFrom", Color.darkGray);
		edgeColor.putMapValue("specializationOf", Color.green);
		edgeColor.putMapValue("alternateOf", Color.blue);
		edgeColor.putMapValue("hadPlan", Color.gray);

		Calculator edgeColorCalc = new BasicCalculator("EdgeColorMapping",
				edgeColor, VisualPropertyType.EDGE_COLOR);

		edgeAppCalc.setCalculator(edgeColorCalc);

		// Discrete Mapping - Set edge target arrow shape
		DiscreteMapping arrowMapping = new DiscreteMapping(ArrowShape.NONE,
				ObjectMapping.EDGE_MAPPING);
		arrowMapping.setControllingAttributeName("interaction", network, false);
		arrowMapping.putMapValue("used", ArrowShape.DELTA);
		arrowMapping.putMapValue("wasInformedBy", ArrowShape.ARROW);
		arrowMapping.putMapValue("wasGeneratedBy", ArrowShape.DELTA);
		arrowMapping.putMapValue("wasDerivedFrom", ArrowShape.CIRCLE);
		arrowMapping.putMapValue("wasAssociatedWith", ArrowShape.DIAMOND);
		arrowMapping.putMapValue("wasAttributedTo", ArrowShape.DIAMOND);
		arrowMapping.putMapValue("actedOnBehalfOf", ArrowShape.DIAMOND);
		arrowMapping.putMapValue("wasRevisionOf", ArrowShape.CIRCLE);
		arrowMapping.putMapValue("wasQuotedFrom", ArrowShape.CIRCLE);
		arrowMapping.putMapValue("specializationOf", ArrowShape.T);
		arrowMapping.putMapValue("alternateOf", ArrowShape.T);
		arrowMapping.putMapValue("hadPlan", ArrowShape.HALF_ARROW_BOTTOM);

		Calculator edgeArrowCalculator = new BasicCalculator(
				"Example Edge Arrow Shape Calculator", arrowMapping,
				VisualPropertyType.EDGE_TGTARROW_SHAPE);
		edgeAppCalc.setCalculator(edgeArrowCalculator);

		// Create the visual style
		VisualStyle visualStyle = new VisualStyle(W3C_VsName, nodeAppCalc,
				edgeAppCalc, globalAppCalc);

		return visualStyle;
	}

	public static void createOPMVisStyleForCurrentView() {
		CyNetwork cyNetwork = Cytoscape.getCurrentNetwork();
		CyNetworkView networkView = Cytoscape.getCurrentNetworkView();
		// get the VisualMappingManager and CalculatorCatalog
		VisualMappingManager manager = Cytoscape.getVisualMappingManager();
		CalculatorCatalog catalog = manager.getCalculatorCatalog();

		// check to see if a visual style with this name already exists
		VisualStyle vs = catalog.getVisualStyle(OPM_VsName);
		if (vs == null) {
			// if not, create it and add it to the catalog
			vs = OPM_visualization.createOPMVisualStyle(cyNetwork);
			catalog.addVisualStyle(vs);
		}

		networkView.setVisualStyle(vs.getName()); // not strictly necessary

		// actually apply the visual style
		manager.setVisualStyle(vs);
		networkView.redrawGraph(true, true);
	}

	public static void createW3CProvVisStyleForCurrentView() {
		CyNetwork cyNetwork = Cytoscape.getCurrentNetwork();
		CyNetworkView networkView = Cytoscape.getCurrentNetworkView();
		// get the VisualMappingManager and CalculatorCatalog
		VisualMappingManager manager = Cytoscape.getVisualMappingManager();
		CalculatorCatalog catalog = manager.getCalculatorCatalog();

		// check to see if a visual style with this name already exists
		VisualStyle vs = catalog.getVisualStyle(W3C_VsName);
		if (vs == null) {
			// if not, create it and add it to the catalog
			vs = OPM_visualization.createW3CProvVisualStyle(cyNetwork);
			catalog.addVisualStyle(vs);
		}

		networkView.setVisualStyle(vs.getName()); // not strictly necessary

		// actually apply the visual style
		manager.setVisualStyle(vs);
		networkView.redrawGraph(true, true);
	}

	public static void registerListenerForCurrentView() {
		MyNodeContextMenuListener l = new MyNodeContextMenuListener();
		Cytoscape.getCurrentNetworkView().addNodeContextMenuListener(l);

		Cytoscape.getCurrentNetworkView().getComponent().addMouseListener(
				new NodeAttributeViewListener());
		Cytoscape.getCurrentNetworkView().getComponent().addMouseListener(
				new EdgeExpendAction());
		Cytoscape.getCurrentNetworkView().getComponent().addMouseListener(
				new EdgeAttributeViewListener());

		if (useAutomaticLoading)
			Cytoscape.getCurrentNetworkView().addGraphViewChangeListener(
					new AutomaticalLoadingEventListener());

		// remove the build-in double click listener
		MouseListener[] ml = Cytoscape.getCurrentNetworkView().getComponent()
				.getMouseListeners();
		for (int i = 0; i < ml.length; i++) {
			// System.out.println(ml[i].toString());
			if (ml[i].toString().contains("PaletteNetworkEdit")) {
				Cytoscape.getCurrentNetworkView().getComponent()
						.removeMouseListener(ml[i]);

				Cytoscape.getCurrentNetworkView().getComponent()
						.addMouseListener(
								new FilteredPaletteNetworkEditEventHandler(
										ml[i]));
			}
		}

		new UpdatePopupListenerOnNetworkPanel().update();
	}

	public static void registerListenerForHistoryNetwork() {
		Cytoscape.getNodeAttributes().getMultiHashMap().addDataListener(
				new AttributeModificationListener());
		Cytoscape.getCurrentNetworkView().addGraphViewChangeListener(
				new NetworkViewModificationListener());
	}
}
