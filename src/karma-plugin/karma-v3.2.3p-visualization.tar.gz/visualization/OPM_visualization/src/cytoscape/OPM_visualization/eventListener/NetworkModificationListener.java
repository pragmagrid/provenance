package cytoscape.OPM_visualization.eventListener;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import csplugins.layout.algorithms.hierarchicalLayout.HierarchicalLayoutAlgorithm;

import cytoscape.CyEdge;
import cytoscape.CyNetwork;
import cytoscape.CyNode;
import cytoscape.Cytoscape;
import cytoscape.OPM_visualization.OPM_visualization;
import cytoscape.data.CyAttributes;
import cytoscape.data.Semantics;

public class NetworkModificationListener implements PropertyChangeListener {

	/**
	 *
	 */
	public static final String MODIFIED = "Modified";

	/**
	 *
	 */
	public static final String CLEAN = "Clean";
	private static HashMap<CyNetwork, String> networkStateMap = new HashMap<CyNetwork, String>();

	/**
	 *
	 */
	public NetworkModificationListener() {
		super();

		Cytoscape.getDesktop().getSwingPropertyChangeSupport()
				.addPropertyChangeListener(Cytoscape.NETWORK_MODIFIED, this);
		Cytoscape.getDesktop().getSwingPropertyChangeSupport()
				.addPropertyChangeListener(Cytoscape.NETWORK_SAVED, this);
		Cytoscape.getDesktop().getSwingPropertyChangeSupport()
				.addPropertyChangeListener(Cytoscape.NETWORK_CREATED, this);
		Cytoscape.getDesktop().getSwingPropertyChangeSupport();

		Cytoscape.getSwingPropertyChangeSupport().addPropertyChangeListener(
				this);

	}

	public void propertyChange(PropertyChangeEvent e) {
		System.out.println("NetworkModificationListener: " + e.toString());
		if (e.getPropertyName().equals(Cytoscape.NETWORK_MODIFIED)) {
			CyNetwork net = (CyNetwork) e.getNewValue();

			if (net instanceof CyNetwork) {
				setModified(net, MODIFIED);
			}

			String date = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy")
					.format(new Date());

			CyNode newNode = Cytoscape.getCyNode("NETWORK_MODIFIED@" + date,
					true);
			CyEdge newEdge = Cytoscape.getCyEdge(newNode,
					OPM_visualization.currentNavState, Semantics.INTERACTION,
					"wasDerivedFrom", true);
			OPM_visualization.historyNetwork.addNode(newNode);
			OPM_visualization.historyNetwork.addEdge(newEdge);

			OPM_visualization.currentNavState = newNode;

			// set the provenance node's attribute
			CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();
			CyAttributes cyEdgeAttrs = Cytoscape.getEdgeAttributes();
			cyNodeAttrs.setAttribute(newNode.getIdentifier(), "node_label",
					newNode.getIdentifier());
			cyNodeAttrs.setAttribute(newNode.getIdentifier(), "NodeType",
					"ARTIFACT");
			cyNodeAttrs.setAttribute(newNode.getIdentifier(), "Time", date);
			cyEdgeAttrs.setAttribute(newEdge.getIdentifier(), "NoEarlierThan",
					date);
			cyEdgeAttrs.setAttribute(newEdge.getIdentifier(), "NoLaterThan",
					date);

			// re-layout the provenance graph
			Cytoscape.getNetworkView(
					OPM_visualization.historyNetwork.getIdentifier())
					.applyLayout(new HierarchicalLayoutAlgorithm());

		} else if (e.getPropertyName().equals(Cytoscape.NETWORK_SAVED)) {
			// MLC 09/19/05 BEGIN:
			// CyNetwork net = (CyNetwork) e.getNewValue();
			CyNetwork net = (CyNetwork) (((Object[]) e.getNewValue())[0]);

			// MLC 09/19/05 END.
			if (net instanceof CyNetwork) {
				setModified(net, CLEAN);
			}
		}
	}

	/**
	 * @param net
	 */
	public static boolean isModified(CyNetwork net) {
		Object modObj = networkStateMap.get(net);

		if (modObj == null) // no network in table, so it can't be modified
		{
			return false;
		} else if (modObj.toString().equals(MODIFIED)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * set the state of the network
	 * 
	 * @param net
	 * @param state
	 *            values supported in this version: CLEAN, MODIFIED
	 */
	public static void setModified(CyNetwork net, String state) {
		networkStateMap.put(net, state);
	}
}
