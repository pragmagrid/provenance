package cytoscape.Karma_query;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import cytoscape.Cytoscape;
import cytoscape.GUI.QueryPanel;
import cytoscape.GUI.RegistryQueryPanel;
import cytoscape.GUI.ServerConfigPanel;
import cytoscape.plugin.CytoscapePlugin;
import cytoscape.util.CytoscapeAction;
import javax.swing.Action;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.SwingConstants;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.concurrent.Semaphore;

import org.freehep.swing.ExtensionFileFilter;

import sun.awt.WindowClosingListener;

/**
 * @author Peng A simple plugin to get OPM xml from Karma database. Deploy this
 *         plugin (Karma_query.jar) to the plugins directory. An image icon
 *         (karma logo) will show up on the toolbar. Click on the icon will
 *         trigger a message box.
 */
public class Karma_query extends CytoscapePlugin {

	ServerConfigPanel scp = null;
	QueryPanel qp = null;
//	RegistryQueryPanel rqp = null;
	static int response = -1;

	public static String filename;
	static private ConfigurationReader conf_reader;

	static int method = -1;

	protected ImageIcon icon_karma = new ImageIcon(getClass().getResource(
			"/karma.jpg"));

	public Karma_query() {

		// (1) Create an toolbarAction

		KarmaPluginToolBarAction karmaToolbarAction = new KarmaPluginToolBarAction(
				icon_karma, this);
		// (2) add the action to Cytoscape toolbar
		Cytoscape.getDesktop().getCyMenus().addCytoscapeAction(
				(CytoscapeAction) karmaToolbarAction);

		/*
		 * reading configuration
		 */

		conf_reader = ConfigurationReader.getInstance();
	}

	public class KarmaPluginToolBarAction extends CytoscapeAction implements
			WindowListener {

		/**
		 * 
		 */
		private static final long serialVersionUID = -7118436127661130349L;

		public KarmaPluginToolBarAction(ImageIcon icon, Karma_query myPlugin) {
			super("", icon);
			// Set SHORT_DESCRIPTION; used to create tool-tip
			this.putValue(Action.SHORT_DESCRIPTION, "Karma Client");
		}

		public void actionPerformed(ActionEvent e) {
			// ... Text to put on the buttons.
			// String[] choices = { "Axis2", "RabbitMQ", "Quit" };
			//
			// if (method == -1) {
			// response = JOptionPane.showOptionDialog(null // Center in
			// // window.
			// , "Choose the Query Client" // Message
			// , "Karma Client" // Title in titlebar
			// , JOptionPane.YES_NO_OPTION // Option type
			// , JOptionPane.PLAIN_MESSAGE // messageType
			// , null // Icon (none)
			// , choices // Button text as above.
			// , "RabbitMQ" // Default button's label
			// );
			// } else {
			// response = method;
			// }
			//
			// if (response != 0 && response != 1) {
			// return;
			// }

			// String setWorkflowID = JOptionPane.showInputDialog(Cytoscape
			// .getDesktop(), "Enter WorkflowID");
			//
			// if (setWorkflowID == null) {
			// return;
			// }

			try {

				scp = new ServerConfigPanel(null);
				scp.setDefaultCloseOperation(scp.DISPOSE_ON_CLOSE);
				scp.addWindowListener(this);
				double x1 = Cytoscape.getDesktop().getX()
						+ Cytoscape.getDesktop().getWidth() / 3;
				double y1 = Cytoscape.getDesktop().getY()
						+ Cytoscape.getDesktop().getHeight() / 5;
				scp.setLocation((int) x1, (int) y1);

				scp.pack();
				scp.setVisible(true);

			} catch (Exception e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e1
						.toString());
			}

		}

		public boolean isInToolBar() {
			return true;
		}

		public boolean isInMenuBar() {
			return true;
		}

		@Override
		public void windowActivated(WindowEvent arg0) {
			// TODO Auto-generated method stub
			// System.out.println("Entered windowActivated");
		}

		@Override
		public void windowClosing(WindowEvent arg0) {
			// TODO Auto-generated method stub
			// System.out.println("Entered windowClosing");
		}

		@Override
		public void windowClosed(WindowEvent arg0) {
			// TODO Auto-generated method stub
			// System.out.println("Entered windowClosed");
			if (!scp.createNewGraph)
				return;

//			rqp = new RegistryQueryPanel(null);
//			rqp.setDefaultCloseOperation(scp.DISPOSE_ON_CLOSE);
//			rqp.addWindowListener(new workflowQueryListener());
//			double x1 = Cytoscape.getDesktop().getX()
//					+ Cytoscape.getDesktop().getWidth() / 3;
//			double y1 = Cytoscape.getDesktop().getY()
//					+ Cytoscape.getDesktop().getHeight() / 4;
//			rqp.setLocation((int) x1, (int) y1);
//
//			rqp.setVisible(true);
			
			qp = new QueryPanel(null);
//			qp.addWindowListener(this);
			qp.addWindowListener(new workflowQueryListener());
			qp.setDefaultCloseOperation(qp.DISPOSE_ON_CLOSE);
			double x = Cytoscape.getDesktop().getX()
					+ Cytoscape.getDesktop().getWidth() / 3;
			double y = Cytoscape.getDesktop().getY()
					+ Cytoscape.getDesktop().getHeight() / 3;
			qp.setLocation((int) x, (int) y);

			qp.setVisible(true);
		}

		@Override
		public void windowDeactivated(WindowEvent arg0) {
			// TODO Auto-generated method stub
			// System.out.println("Entered windowDeactivated");
		}

		@Override
		public void windowDeiconified(WindowEvent arg0) {
			// TODO Auto-generated method stub
			// System.out.println("Entered windowDeiconified");
		}

		@Override
		public void windowIconified(WindowEvent arg0) {
			// TODO Auto-generated method stub
			// System.out.println("Entered windowIconified");
		}

		@Override
		public void windowOpened(WindowEvent arg0) {
			// TODO Auto-generated method stub
			// System.out.println("Entered windowOpened");
		}
	}

	class workflowQueryListener implements WindowListener {

		@Override
		public void windowActivated(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowClosed(WindowEvent arg0) {
			// TODO Auto-generated method stub
			// System.out.println("Entered retrieval");
			try {

				String graph_response = null;
				String graph = null;

				// String setWorkflowID = qp.ID;
				// boolean withAnnotation = qp.withAnnotation;

				if (!qp.doRetrieval)
					return;

				if (scp.useAxis2) {
					KarmaAxis2Query axis2Tester = new KarmaAxis2Query(
							ConfigurationReader.serviceURL);
					if (qp.withAnnotation)
						graph_response = axis2Tester
								.getWorkflowGraphWithAnnotation(qp.ID);
					else
						graph_response = axis2Tester
								.getWorkflowGraphWithoutAnnotation(qp.ID);
				} else if (scp.useRabbitmq) {
					RabbitmqQuery rq = new RabbitmqQuery();
					if (qp.withAnnotation)
						graph_response = rq
								.getWorkflowGraphWithAnnotation(qp.ID);
					else
						graph_response = rq
								.getWorkflowGraphWithoutAnnotation(qp.ID);
				} else
					return;

				/*
				 * Re-organize the result xml into a opm xml
				 */
				int start = graph_response.lastIndexOf("<v1:opmGraph");
				int end = graph_response.lastIndexOf("<");

				if (start == -1 || end == -1) {
					graph = graph_response;

					JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
							"An invalid OPM graph returned");
				} else
					graph = graph_response.substring(start, end);

				JFileChooser fileChooser = new JFileChooser();

				ExtensionFileFilter filter = new ExtensionFileFilter();
				filter.addExtension("xml");
				filter.setDescription("xml files");
				fileChooser.setFileFilter(filter);

				// if set to null, will be displayed in the middle of window
				int returnVal = fileChooser.showSaveDialog(Cytoscape
						.getDesktop());
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					String filePath = fileChooser.getSelectedFile()
							.getAbsolutePath();
					String save_file_name = filePath;

					FileWriter fw;
					if (save_file_name.contains(".xml"))
						fw = new FileWriter(save_file_name);
					else
						fw = new FileWriter(save_file_name + ".xml");
					BufferedWriter bw = new BufferedWriter(fw);
					bw.write(graph);
					bw.flush();
					bw.close();
					fw.close();
				}

			} catch (Exception e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e1
						.toString());
			}
		}

		@Override
		public void windowClosing(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowDeactivated(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowDeiconified(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowIconified(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowOpened(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

	}

//	class workflowQueryListener implements WindowListener {
//
//		@Override
//		public void windowActivated(WindowEvent arg0) {
//			// TODO Auto-generated method stub
//
//		}
//
//		@Override
//		public void windowClosed(WindowEvent arg0) {
//			// TODO Auto-generated method stub
//			// System.out.println("Entered retrieval");
//			try {
//
//				String graph_response = null;
//				String graph = null;
//
//				// String setWorkflowID = qp.ID;
//				// boolean withAnnotation = qp.withAnnotation;
//
//				if (!rqp.doQuery)
//					return;
//
//				if (scp.useAxis2) {
//					KarmaAxis2Query axis2Tester = new KarmaAxis2Query(
//							ConfigurationReader.serviceURL);
//					if (rqp.withAnnotation)
//						graph_response = axis2Tester
//								.getWorkflowGraphWithAnnotation(rqp.workflowID);
//					else
//						graph_response = axis2Tester
//								.getWorkflowGraphWithoutAnnotation(rqp.workflowID);
//				} else if (scp.useRabbitmq) {
//					RabbitmqQuery rq = new RabbitmqQuery();
//					if (rqp.withAnnotation)
//						graph_response = rq
//								.getWorkflowGraphWithAnnotation(rqp.workflowID);
//					else
//						graph_response = rq
//								.getWorkflowGraphWithoutAnnotation(rqp.workflowID);
//				} else
//					return;
//
//				/*
//				 * Re-organize the result xml into a opm xml
//				 */
//				int start = graph_response.lastIndexOf("<v1:opmGraph");
//				int end = graph_response.lastIndexOf("<");
//
//				if (start == -1 || end == -1) {
//					graph = graph_response;
//
//					JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
//							"An invalid OPM graph returned");
//				} else
//					graph = graph_response.substring(start, end);
//
//				JFileChooser fileChooser = new JFileChooser();
//
//				ExtensionFileFilter filter = new ExtensionFileFilter();
//				filter.addExtension("xml");
//				filter.setDescription("xml files");
//				fileChooser.setFileFilter(filter);
//
//				// if set to null, will be displayed in the middle of window
//				int returnVal = fileChooser.showSaveDialog(Cytoscape
//						.getDesktop());
//				if (returnVal == JFileChooser.APPROVE_OPTION) {
//					String filePath = fileChooser.getSelectedFile()
//							.getAbsolutePath();
//					String save_file_name = filePath;
//
//					FileWriter fw;
//					if (save_file_name.contains(".xml"))
//						fw = new FileWriter(save_file_name);
//					else
//						fw = new FileWriter(save_file_name + ".xml");
//					BufferedWriter bw = new BufferedWriter(fw);
//					bw.write(graph);
//					bw.flush();
//					bw.close();
//					fw.close();
//				}
//
//			} catch (Exception e1) {
//				// TODO Auto-generated catch block
//				JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e1
//						.toString());
//			}
//		}
//
//		@Override
//		public void windowClosing(WindowEvent arg0) {
//			// TODO Auto-generated method stub
//
//		}
//
//		@Override
//		public void windowDeactivated(WindowEvent arg0) {
//			// TODO Auto-generated method stub
//
//		}
//
//		@Override
//		public void windowDeiconified(WindowEvent arg0) {
//			// TODO Auto-generated method stub
//
//		}
//
//		@Override
//		public void windowIconified(WindowEvent arg0) {
//			// TODO Auto-generated method stub
//
//		}
//
//		@Override
//		public void windowOpened(WindowEvent arg0) {
//			// TODO Auto-generated method stub
//
//		}
//
//	}
	
	public static void main(String args[]) {
		// QueryPanel qp = new QueryPanel(null);
		// qp.setDefaultCloseOperation(qp.DISPOSE_ON_CLOSE);
		// qp.setVisible(true);
		//
		// while (qp.waitingForInput)
		// ;
		//
		// System.out.println(qp.ID);
		// System.out.println(qp.withAnnotation);
		// System.out.println(qp.doRetrieval);
	}
}