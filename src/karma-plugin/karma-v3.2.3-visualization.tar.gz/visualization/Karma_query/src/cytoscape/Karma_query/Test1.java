package cytoscape.Karma_query;

public class Test1 {

}
