package cytoscape.GUI;

import javax.swing.JPanel;
import java.awt.Frame;
import java.awt.BorderLayout;
import javax.swing.JDialog;
import java.awt.GridLayout;
import javax.swing.JLabel;
import java.awt.GridBagLayout;
import java.awt.Dimension;

import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JCheckBox;
import javax.swing.JTextField;
import javax.swing.BorderFactory;
import javax.swing.border.TitledBorder;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.EtchedBorder;

import cytoscape.Cytoscape;
import cytoscape.Karma_query.ConfigurationReader;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Rectangle;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class ServerConfigPanel extends JDialog {
	public boolean createNewGraph = false;
	public static boolean useAxis2 = false;
	public static boolean useRabbitmq = false;

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JPanel jPanel = null;
	private JLabel jLabel1 = null;
	private JPanel jPanel1 = null;
	private JPanel jPanel3 = null;
	private JPanel jPanel4 = null;
	private JCheckBox jCheckBox = null;
	private JPanel jPanel5 = null;
	private JLabel jLabel = null;
	private JTextField jTextField = null;
	private JPanel jPanel6 = null;
	private JLabel Rabbitmq = null;
	private JLabel jLabel2 = null;
	private JTextField jTextField1 = null;
	private JLabel jLabel3 = null;
	private JPanel jPanel7 = null;
	private JLabel jLabel4 = null;
	private JButton jButton = null;
	private JLabel jLabel5 = null;
	private JButton jButton1 = null;
	private JLabel jLabel6 = null;
	private JCheckBox jCheckBox1 = null;
	private JPanel jPanel8 = null;
	private JPanel jPanel9 = null;
	private JPanel jPanel10 = null;
	private JLabel jLabel7 = null;
	private JLabel jLabel8 = null;
	private JTextField jTextField2 = null;
	private JTextField jTextField3 = null;
	private JPanel jPanel11 = null;
	private JPanel jPanel12 = null;
	private JLabel jLabel9 = null;
	private JTextField jTextField4 = null;
	private JLabel jLabel10 = null;
	private JTextField jTextField5 = null;
	private JPanel jPanel13 = null;
	private JLabel jLabel11 = null;
	private JTextField jTextField6 = null;
	private JPanel jPanel14 = null;
	private JPanel jPanel15 = null;
	private JLabel jLabel12 = null;
	private JTextField jTextField7 = null;
	private JLabel jLabel13 = null;
	private JLabel jLabel15 = null;
	private JTextField jTextField8 = null;
	private JTextField jTextField10 = null;

	/**
	 * @param owner
	 */
	public ServerConfigPanel(Frame owner) {
		super(owner);
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setBounds(new Rectangle(0, 0, 464, 389));
		this.setContentPane(getJContentPane());
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			GridBagConstraints gridBagConstraints31 = new GridBagConstraints();
			gridBagConstraints31.fill = GridBagConstraints.HORIZONTAL;
			gridBagConstraints31.gridx = 0;
			gridBagConstraints31.gridy = 3;
			gridBagConstraints31.gridheight = 2;
			// gridBagConstraints31.ipady = 220;
			// gridBagConstraints31.gridwidth = 2;
			GridBagConstraints gridBagConstraints3 = new GridBagConstraints();
			gridBagConstraints3.fill = GridBagConstraints.HORIZONTAL;
			gridBagConstraints3.gridy = 5;
			gridBagConstraints3.gridx = 0;
			GridBagConstraints gridBagConstraints2 = new GridBagConstraints();
			gridBagConstraints2.fill = GridBagConstraints.HORIZONTAL;
			gridBagConstraints2.gridx = 0;
			gridBagConstraints2.gridy = 2;
			// gridBagConstraints2.ipady = 40;
			GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
			gridBagConstraints1.fill = GridBagConstraints.HORIZONTAL;
			gridBagConstraints1.gridx = 0;
			gridBagConstraints1.gridy = 1;
			GridBagConstraints gridBagConstraints = new GridBagConstraints();
			gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
			gridBagConstraints.gridx = 0;
			gridBagConstraints.gridy = 0;
			jContentPane = new JPanel();
			jContentPane.setLayout(new GridBagLayout());
			jContentPane.add(getJPanel(), gridBagConstraints);
			jContentPane.add(getJPanel3(), gridBagConstraints1);
			jContentPane.add(getJPanel1(), gridBagConstraints2);
			jContentPane.add(getJPanel4(), gridBagConstraints3);
			jContentPane.add(getJPanel6(), gridBagConstraints31);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel() {
		if (jPanel == null) {
			jLabel1 = new JLabel();
			jLabel1.setText(">> Karma Server Configuration");
			GridLayout gridLayout1 = new GridLayout();
			gridLayout1.setRows(1);
			jPanel = new JPanel();
			jPanel.setLayout(gridLayout1);
			jPanel.add(jLabel1, null);
			
		}
		return jPanel;
	}

	/**
	 * This method initializes jPanel1
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel1() {
		if (jPanel1 == null) {
			jPanel1 = new JPanel();
			jPanel1.setLayout(new BorderLayout());
			// jPanel1.add(getJCheckBox(), BorderLayout.NORTH);
			jPanel1.add(getJPanel5(), BorderLayout.CENTER);
		}
		return jPanel1;
	}

	/**
	 * This method initializes jPanel3
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel3() {
		if (jPanel3 == null) {
			GridLayout gridLayout = new GridLayout();
			gridLayout.setColumns(2);
			gridLayout.setRows(1);
			jPanel3 = new JPanel();
			jPanel3.setLayout(gridLayout);
			jPanel3.add(getJCheckBox());
			jPanel3.add(getJCheckBox1());

			ButtonGroup group = new ButtonGroup();
			group.add(getJCheckBox1());
			group.add(getJCheckBox());

			getJCheckBox1().setEnabled(true);
			getJCheckBox().setEnabled(true);
			getJCheckBox().setSelected(true);

			getJTextField().setEnabled(true);
			getJTextField1().setEnabled(false);
			// jLabel.setForeground(Color.GRAY);
			// jLabel2.setForeground(Color.GRAY);

			ActionListener al = new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					if (ae.getSource() == getJCheckBox()) {
						jLabel.setForeground(Color.BLACK);
						getJTextField().setEnabled(true);

						jLabel2.setForeground(Color.GRAY);
						getJTextField1().setEnabled(false);
						jLabel7.setForeground(Color.GRAY);
						getJTextField2().setEnabled(false);
						jLabel8.setForeground(Color.GRAY);
						getJTextField3().setEnabled(false);
						jLabel9.setForeground(Color.GRAY);
						getJTextField4().setEnabled(false);
						jLabel10.setForeground(Color.GRAY);
						getJTextField5().setEnabled(false);
						jLabel11.setForeground(Color.GRAY);
						getJTextField6().setEnabled(false);
						jLabel12.setForeground(Color.GRAY);
						getJTextField7().setEnabled(false);
						jLabel13.setForeground(Color.GRAY);
						getJTextField8().setEnabled(false);

					} else if (ae.getSource() == getJCheckBox1()) {
						jLabel.setForeground(Color.GRAY);
						getJTextField().setEnabled(false);

						jLabel2.setForeground(Color.BLACK);
						getJTextField1().setEnabled(true);
						jLabel7.setForeground(Color.BLACK);
						getJTextField2().setEnabled(true);
						jLabel8.setForeground(Color.BLACK);
						getJTextField3().setEnabled(true);
						jLabel9.setForeground(Color.BLACK);
						getJTextField4().setEnabled(true);
						jLabel10.setForeground(Color.BLACK);
						getJTextField5().setEnabled(true);
						jLabel11.setForeground(Color.BLACK);
						getJTextField6().setEnabled(true);
						jLabel12.setForeground(Color.BLACK);
						getJTextField7().setEnabled(true);
						jLabel13.setForeground(Color.BLACK);
						getJTextField8().setEnabled(true);
					}
				}
			};

			getJCheckBox1().addActionListener(al);
			getJCheckBox().addActionListener(al);
		}
		return jPanel3;
	}

	/**
	 * This method initializes jPanel4
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel4() {
		if (jPanel4 == null) {
			jLabel3 = new JLabel();
			jLabel3
					.setText("Current Session(all network/attributes) will be lost.\nDo you want to continue? ");
			GridLayout gridLayout2 = new GridLayout();
			gridLayout2.setRows(2);
			jPanel4 = new JPanel();
			jPanel4.setLayout(gridLayout2);
			jPanel4.add(jLabel3, null);
			jPanel4.add(getJPanel7(), null);
		}
		return jPanel4;
	}

	/**
	 * This method initializes jCheckBox
	 * 
	 * @return javax.swing.JCheckBox
	 */
	private JCheckBox getJCheckBox() {
		if (jCheckBox == null) {
			jCheckBox = new JCheckBox();
			jCheckBox.setText("Axis2");
		}
		return jCheckBox;
	}

	/**
	 * This method initializes jPanel5
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel5() {
		if (jPanel5 == null) {
			jLabel = new JLabel();
			jLabel.setText("ServiceURL: ");
			jLabel.setForeground(Color.BLACK);
			jPanel5 = new JPanel();
			jPanel5.setLayout(new BorderLayout());
			jPanel5.setBorder(BorderFactory.createTitledBorder(null,
					"Axis2 Config", TitledBorder.DEFAULT_JUSTIFICATION,
					TitledBorder.DEFAULT_POSITION, new Font("Dialog",
							Font.BOLD, 12), new Color(51, 51, 51)));
			jPanel5.add(jLabel, BorderLayout.WEST);
			jPanel5.add(getJTextField(), BorderLayout.CENTER);
		}
		return jPanel5;
	}

	/**
	 * This method initializes jTextField
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getJTextField() {
		if (jTextField == null) {
			jTextField = new JTextField();
			jTextField.setText(ConfigurationReader.serviceURL);
		}
		return jTextField;
	}

	/**
	 * This method initializes jPanel6
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel6() {
		if (jPanel6 == null) {
			GridLayout gridLayout5 = new GridLayout();
			gridLayout5.setRows(8);
			jLabel2 = new JLabel();
			jLabel2.setText("username: ");
			jLabel2.setForeground(Color.GRAY);
			jPanel6 = new JPanel();
			jPanel6.setLayout(gridLayout5);
			jPanel6.setBorder(BorderFactory.createTitledBorder(null,
					"Rabbitmq config", TitledBorder.DEFAULT_JUSTIFICATION,
					TitledBorder.DEFAULT_POSITION, new Font("Dialog",
							Font.BOLD, 12), new Color(51, 51, 51)));
			jPanel6.add(getJPanel8(), null);
			jPanel6.add(getJPanel9(), null);
			jPanel6.add(getJPanel10(), null);
			jPanel6.add(getJPanel11(), null);
			jPanel6.add(getJPanel12(), null);
			jPanel6.add(getJPanel13(), null);
			jPanel6.add(getJPanel14(), null);
			jPanel6.add(getJPanel15(), null);

		}
		return jPanel6;
	}

	/**
	 * This method initializes jTextField1
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getJTextField1() {
		if (jTextField1 == null) {
			jTextField1 = new JTextField();
			jTextField1.setText(ConfigurationReader.username);
			jTextField1.setPreferredSize(new Dimension(200, 20));
		}
		return jTextField1;
	}

	/**
	 * This method initializes jPanel7
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel7() {
		if (jPanel7 == null) {
			jLabel6 = new JLabel();
			jLabel6.setText("");
			jLabel5 = new JLabel();
			jLabel5.setText("");
			jLabel4 = new JLabel();
			jLabel4.setText("");
			GridLayout gridLayout4 = new GridLayout();
			gridLayout4.setRows(1);
			gridLayout4.setColumns(5);
			jPanel7 = new JPanel();
			jPanel7.setLayout(gridLayout4);
			jPanel7.add(jLabel4, null);
			jPanel7.add(getJButton(), null);
			jPanel7.add(jLabel6, null);
			jPanel7.add(getJButton1(), null);
			jPanel7.add(jLabel5, null);

			ActionListener al = new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					if (ae.getSource() == getJButton()) {
						System.out.println("You clicked the JButton");
						if (getJCheckBox().isSelected()) {
							ConfigurationReader.serviceURL = jTextField.getText();
							useAxis2 = true;
							useRabbitmq = false;

							ConfigurationReader.store();
						}
						if (getJCheckBox1().isSelected()) {
							ConfigurationReader.username = jTextField1.getText();
							ConfigurationReader.password = jTextField2.getText();
							ConfigurationReader.hostname = jTextField3.getText();
							ConfigurationReader.hostport = jTextField4.getText();
							ConfigurationReader.virtualhost = jTextField5.getText();
							ConfigurationReader.exchangename = jTextField6.getText();
							ConfigurationReader.queuename = jTextField7.getText();
							ConfigurationReader.routingkey = jTextField8.getText();
							useRabbitmq = true;
							useAxis2 = false;
							
							ConfigurationReader.store();
						}

						createNewGraph = true;
					} else if (ae.getSource() == getJButton1()) {
						System.out.println("You clicked the JButton1");
					}

					dispose();
				}

			};

			getJButton().addActionListener(al);
			getJButton1().addActionListener(al);
		}
		return jPanel7;
	}

	/**
	 * This method initializes jButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton("OK");
		}
		return jButton;
	}

	/**
	 * This method initializes jButton1
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButton1() {
		if (jButton1 == null) {
			jButton1 = new JButton("Cancel");
		}
		return jButton1;
	}

	/**
	 * This method initializes jCheckBox1
	 * 
	 * @return javax.swing.JCheckBox
	 */
	private JCheckBox getJCheckBox1() {
		if (jCheckBox1 == null) {
			jCheckBox1 = new JCheckBox("Rabbitmq");
		}
		return jCheckBox1;
	}

	/**
	 * This method initializes jPanel8
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel8() {
		if (jPanel8 == null) {
			jPanel8 = new JPanel();
			jPanel8.setLayout(new BorderLayout());
			jPanel8.add(jLabel2, BorderLayout.WEST);
			jPanel8.add(getJTextField1(), BorderLayout.CENTER);
		}
		return jPanel8;
	}

	/**
	 * This method initializes jPanel9
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel9() {
		if (jPanel9 == null) {
			jLabel7 = new JLabel();
			jLabel7.setText("password: ");
			jLabel7.setForeground(Color.GRAY);
			jPanel9 = new JPanel();
			jPanel9.setLayout(new BorderLayout());
			jPanel9.add(jLabel7, BorderLayout.WEST);
			jPanel9.add(getJTextField2(), BorderLayout.CENTER);
			getJTextField2().setEnabled(false);
		}
		return jPanel9;
	}

	/**
	 * This method initializes jPanel10
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel10() {
		if (jPanel10 == null) {
			jLabel8 = new JLabel();
			jLabel8.setText("hostname: ");
			jLabel8.setForeground(Color.GRAY);
			jPanel10 = new JPanel();
			jPanel10.setLayout(new BorderLayout());
			jPanel10.add(jLabel8, BorderLayout.WEST);
			jPanel10.add(getJTextField3(), BorderLayout.CENTER);
			getJTextField3().setEnabled(false);
		}
		return jPanel10;
	}

	/**
	 * This method initializes jTextField2
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getJTextField2() {
		if (jTextField2 == null) {
			jTextField2 = new JTextField("");
			jTextField2.setText(ConfigurationReader.password);
		}
		return jTextField2;
	}

	/**
	 * This method initializes jTextField3
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getJTextField3() {
		if (jTextField3 == null) {
			jTextField3 = new JTextField();
			jTextField3.setText(ConfigurationReader.hostname);
		}
		return jTextField3;
	}

	/**
	 * This method initializes jPanel11
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel11() {
		if (jPanel11 == null) {
			jLabel9 = new JLabel();
			jLabel9.setText("hostport: ");
			jLabel9.setForeground(Color.GRAY);
			jPanel11 = new JPanel();
			jPanel11.setLayout(new BorderLayout());
			jPanel11.add(jLabel9, BorderLayout.WEST);
			jPanel11.add(getJTextField4(), BorderLayout.CENTER);
			getJTextField4().setEnabled(false);
		}
		return jPanel11;
	}

	/**
	 * This method initializes jPanel12
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel12() {
		if (jPanel12 == null) {
			jLabel10 = new JLabel();
			jLabel10.setText("virtualhost: ");
			jLabel10.setForeground(Color.GRAY);
			jPanel12 = new JPanel();
			jPanel12.setLayout(new BorderLayout());
			jPanel12.add(jLabel10, BorderLayout.WEST);
			jPanel12.add(getJTextField5(), BorderLayout.CENTER);
			getJTextField5().setEnabled(false);
		}
		return jPanel12;
	}

	/**
	 * This method initializes jTextField4
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getJTextField4() {
		if (jTextField4 == null) {
			jTextField4 = new JTextField();
			jTextField4.setText(ConfigurationReader.hostport);
		}
		return jTextField4;
	}

	/**
	 * This method initializes jTextField5
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getJTextField5() {
		if (jTextField5 == null) {
			jTextField5 = new JTextField();
			jTextField5.setText(ConfigurationReader.virtualhost);
		}
		return jTextField5;
	}

	/**
	 * This method initializes jPanel13
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel13() {
		if (jPanel13 == null) {
			jLabel11 = new JLabel();
			jLabel11.setText("exchangename: ");
			jLabel11.setForeground(Color.GRAY);
			jPanel13 = new JPanel();
			jPanel13.setLayout(new BorderLayout());
			jPanel13.add(jLabel11, BorderLayout.WEST);
			jPanel13.add(getJTextField6(), BorderLayout.CENTER);
			getJTextField6().setEnabled(false);
		}
		return jPanel13;
	}

	/**
	 * This method initializes jTextField6
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getJTextField6() {
		if (jTextField6 == null) {
			jTextField6 = new JTextField();
			jTextField6.setText(ConfigurationReader.exchangename);
		}
		return jTextField6;
	}

	/**
	 * This method initializes jPanel14
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel14() {
		if (jPanel14 == null) {
			jLabel12 = new JLabel();
			jLabel12.setText("queuename: ");
			jLabel12.setForeground(Color.GRAY);
			jPanel14 = new JPanel();
			jPanel14.setLayout(new BorderLayout());
			jPanel14.add(jLabel12, BorderLayout.WEST);
			jPanel14.add(getJTextField7(), BorderLayout.CENTER);
			getJTextField7().setEnabled(false);
		}
		return jPanel14;
	}

	/**
	 * This method initializes jPanel15
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel15() {
		if (jPanel15 == null) {
			jLabel13 = new JLabel();
			jLabel13.setText("routingkey: ");
			jLabel13.setForeground(Color.GRAY);
			jPanel15 = new JPanel();
			jPanel15.setLayout(new BorderLayout());
			jPanel15.add(jLabel13, BorderLayout.WEST);
			jPanel15.add(getJTextField8(), BorderLayout.CENTER);
			getJTextField8().setEnabled(false);
		}
		return jPanel15;
	}

	/**
	 * This method initializes jTextField7
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getJTextField7() {
		if (jTextField7 == null) {
			jTextField7 = new JTextField();
			jTextField7.setText(ConfigurationReader.queuename);
		}
		return jTextField7;
	}

	/**
	 * This method initializes jTextField8
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getJTextField8() {
		if (jTextField8 == null) {
			jTextField8 = new JTextField();
			jTextField8.setText(ConfigurationReader.routingkey);
		}
		return jTextField8;
	}

	/**
	 * This method initializes jTextField10
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getJTextField10() {
		if (jTextField10 == null) {
			jTextField10 = new JTextField();
		}
		return jTextField10;
	}

	public static void main(String[] args) {
		
		ServerConfigPanel gp = new ServerConfigPanel(null);
		gp.setVisible(true);
	}

} // @jve:decl-index=0:visual-constraint="67,17"
