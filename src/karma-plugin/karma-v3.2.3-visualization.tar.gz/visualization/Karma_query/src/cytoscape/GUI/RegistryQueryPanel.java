package cytoscape.GUI;

import javax.swing.JPanel;
import java.awt.Frame;
import java.awt.BorderLayout;
import javax.swing.JDialog;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Dimension;
import javax.swing.JTree;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import cytoscape.GUI.OutlineNode.NodeType;
import cytoscape.Karma_query.ConfigurationReader;
import cytoscape.Karma_query.KarmaAxis2Query;
import cytoscape.Karma_query.RabbitmqQuery;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.List;

public class RegistryQueryPanel extends JDialog implements
		TreeSelectionListener {
	public boolean withAnnotation = false;
	public boolean doQuery = false;
	public String workflowID = null;
	private KarmaAxis2Query axis2Client;
	private RabbitmqQuery rqClient;

	private SAXBuilder builder;

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JScrollPane jScrollPane = null;
	private JTextArea jTextArea = null;
	private JButton jButton = null;
	private JButton jButton1 = null;
	private JTree jTree = null;

	/**
	 * @param owner
	 */
	public RegistryQueryPanel(Frame owner) {
		super(owner);
		initialize();

		this.builder = new SAXBuilder();
		try {
			if (ServerConfigPanel.useAxis2) {
				this.axis2Client = new KarmaAxis2Query(
						ConfigurationReader.serviceURL);
			} else if (ServerConfigPanel.useRabbitmq) {
				this.rqClient = new RabbitmqQuery();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setTitle("Registry");
		this.setSize(626, 372);
		this.setContentPane(getJContentPane());
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			GridBagConstraints gridBagConstraints5 = new GridBagConstraints();
			gridBagConstraints5.gridx = 2;
			gridBagConstraints5.gridy = 1;
			gridBagConstraints5.weightx = 0.15;
			gridBagConstraints5.weighty = 0.1;
			GridBagConstraints gridBagConstraints4 = new GridBagConstraints();
			gridBagConstraints4.gridx = 1;
			gridBagConstraints4.gridy = 1;
			gridBagConstraints4.weightx = 0.15;
			gridBagConstraints4.weighty = 0.1;
			GridBagConstraints gridBagConstraints3 = new GridBagConstraints();
			gridBagConstraints3.fill = GridBagConstraints.BOTH;
			gridBagConstraints3.gridy = 0;
			gridBagConstraints3.weightx = 0.3;
			gridBagConstraints3.weighty = 0.8;
			gridBagConstraints3.gridx = 1;
			gridBagConstraints3.anchor = GridBagConstraints.NORTH;
			gridBagConstraints3.gridwidth = 2;
			GridBagConstraints gridBagConstraints = new GridBagConstraints();
			gridBagConstraints.fill = GridBagConstraints.BOTH;
			gridBagConstraints.gridy = 0;
			gridBagConstraints.weightx = 0.7;
			gridBagConstraints.weighty = 1.0;
			gridBagConstraints.gridheight = 2;
			gridBagConstraints.ipadx = 220;
			// gridBagConstraints.gridwidth = 1;
			gridBagConstraints.gridx = 0;
			jContentPane = new JPanel();
			jContentPane.setLayout(new GridBagLayout());
			jContentPane.add(getJScrollPane(), gridBagConstraints);
			jContentPane.add(getJTextArea(), gridBagConstraints3);
			jContentPane.add(getJButton(), gridBagConstraints4);
			jContentPane.add(getJButton1(), gridBagConstraints5);

			ActionListener al = new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					if (ae.getSource() == getJButton()) {
						withAnnotation = true;
						doQuery = true;
					} else if (ae.getSource() == getJButton1()) {
						withAnnotation = false;
						doQuery = true;
					}

					dispose();
				}

			};

			getJButton().addActionListener(al);
			getJButton1().addActionListener(al);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jScrollPane
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			try {
				jTree = new JTree(new OutlineNode(NodeType.NULL, false,
						"Graph", "null"));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			jTree.addTreeSelectionListener(this);
			jScrollPane.setViewportView(jTree);
		}
		return jScrollPane;
	}

	/**
	 * This method initializes jTextArea
	 * 
	 * @return javax.swing.JTextArea
	 */
	private JTextArea getJTextArea() {
		if (jTextArea == null) {
			jTextArea = new JTextArea();
			jTextArea.setLineWrap(true);
			jTextArea.setWrapStyleWord(true);
			jTextArea.setEditable(false);
		}
		return jTextArea;
	}

	/**
	 * This method initializes jButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setText("withAnnotation");
			jButton.setSize(new Dimension(140, 26));
			jButton.setFont(new Font("Dialog", Font.BOLD, 12));
		}
		return jButton;
	}

	/**
	 * This method initializes jButton1
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButton1() {
		if (jButton1 == null) {
			jButton1 = new JButton();
			jButton1.setText("withoutAnnotation");
			jButton1.setFont(new Font("Dialog", Font.BOLD, 12));
			jButton.setSize(new Dimension(140, 26));
		}
		return jButton1;
	}

	public static void main(String[] args) {
		RegistryQueryPanel gp = new RegistryQueryPanel(null);
		gp.setVisible(true);
	}

	@Override
	public void valueChanged(TreeSelectionEvent arg0) {
		// TODO Auto-generated method stub
		StringBuffer sb = new StringBuffer();
		OutlineNode node = (OutlineNode) jTree.getLastSelectedPathComponent();

		if (node.getType() == NodeType.AbstractService) {
			String[] serviceID = new String[1];
			serviceID[0] = node.getId();
			String xmlValue = null;

			if (ServerConfigPanel.useAxis2) {
				xmlValue = axis2Client.getAbstractServiceDetailByID(serviceID);
			} else if (ServerConfigPanel.useRabbitmq) {
				xmlValue = rqClient.getAbstractServiceDetailByID(serviceID);
			}

			Reader reader = new StringReader(xmlValue);
			Document doc;
			try {
				doc = builder.build(reader);
				Element root = doc.getRootElement();

				Element child = root.getChild("abstractServiceDetailListType",
						root.getNamespace());
				Element sec_child = child.getChild("abstractServiceDetail",
						root.getNamespace());
				if (sec_child != null) {
					List<Element> third_child = sec_child.getChildren();

					for (Element element : third_child) {
						if (element.getName().equalsIgnoreCase("creationTime"))
							continue;

						sb.append(element.getName() + ":\t"
								+ element.getValue() + "\n");
					}
				}
			} catch (JDOMException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		if (node.getType() == NodeType.Service) {
			String[] serviceURI = new String[1];
			serviceURI[0] = node.toString();
			String xmlValue = null;

			if (ServerConfigPanel.useAxis2) {
				xmlValue = axis2Client.getServiceDetailByURI(serviceURI);
			} else if (ServerConfigPanel.useRabbitmq) {
				xmlValue = rqClient.getServiceDetailByURI(serviceURI);
			}

			Reader reader = new StringReader(xmlValue);
			Document doc;
			try {
				doc = builder.build(reader);
				Element root = doc.getRootElement();

				Element child = root.getChild("serviceDetailList", root
						.getNamespace());
				Element sec_child = child.getChild("serviceDetail", root
						.getNamespace());

				// when click, update the query workflowID to be the id of this
				// node
				this.workflowID = sec_child.getAttributeValue("id");

				if (sec_child != null) {
					List<Element> third_child = sec_child.getChildren();

					for (Element element : third_child) {
						if (element.getName().equalsIgnoreCase("instanceof"))
							continue;

						sb.append(element.getName() + ":\t"
								+ element.getValue() + "\n");

						// if(element.getName().equalsIgnoreCase("workflowID"))
						// this.workflowID = element.getValue();
					}
				}
			} catch (JDOMException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		jTextArea.setText(sb.toString());
	}
} // @jve:decl-index=0:visual-constraint="10,10"
