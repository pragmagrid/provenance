package cytoscape.GUI;

import java.awt.*;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.*;
import javax.swing.tree.*;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import cytoscape.Karma_query.ConfigurationReader;
import cytoscape.Karma_query.KarmaAxis2Query;
import cytoscape.Karma_query.RabbitmqQuery;

/**
 * Simple TreeNode that builds children on the fly. The key idea is that
 * getChildCount is always called before any actual children are requested. So
 * getChildCount builds the children if they don't already exist.
 */

public class OutlineNode extends DefaultMutableTreeNode {
	private boolean areChildrenDefined = false;
	private boolean isLeaf;
	private NodeType nodeType; // indicates what's the type of this node
	private String nodeContent;
	private String nodeId;
	private SAXBuilder builder;

	private KarmaAxis2Query axis2Client;
	private RabbitmqQuery rqClient;
	
	public enum NodeType {
		NULL, Type, AbstractService, Service
	};

	public OutlineNode(NodeType nodeType, boolean isLeaf, String nodeContent,
			String nodeId) throws Exception {
		this.nodeType = nodeType;
		this.isLeaf = isLeaf;
		this.nodeContent = nodeContent;
		this.nodeId = nodeId;
		this.builder = new SAXBuilder();
		
		if (ServerConfigPanel.useAxis2) {
			this.axis2Client = new KarmaAxis2Query(
					ConfigurationReader.serviceURL);
		} else if (ServerConfigPanel.useRabbitmq) {
			this.rqClient = new RabbitmqQuery();
		}
	}

	public boolean isLeaf() {
		return (isLeaf);
	}

	public int getChildCount() {
		if (!areChildrenDefined) {
			try {
				defineChildNodes();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return (super.getChildCount());
	}

	private void defineChildNodes() throws Exception {
		// You must set the flag before defining children if you
		// use "add" for the new children. Otherwise you get an infinite
		// recursive loop, since add results in a call to getChildCount.
		// However, you could use "insert" in such a case.
		areChildrenDefined = true;
		// for(int i=0; i<numChildren; i++)
		// add(new OutlineNode(i+1, numChildren));

		if (nodeType == NodeType.NULL) {
			String xmlValue = null;
			
			if (ServerConfigPanel.useAxis2) {
				xmlValue = axis2Client.findAllAbstractService();
			} else if (ServerConfigPanel.useRabbitmq) {
				xmlValue = rqClient.findAllAbstractService();
			}
			
			Reader reader = new StringReader(xmlValue);
			Document doc = builder.build(reader);
			Element root = doc.getRootElement();

			Element child = root.getChild("serviceNameList", root
					.getNamespace());
			List<Element> sec_child = child.getChildren("serviceID", root
					.getNamespace());

			Element child_1 = root
					.getChild("uniqueIDList", root.getNamespace());
			List<Element> sec_child_1 = child_1.getChildren("uniqueID", root
					.getNamespace());

			for (int i = 0; i < sec_child.size(); i++) {
				add(new OutlineNode(NodeType.AbstractService, false, sec_child
						.get(i).getValue(), sec_child_1.get(i).getValue()));
			}
			// add(new OutlineNode(NodeType.Type, false,"Gush"));
			// add(new OutlineNode(NodeType.Type, false,"Twister"));
			// add(new OutlineNode(NodeType.Type, false,"NASA"));
		} else if (nodeType == NodeType.Type) {
			// add(new OutlineNode(NodeType.Workflow, false, this.toString()
			// + "-workflow-1"));
			// add(new OutlineNode(NodeType.Workflow, false, this.toString()
			// + "-workflow-2"));
			// add(new OutlineNode(NodeType.Workflow, false, this.toString()
			// + "-workflow-3"));
		} else if (nodeType == NodeType.AbstractService) {
			String xmlValue = null;
			
			if (ServerConfigPanel.useAxis2) {
				xmlValue = axis2Client.findServiceByName(this.nodeContent);
			} else if (ServerConfigPanel.useRabbitmq) {
				xmlValue = rqClient.findServiceByName(this.nodeContent);
			}
			
			Reader reader = new StringReader(xmlValue);
			Document doc = builder.build(reader);
			Element root = doc.getRootElement();

			Element child = root.getChild("serviceIDList", root.getNamespace());
			List<Element> sec_child = child.getChildren("serviceID", root
					.getNamespace());

			/*
			 * only accept node with subtype "WORKFLOW"
			 */
			String[] serviceURI = new String[sec_child.size()];

			for (int i = 0; i < serviceURI.length; i++) {
				serviceURI[i] = sec_child.get(i).getValue();
			}

			String detailXML = null;
			
			if (ServerConfigPanel.useAxis2) {
				detailXML = axis2Client.getServiceDetailByURI(serviceURI);
			} else if (ServerConfigPanel.useRabbitmq) {
				detailXML = rqClient.getServiceDetailByURI(serviceURI);
			}
			
			// System.out.println(detailXML);
			Reader detailReader = new StringReader(detailXML);
			Document detailDoc;
			try {
				detailDoc = builder.build(detailReader);
				Element detailRoot = detailDoc.getRootElement();

				Element detailChild = detailRoot.getChild("serviceDetailList",
						detailRoot.getNamespace());
				List<Element> detailSec_children = detailChild.getChildren(
						"serviceDetail", detailRoot.getNamespace());

				for (Element detailSec_child : detailSec_children) {
					if (detailSec_child != null) {
						Element element = detailSec_child.getChild(
								"type", detailRoot.getNamespace());

						if (element.getName().equalsIgnoreCase("type")
								&& element.getValue().equalsIgnoreCase(
										"workflow")) {
							add(new OutlineNode(NodeType.Service, true,
									detailSec_child.getAttributeValue("id"), null));
						}

					}
				}

			} catch (JDOMException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// add(new OutlineNode(NodeType.WorkflowIns, true, this.toString()
			// + "-20110601"));
			// add(new OutlineNode(NodeType.WorkflowIns, true, this.toString()
			// + "-20110602"));
			// add(new OutlineNode(NodeType.WorkflowIns, true, this.toString()
			// + "-20110603"));
		}
	}

	public NodeType getType() {
		return nodeType;
	}

	public String getId() {
		return nodeId;
	}

	public String toString() {
		return nodeContent;
	}
}
