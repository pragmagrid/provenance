package cytoscape.OPM_visualization.eventListener;

import giny.model.Edge;
import giny.model.Node;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.InputEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Iterator;
import java.util.Set;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import cytoscape.CyNetwork;
import cytoscape.CyNode;
import cytoscape.Cytoscape;
import cytoscape.OPM_visualization.OPM_visualization;
import cytoscape.data.CyAttributes;
import cytoscape.util.undo.RedoAction;
import cytoscape.util.undo.UndoAction;
import cytoscape.view.CyNetworkView;
import cytoscape.view.NetworkViewManager;

/*
 * An action listener for history graph, when double click on the node, a series of undo/redo actions may happen accordingly
 */

public class HistoryGraphNodeListener extends MouseAdapter {
	public void mousePressed(MouseEvent mouseEvent) {
		System.out.println(mouseEvent.toString());
		
		int modifiers = mouseEvent.getModifiers();
		if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK
				&& mouseEvent.getClickCount() == 2) {
			CyNetwork cyNetwork = Cytoscape.getCurrentNetwork();
			// CyNetworkView view = Cytoscape.getCurrentNetworkView();
			Set<CyNode> nodes_set = cyNetwork.getSelectedNodes();

			// make sure if some node has been clicked
			if (nodes_set.isEmpty())
				return;

			Iterator<CyNode> itr_n = nodes_set.iterator();
			CyNode node = itr_n.next();

			CyAttributes cyNodeAttributes = Cytoscape.getNodeAttributes();
			// NodeView nv = view.getNodeView(node);

			// To see if this is the abstract node
			String node_id = node.getIdentifier();

			String dest_time = cyNodeAttributes.getStringAttribute(node_id,
					"Time");
			String cur_time = cyNodeAttributes.getStringAttribute(
					OPM_visualization.currentNavState.getIdentifier(), "Time");

			if (dest_time.compareTo(cur_time) > 0) {
				System.out
						.println("selected state is later than current state");

				int[] source_edges = cyNetwork.getRootGraph()
						.getAdjacentEdgeIndicesArray(
								OPM_visualization.currentNavState
										.getRootGraphIndex(), false, false,
								true);
				for (int i = 0; i < source_edges.length; i++) {
					Edge edge = cyNetwork.getRootGraph().getEdge(
							source_edges[i]);

					CyNode nav_node = (CyNode) edge.getTarget();

					// set the current state to be the state selected now
					OPM_visualization.currentNavState = nav_node;
					new RedoAction().actionPerformed(null);

					if (nav_node.getRootGraphIndex() == node
							.getRootGraphIndex()) {
						return;
					}
				}

			} else if (dest_time.compareTo(cur_time) < 0) {
				System.out
						.println("selected state is ealier than current state");

				while (true) {
					int[] source_edges = cyNetwork.getRootGraph()
							.getAdjacentEdgeIndicesArray(
									OPM_visualization.currentNavState
											.getRootGraphIndex(), false, false,
									true);
					for (int i = 0; i < source_edges.length; i++) {
						Edge edge = cyNetwork.getRootGraph().getEdge(
								source_edges[i]);

						CyNode nav_node = (CyNode) edge.getTarget();

						// OPM_visualization.undoActionList.get(
						// OPM_visualization.currentNavState.getIdentifier()).undo();
						// set the current state to be the state selected now
						OPM_visualization.currentNavState = nav_node;
						new UndoAction().actionPerformed(null);
						new UndoAction().actionPerformed(null);

						if (nav_node.getRootGraphIndex() == node
								.getRootGraphIndex()) {
							return;
						}
					}
				}
			} else {
				return;
			}

		}
		/*
		 * To decide the action based on the type of mouse Event
		 */
		// if ((modifiers & InputEvent.BUTTON1_MASK) ==
		// InputEvent.BUTTON1_MASK) {
		// JOptionPane.showMessageDialog(Cytoscape.getDesktop(),"Left button pressed.");
		// // System.out.println("Left button pressed.");
		// }
		// if ((modifiers & InputEvent.BUTTON2_MASK) ==
		// InputEvent.BUTTON2_MASK) {
		// JOptionPane.showMessageDialog(Cytoscape.getDesktop(),"Middle button pressed.");
		// // System.out.println("Middle button pressed.");
		// }
		// if ((modifiers & InputEvent.BUTTON3_MASK) ==
		// InputEvent.BUTTON3_MASK) {
		// JOptionPane.showMessageDialog(Cytoscape.getDesktop(),"Right button pressed.");
		// // System.out.println("Right button pressed.");
		// }
	}

}