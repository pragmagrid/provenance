package cytoscape.OPM_visualization.actionListener;

import giny.model.Edge;
import giny.model.Node;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.InputEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Iterator;
import java.util.Set;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import cytoscape.CyEdge;
import cytoscape.CyNetwork;
import cytoscape.CyNode;
import cytoscape.Cytoscape;
import cytoscape.data.CyAttributes;
import cytoscape.data.Semantics;
import cytoscape.view.CyNetworkView;
import cytoscape.view.NetworkViewManager;

/**
 * @author Peng
 */

/*
 * An action listener, when double click on the edge, it will show its subgraph
 * if it has
 */

public class EdgeExpendAction extends MouseAdapter {
	public void mousePressed(MouseEvent mouseEvent) {
		int modifiers = mouseEvent.getModifiers();
		if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK
				&& mouseEvent.getClickCount() == 2) {
			CyNetwork cyNetwork = Cytoscape.getCurrentNetwork();
			// CyNetworkView view = Cytoscape.getCurrentNetworkView();
			Set<CyEdge> edges_set = cyNetwork.getSelectedEdges();

			// make sure if some node has been clicked
			if (edges_set.isEmpty())
				return;

			// JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
			// "double click on edge");

			Iterator<CyEdge> itr_n = edges_set.iterator();
			CyEdge temp = itr_n.next();

			CyAttributes cyEdgeAttrs = Cytoscape.getEdgeAttributes();
			// String[] attr_name = cyEdgeAttributes.getAttributeNames();

			// NodeView nv = view.getNodeView(node);

			String edge_id = temp.getIdentifier();
			if (edge_id.contains("wasTriggeredBy")) {
				Node source = temp.getSource();
				Node target = temp.getTarget();

				int[] source_edges = cyNetwork.getRootGraph()
						.getAdjacentEdgeIndicesArray(
								source.getRootGraphIndex(), false, false, true);
				// System.out.println("source_edges number: "+source_edges.length);
				for (int i = 0; i < source_edges.length; i++) {
					Edge edge = cyNetwork.getRootGraph().getEdge(
							source_edges[i]);

					if (!cyEdgeAttrs.getStringAttribute(edge.getIdentifier(),
							"interaction").equalsIgnoreCase("used"))
						continue;

					Node node = edge.getTarget();
					int[] second_edges = cyNetwork.getRootGraph()
							.getAdjacentEdgeIndicesArray(
									node.getRootGraphIndex(), false, false,
									true);
					// System.out.println("second_edges number: "+second_edges.length);
					boolean isExpanded = false;
					for (int j = 0; j < second_edges.length; j++) {
						Edge second_edge = cyNetwork.getRootGraph().getEdge(
								second_edges[j]);

						if (!cyEdgeAttrs.getStringAttribute(
								second_edge.getIdentifier(), "interaction")
								.equalsIgnoreCase("wasGeneratedBy"))
							continue;

						Node second_node = second_edge.getTarget();

						if (second_node.getRootGraphIndex() == target
								.getRootGraphIndex()) {

							Node res1 = cyNetwork.restoreNode(node);
							Edge res2 = cyNetwork.restoreEdge(edge);
							Edge res3 = cyNetwork.restoreEdge(second_edge);

							if (res1 != null && res2 != null && res3 != null) {
								isExpanded = true;

								double x = (Cytoscape.getCurrentNetworkView()
										.getNodeView(source).getXPosition() + Cytoscape
										.getCurrentNetworkView().getNodeView(
												target).getXPosition()) / 2;
								double y = (Cytoscape.getCurrentNetworkView()
										.getNodeView(source).getYPosition() + Cytoscape
										.getCurrentNetworkView().getNodeView(
												target).getYPosition()) / 2;
								Cytoscape.getCurrentNetworkView().getNodeView(
										node).setXPosition(x);
								Cytoscape.getCurrentNetworkView().getNodeView(
										node).setYPosition(y);
							}
						}
					}

					if (isExpanded) {
						cyNetwork.removeEdge(temp.getRootGraphIndex(), true);
						Cytoscape.getCurrentNetworkView().redrawGraph(true,
								true);
						break;
					}
				}
			} else if (edge_id.contains("wasDerivedFrom")) {
				Node source = temp.getSource();
				Node target = temp.getTarget();

				int[] source_edges = cyNetwork.getRootGraph()
						.getAdjacentEdgeIndicesArray(
								source.getRootGraphIndex(), false, false, true);
				// System.out.println("source_edges number: "+source_edges.length);
				for (int i = 0; i < source_edges.length; i++) {
					Edge edge = cyNetwork.getRootGraph().getEdge(
							source_edges[i]);

					if (!cyEdgeAttrs.getStringAttribute(edge.getIdentifier(),
							"interaction").equalsIgnoreCase("wasGeneratedBy"))
						continue;

					Node node = edge.getTarget();
					int[] second_edges = cyNetwork.getRootGraph()
							.getAdjacentEdgeIndicesArray(
									node.getRootGraphIndex(), false, false,
									true);
					// System.out.println("second_edges number: "+second_edges.length);
					boolean isExpanded = false;
					for (int j = 0; j < second_edges.length; j++) {
						Edge second_edge = cyNetwork.getRootGraph().getEdge(
								second_edges[j]);

						if (!cyEdgeAttrs.getStringAttribute(
								second_edge.getIdentifier(), "interaction")
								.equalsIgnoreCase("used"))
							continue;

						Node second_node = second_edge.getTarget();

						if (second_node.getRootGraphIndex() == target
								.getRootGraphIndex()) {

							Node res1 = cyNetwork.restoreNode(node);
							Edge res2 = cyNetwork.restoreEdge(edge);
							Edge res3 = cyNetwork.restoreEdge(second_edge);

							if (res1 != null && res2 != null && res3 != null) {
								isExpanded = true;

								double x = (Cytoscape.getCurrentNetworkView()
										.getNodeView(source).getXPosition() + Cytoscape
										.getCurrentNetworkView().getNodeView(
												target).getXPosition()) / 2;
								double y = (Cytoscape.getCurrentNetworkView()
										.getNodeView(source).getYPosition() + Cytoscape
										.getCurrentNetworkView().getNodeView(
												target).getYPosition()) / 2;
								Cytoscape.getCurrentNetworkView().getNodeView(
										node).setXPosition(x);
								Cytoscape.getCurrentNetworkView().getNodeView(
										node).setYPosition(y);
							}

						}
					}

					if (isExpanded) {
						cyNetwork.removeEdge(temp.getRootGraphIndex(), true);
						Cytoscape.getCurrentNetworkView().redrawGraph(true,
								true);
						break;
					}
				}
			}

		}
		/*
		 * To decide the action based on the type of mouse Event
		 */
		// if ((modifiers & InputEvent.BUTTON1_MASK) ==
		// InputEvent.BUTTON1_MASK) {
		// JOptionPane.showMessageDialog(Cytoscape.getDesktop(),"Left button pressed.");
		// // System.out.println("Left button pressed.");
		// }
		// if ((modifiers & InputEvent.BUTTON2_MASK) ==
		// InputEvent.BUTTON2_MASK) {
		// JOptionPane.showMessageDialog(Cytoscape.getDesktop(),"Middle button pressed.");
		// // System.out.println("Middle button pressed.");
		// }
		// if ((modifiers & InputEvent.BUTTON3_MASK) ==
		// InputEvent.BUTTON3_MASK) {
		// JOptionPane.showMessageDialog(Cytoscape.getDesktop(),"Right button pressed.");
		// // System.out.println("Right button pressed.");
		// }
	}

}
