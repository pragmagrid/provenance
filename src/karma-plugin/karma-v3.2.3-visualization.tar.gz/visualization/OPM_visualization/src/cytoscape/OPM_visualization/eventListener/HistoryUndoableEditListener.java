package cytoscape.OPM_visualization.eventListener;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;

import csplugins.layout.algorithms.hierarchicalLayout.HierarchicalLayoutAlgorithm;
import cytoscape.CyEdge;
import cytoscape.CyNode;
import cytoscape.Cytoscape;
import cytoscape.OPM_visualization.OPM_visualization;
import cytoscape.data.CyAttributes;
import cytoscape.data.Semantics;
import cytoscape.util.undo.UndoAction;

public class HistoryUndoableEditListener implements UndoableEditListener {

	@Override
	public void undoableEditHappened(UndoableEditEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println("undoableEditHappened:" + arg0.toString());

		if (arg0.toString().contains("UndoableEditEvent")) {
			if (arg0.toString().contains("DeleteEdit")) {
				System.out.println("DeleteEdit added");
				OPM_visualization.undoActionList.put(
						OPM_visualization.currentNavState.getIdentifier(), arg0
								.getEdit());
			}

		}
		new UndoAction().actionPerformed(null);
	}

}
