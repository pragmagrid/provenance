package cytoscape.OPM_visualization.util;

import giny.model.Node;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.swing.JOptionPane;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.OPM_visualization.GraphConfigPanel;
import cytoscape.OPM_visualization.query.KarmaAxis2Query;
import cytoscape.OPM_visualization.query.RabbitmqQuery;
import cytoscape.data.CyAttributes;

public class DetailLoader implements Runnable {
	static String filename;
	static private ConfigurationReader conf_reader;

	private static KarmaAxis2Query axis2Client;
	private static RabbitmqQuery rqClient;

	// public static String serviceURL;
	// public static String username;
	// public static String password;
	// public static String hostname;
	// public static String hostport;
	// public static String virtualhost;
	// public static String exchangename;
	// public static String queuename;
	// public static String routingkey;

	// public static String pathToConfigFile =
	// "/plugins/config/karmaVisConfig.txt";

	static int method = -1;

	Collection<Node> nodes;

	public DetailLoader(Collection<Node> nodes) throws Exception {
		this.nodes = nodes;
		initialize();
	}

	public static void initialize() throws Exception {
		if (conf_reader == null)
			conf_reader = ConfigurationReader.getInstance();

		if (GraphConfigPanel.useAxis2) {
			if (axis2Client == null)
				axis2Client = new KarmaAxis2Query(conf_reader.serviceURL);
		} else if (GraphConfigPanel.useRabbitmq) {
			if (rqClient == null)
				rqClient = new RabbitmqQuery();
		}

		// String proFilePath = System.getProperty("user.dir") +
		// pathToConfigFile;
		// BufferedInputStream in;
		// try {
		// in = new BufferedInputStream(new FileInputStream(proFilePath));

		// serviceURL = conf_reader.getProperty("axis2.serviceURL");
		//
		// username = conf_reader.getProperty("messaging.username");
		// password = conf_reader.getProperty("messaging.password");
		// hostname = conf_reader.getProperty("messaging.hostname");
		// hostport = conf_reader.getProperty("messaging.hostport");
		// virtualhost = conf_reader.getProperty("messaging.virtualhost");
		// exchangename = conf_reader.getProperty("messaging.exchangename");
		// queuename = conf_reader.getProperty("messaging.queuename");
		// routingkey = conf_reader.getProperty("messaging.routingkey");

		// if (conf_reader.getProperty("method").contains("option1")
		// && conf_reader.getProperty("method").contains("option2")) {
		// method = -1;
		// } else if (conf_reader.getProperty("method").contains("option1"))
		// {
		// method = 0;
		// } else if (conf_reader.getProperty("method").contains("option2"))
		// {
		// method = 1;
		// } else {
		// JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
		// "Configuration error in karmaQueryConfig.txt:method");
		// }
		// } catch (FileNotFoundException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
	}

	public static void store() {
		// String proFilePath = System.getProperty("user.dir") +
		// pathToConfigFile;
		// BufferedOutputStream out;
		// BufferedInputStream in;
		// try {
		// out = new BufferedOutputStream(new FileOutputStream(proFilePath));
		// in = new BufferedInputStream(new FileInputStream(proFilePath));
		//
		// conf_reader = ConfigurationManager.getInstance(in);
		// conf_reader.setProperty("axis2.serviceURL", serviceURL);
		// conf_reader.setProperty("messaging.username", username);
		// conf_reader.setProperty("messaging.password", password);
		// conf_reader.setProperty("messaging.hostname", hostname);
		// conf_reader.setProperty("messaging.hostport", hostport);
		// conf_reader.setProperty("messaging.virtualhost", virtualhost);
		// conf_reader.setProperty("messaging.exchangename", exchangename);
		// conf_reader.setProperty("messaging.queuename", queuename);
		// conf_reader.setProperty("messaging.routingkey", routingkey);
		// conf_reader
		// .store(
		// out,
		// "Properties for using Karma Query Plugin\n@author: Peng Chen (chenpeng@indiana.edu)\naxis2.serviceURL: information to use Axis Service\nmessaging: information to use RabbitMQ messaging system");
		//
		// } catch (FileNotFoundException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		conf_reader.store();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		CyNetwork network = Cytoscape.getCurrentNetwork();
		CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();
		CyAttributes cyEdgeAttrs = Cytoscape.getEdgeAttributes();

		Iterator<Node> itr_nodes = nodes.iterator();

		SAXBuilder builder = new SAXBuilder();

		try {
			List<String> process_id = new ArrayList<String>();
			List<String> artifact_id = new ArrayList<String>();

			while (itr_nodes.hasNext()) {
				Node temp = itr_nodes.next();
				String detailLevel = cyNodeAttrs.getStringAttribute(temp
						.getIdentifier(), "detailLevel");
				if (detailLevel != null
						&& detailLevel.equalsIgnoreCase("coarse")) {
					cyNodeAttrs.setAttribute(temp.getIdentifier(),
							"detailLevel", "fine");
				} else
					continue;

				String nodeType = cyNodeAttrs.getStringAttribute(temp
						.getIdentifier(), "NodeType");

				if (nodeType.contains("PROCESS")) {
					process_id.add(temp.getIdentifier());
					System.out.println("add process: " + temp.getIdentifier());

					// String[] ID = new String[1];
					// ID[0] = temp.getIdentifier();

					// KarmaAxis2Query axis2Tester;
					//
					// axis2Tester = new KarmaAxis2Query(this.serviceURL);
					//
					// String graph_response = axis2Tester
					// .getServiceDetailByID(ID);
					// Reader reader = new StringReader(graph_response);
					//
					// Document doc = builder.build(reader);
					// Element root = doc.getRootElement();
					//
					// Element child = root.getChild("serviceDetailList", root
					// .getNamespace());
					// if (child == null)
					// continue;
					//
					// Element sec_child = child.getChild("serviceDetail", root
					// .getNamespace());
					//
					// for (int i = 0; i < GraphBuilder.process_keyword.length;
					// i++) {
					// Element tmp = sec_child.getChild(
					// GraphBuilder.process_keyword[i], root
					// .getNamespace());
					// if (tmp != null)
					// cyNodeAttrs.setAttribute(temp.getIdentifier(),
					// GraphBuilder.process_name[i], tmp
					// .getValue());
					// }

				} else if (nodeType.contains("ARTIFACT")) {
					artifact_id.add(temp.getIdentifier());
					System.out.println("add artifact: " + temp.getIdentifier());
					// String[] blockID = { temp.getIdentifier() };

					// KarmaAxis2Query axis2Tester;
					//
					// axis2Tester = new KarmaAxis2Query(this.serviceURL);
					//
					// String graph_response = axis2Tester
					// .getDataProductDetail(blockID);
					// System.out.println("#####################\n"
					// + graph_response);
					// Reader reader = new StringReader(graph_response);
					//
					// Document doc = builder.build(reader);
					// Element root = doc.getRootElement();
					// Element child = root.getChild("dataProductDetailList",
					// root
					// .getNamespace());
					// Element sec_child = child.getChild("dataProductDetail",
					// root.getNamespace());
					//
					// for (int i = 0; i < GraphBuilder.block_keyword.length;
					// i++) {
					// Element tmp = sec_child.getChild(
					// GraphBuilder.block_keyword[i], root
					// .getNamespace());
					// if (tmp != null)
					// cyNodeAttrs.setAttribute(temp.getIdentifier(),
					// GraphBuilder.block_name[i], tmp.getValue());
					// }
					//
					// Element blockContent = sec_child.getChild("blockContent",
					// root.getNamespace());
					//
					// System.out.println(sec_child.getAttributeValue("id")
					// .toString());
					//
					// // System.out.println(blockContent.getValue());
					//
					// if (blockContent == null)
					// continue;
					// Reader reader1 = new
					// StringReader(blockContent.getValue());
					//
					// Document doc1 = builder.build(reader1);
					// Element root1 = doc1.getRootElement();
					//
					// Element child1 = root1.getChild("block", root1
					// .getNamespace());
					// if (child1 == null)
					// continue;
					//
					// for (int i = 0; i < GraphBuilder.block_keyword.length;
					// i++) {
					// Element tmp = child1.getChild(
					// GraphBuilder.block_keyword[i], root1
					// .getNamespace());
					// if (tmp != null)
					// cyNodeAttrs.setAttribute(temp.getIdentifier(),
					// GraphBuilder.block_name[i], tmp.getValue());
					// }
					//
					// for (int i = 0; i < GraphBuilder.art_label.length; i++) {
					// String attr = cyNodeAttrs.getStringAttribute(temp
					// .getIdentifier(), GraphBuilder.art_label[i]);
					//
					// if (attr != null && !attr.isEmpty()) {
					// cyNodeAttrs.setAttribute(temp.getIdentifier(),
					// "node_label", attr);
					// break;
					// }
					// }

				}
			}
			if (process_id.size() > 0) {
				String[] id = new String[process_id.size()];
				List<String> instanceOf = new ArrayList<String>();

				String graph_response = null;
				if (GraphConfigPanel.useAxis2) {
					graph_response = axis2Client
							.getServiceDetailByID(process_id.toArray(id));
				} else if (GraphConfigPanel.useRabbitmq) {
					graph_response = rqClient.getServiceDetailByID(process_id
							.toArray(id));
				}

				Reader reader = new StringReader(graph_response);
				System.out.println(graph_response);

				Document doc = builder.build(reader);
				Element root = doc.getRootElement();

				Element child = root.getChild("serviceDetailList", root
						.getNamespace());

				if (child != null) {
					List<Element> sec_child = child.getChildren(
							"serviceDetail", root.getNamespace());

					for (Element element : sec_child) {
						// for (int i = 0; i <
						// GraphBuilder.process_keyword.length; i++) {
						// Element tmp = element.getChild(
						// GraphBuilder.process_keyword[i], root
						// .getNamespace());
						// if (tmp != null)
						// cyNodeAttrs.setAttribute(element
						// .getAttributeValue("id"),
						// GraphBuilder.process_name[i], tmp
						// .getValue());
						// }

						List<Element> ls = element.getChildren();
						for (Element tmp : ls) {
							if (!tmp.getName().equals("instanceOf"))
								cyNodeAttrs.setAttribute(element
										.getAttributeValue("id"),
										tmp.getName(), tmp.getValue());
						}

						if (element.getChild("instanceOf", root.getNamespace()) != null)
							instanceOf.add("Registry_process_"
									+ element.getChild("instanceOf",
											root.getNamespace()).getValue());
					}

				}

				if (instanceOf.size() > 0) {
					String[] instanceOf_ids = new String[instanceOf.size()];
					// String graph_response_1 = axis2Tester
					// .getAbstractServiceDetailByID(instanceOf
					// .toArray(instanceOf_ids));

					String graph_response_1 = null;
					if (GraphConfigPanel.useAxis2) {
						graph_response_1 = axis2Client
								.getAbstractServiceDetailByID(instanceOf
										.toArray(instanceOf_ids));
					} else if (GraphConfigPanel.useRabbitmq) {
						graph_response_1 = rqClient
								.getAbstractServiceDetailByID(instanceOf
										.toArray(instanceOf_ids));
					}

					Reader reader_1 = new StringReader(graph_response_1);
					System.out.println(graph_response_1);

					Document doc_1 = builder.build(reader_1);
					Element root_1 = doc_1.getRootElement();

					Element child_1 = root_1.getChild(
							"abstractServiceDetailListType", root_1
									.getNamespace());
					if (child_1 != null) {
						List<Element> sec_child_1 = child_1.getChildren(
								"abstractServiceDetail", root_1.getNamespace());

						for (int i = 0; i < sec_child_1.size(); i++) {
							List<Element> third_child_1 = sec_child_1.get(i)
									.getChildren();

							for (int j = 0; j < third_child_1.size(); j++) {
								cyNodeAttrs.setAttribute(id[i], "_reg_"
										+ third_child_1.get(j).getName(),
										third_child_1.get(j).getValue());
							}
						}

					}

				}
			}

			if (artifact_id.size() > 0) {
				String[] id = new String[artifact_id.size()];
				// KarmaAxis2Query axis2Tester = new KarmaAxis2Query(
				// conf_reader.serviceURL);
				// String graph_response = axis2Tester
				// .getDataProductDetail(artifact_id.toArray(id));

				String graph_response = null;
				if (GraphConfigPanel.useAxis2) {
					graph_response = axis2Client
							.getDataProductDetail(artifact_id.toArray(id));
				} else if (GraphConfigPanel.useRabbitmq) {
					graph_response = rqClient.getDataProductDetail(artifact_id
							.toArray(id));
				}

				Reader reader = new StringReader(graph_response);

				Document doc = builder.build(reader);
				Element root = doc.getRootElement();
				Element child = root.getChild("dataProductDetailList", root
						.getNamespace());

				if (child != null) {
					List<Element> sec_child = child.getChildren(
							"dataProductDetail", root.getNamespace());

					for (Element element : sec_child) {
						// for (int i = 0; i <
						// GraphBuilder.artifact_keyword.length; i++) {
						// Element tmp = element.getChild(
						// GraphBuilder.artifact_keyword[i], root
						// .getNamespace());
						// if (tmp != null)
						// cyNodeAttrs.setAttribute(element
						// .getAttributeValue("id"),
						// GraphBuilder.artifact_name[i], tmp
						// .getValue());
						// }

						List<Element> ls = element.getChildren();
						for (Element tmp : ls) {
							if (!tmp.getName().equals("blockContent"))
								cyNodeAttrs.setAttribute(element
										.getAttributeValue("id"),
										tmp.getName(), tmp.getValue());
						}

						Element blockContent = element.getChild("blockContent",
								root.getNamespace());

						System.out.println(element.getAttributeValue("id")
								.toString());

						// System.out.println(blockContent.getValue());

						if (blockContent == null)
							continue;
						Reader reader1 = new StringReader(blockContent
								.getValue());

						Document doc1 = builder.build(reader1);
						Element root1 = doc1.getRootElement();

						Element child1 = root1.getChild("block", root1
								.getNamespace());
						if (child1 == null)
							continue;

						// for (int i = 0; i <
						// GraphBuilder.artifact_keyword.length; i++) {
						// Element tmp = child1.getChild(
						// GraphBuilder.artifact_keyword[i], root1
						// .getNamespace());
						// if (tmp != null)
						// cyNodeAttrs.setAttribute(element
						// .getAttributeValue("id"),
						// GraphBuilder.artifact_name[i], tmp
						// .getValue());
						// }

						List<Element> ls1 = child1.getChildren();
						for (Element tmp1 : ls1) {
							cyNodeAttrs.setAttribute(element
									.getAttributeValue("id"), tmp1.getName(),
									tmp1.getValue());
						}

						for (int i = 0; i < GraphBuilder.art_label.length; i++) {
							String attr = cyNodeAttrs.getStringAttribute(
									element.getAttributeValue("id"),
									GraphBuilder.art_label[i]);

							if (attr != null && !attr.isEmpty()) {
								cyNodeAttrs.setAttribute(element
										.getAttributeValue("id"), "node_label",
										attr);
								break;
							}
						}
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e.toString());
		}
		Cytoscape.getCurrentNetworkView().redrawGraph(true, true);
	}
}