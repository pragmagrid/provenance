package cytoscape.OPM_visualization;

import java.awt.event.ActionEvent;
import cytoscape.Cytoscape;
import cytoscape.plugin.CytoscapePlugin;
import cytoscape.util.CytoscapeAction;
import cytoscape.util.undo.CyUndo;
import cytoscape.util.undo.RedoAction;
import cytoscape.util.undo.UndoAction;

import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import cytoscape.CyEdge;
import cytoscape.CyNetwork;
import cytoscape.CyNode;
import cytoscape.CytoscapeModifiedNetworkManager;
import cytoscape.OPM_visualization.actionListener.EdgeExpendAction;
import cytoscape.OPM_visualization.eventListener.AttributeModificationListener;
import cytoscape.OPM_visualization.eventListener.AutomaticalLoadingEventListener;
import cytoscape.OPM_visualization.eventListener.EdgeAttributeViewListener;
import cytoscape.OPM_visualization.eventListener.FilteredPaletteNetworkEditEventHandler;
import cytoscape.OPM_visualization.eventListener.HistoryGraphNodeListener;
import cytoscape.OPM_visualization.eventListener.MyNodeContextMenuListener;
import cytoscape.OPM_visualization.eventListener.NetworkModificationListener;
import cytoscape.OPM_visualization.eventListener.NetworkViewModificationListener;
import cytoscape.OPM_visualization.eventListener.NodeAttributeViewListener;
import cytoscape.OPM_visualization.layout.ClockwiseAttributeCircleLayout;
import cytoscape.OPM_visualization.layout.ForceDirectedProvenanceHistoryLayout;
import cytoscape.OPM_visualization.layout.MyLayout;
import cytoscape.OPM_visualization.layout.NSLayout;
import cytoscape.OPM_visualization.layout.NSLayoutExtD_Circle;
import cytoscape.OPM_visualization.layout.NSLayoutExtNode;
import cytoscape.OPM_visualization.layout.NSLayoutExtRD_Circle;
import cytoscape.OPM_visualization.layout.NSLayoutExtRD_Square;
import cytoscape.OPM_visualization.layout.NSLayoutExtR_Circle;
import cytoscape.OPM_visualization.layout.StringEmbededProvenanceHistoryLayout;
import cytoscape.OPM_visualization.util.DetailLoader;
import cytoscape.OPM_visualization.util.GraphBuilder;
import cytoscape.actions.NewSessionAction;
import cytoscape.data.Semantics;
import cytoscape.data.CyAttributes;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;

import cytoscape.view.CyNetworkView;
import cytoscape.view.NetworkViewManager;
import cytoscape.visual.ArrowShape;
import cytoscape.visual.CalculatorCatalog;
import cytoscape.visual.EdgeAppearanceCalculator;
import cytoscape.visual.GlobalAppearanceCalculator;
import cytoscape.visual.NodeAppearanceCalculator;
import cytoscape.visual.NodeShape;
import cytoscape.visual.VisualMappingManager;
import cytoscape.visual.VisualPropertyType;
import cytoscape.visual.VisualStyle;
import cytoscape.visual.calculators.BasicCalculator;
import cytoscape.visual.calculators.Calculator;
import cytoscape.visual.mappings.DiscreteMapping;
import cytoscape.visual.mappings.ObjectMapping;
import cytoscape.visual.mappings.PassThroughMapping;
import java.awt.Color;

import cytoscape.layout.CyLayoutAlgorithm;
import cytoscape.layout.CyLayouts;

import cytoscape.layout.Tunable;

import giny.model.Edge;
import giny.model.GraphPerspective;
import giny.model.Node;
import javax.swing.JPanel;

import java.awt.Container;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Rectangle;

import java.text.SimpleDateFormat;
import java.util.Iterator;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;

import giny.view.NodeView;
import ding.view.NodeContextMenuListener;
import edu.iu.pti.opmPlugin.PluginDocument;

import javax.swing.JPopupMenu;
import javax.swing.JMenuItem;

import org.apache.xmlbeans.XmlObject;
import org.freehep.swing.ExtensionFileFilter;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

import java.awt.event.ActionListener;

import cytoscape.data.SelectEventListener;
import cytoscape.data.SelectEvent;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

import csplugins.layout.algorithms.hierarchicalLayout.HierarchicalLayoutAlgorithm;
import csplugins.layout.algorithms.circularLayout.CircularLayoutAlgorithm;
import csplugins.layout.algorithms.GroupAttributesLayout;

import org.openprovenance.model.v1_1_a.*;
import org.openprovenance.model.v1_1_a.Process;
import org.openprovenance.model.v1_1_a.impl.*;
import org.xml.sax.InputSource;

import javax.swing.*;
import javax.swing.undo.UndoableEdit;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import java.awt.*;
import java.awt.event.*;

/**
 * @author Peng
 */

/*
 * A simple plugin to visualize OPM graph. Deploy this plugin (KarmaGraph.jar)
 * to the plugins directory. An image icon (geni logo) will show up on the
 * toolbar. Click on the icon will trigger a message box.
 */
public class OPM_visualization extends CytoscapePlugin {

	public static String filename;
	GraphConfigPanel gp = null;
	public static boolean useAutomaticLoading = false;

	protected ImageIcon icon_geni = new ImageIcon(getClass().getResource(
			"/geni_logo.jpg"));

	// This network is used to hold the provenance information of navigating the
	// graph
	public static CyNetwork historyNetwork = null;
	public static CyNode currentNavState = null;

	public static HashMap<String, UndoableEdit> undoActionList = new HashMap<String, UndoableEdit>();

	// static{
	// historyNetwork = Cytoscape.createNetwork("Navigate History Provenance",
	// true);
	// currentNavState = Cytoscape.getCyNode("Navigation Root", true);
	// historyNetwork.addNode(currentNavState);
	// }

	public OPM_visualization() {

		CyLayoutAlgorithm layout = new ClockwiseAttributeCircleLayout();
		// layout.setLayoutAttribute("timestep");
		MyLayout layout2 = new MyLayout();
		NSLayout nslayout = new NSLayout();
		NSLayoutExtNode nslayoutext1 = new NSLayoutExtNode();
		// NSLayoutExtRD_Square nslayoutext2 = new NSLayoutExtRD_Square();
		NSLayoutExtRD_Circle nslayoutext3 = new NSLayoutExtRD_Circle();
		NSLayoutExtR_Circle nslayoutext4 = new NSLayoutExtR_Circle();
		NSLayoutExtD_Circle nslayoutext5 = new NSLayoutExtD_Circle();
		StringEmbededProvenanceHistoryLayout provenancelayout1 = new StringEmbededProvenanceHistoryLayout();
		ForceDirectedProvenanceHistoryLayout provenancelayout2 = new ForceDirectedProvenanceHistoryLayout();

		CyLayouts.addLayout(layout, "GENI OPMLayout");
		CyLayouts.addLayout(layout2, "GENI OPMLayout");
		CyLayouts.addLayout(nslayout, "GENI OPMLayout");
		CyLayouts.addLayout(nslayoutext1, "GENI OPMLayout");
		// CyLayouts.addLayout(nslayoutext2, "GENI OPMLayout");
		CyLayouts.addLayout(nslayoutext3, "GENI OPMLayout");
		CyLayouts.addLayout(nslayoutext4, "GENI OPMLayout");
		CyLayouts.addLayout(nslayoutext5, "GENI OPMLayout");
		CyLayouts.addLayout(provenancelayout1, "GENI OPMLayout");
		CyLayouts.addLayout(provenancelayout2, "GENI OPMLayout");

		// (1) Create an toolbarAction
		MyPluginToolBarAction toolbarAction = new MyPluginToolBarAction(
				icon_geni, this);
		// (2) add the action to Cytoscape toolbar
		Cytoscape.getDesktop().getCyMenus().addCytoscapeAction(
				(CytoscapeAction) toolbarAction);

	}

	public static final String vsName = "OPM Visual Style";

	public class MyPluginToolBarAction extends CytoscapeAction implements
			WindowListener {

		/**
		 * 
		 */
		private static final long serialVersionUID = 7009055641207623850L;

		public MyPluginToolBarAction(ImageIcon icon, OPM_visualization myPlugin) {
			super("", icon);
			// Set SHORT_DESCRIPTION; used to create tool-tip
			this.putValue(Action.SHORT_DESCRIPTION,
					"OPM Visulization Plugin tool tip");
		}

		public void actionPerformed(ActionEvent e) {
			try {

				DetailLoader.initialize();

				gp = new GraphConfigPanel(null);
				gp.addWindowListener(this);
				gp.setDefaultCloseOperation(gp.DISPOSE_ON_CLOSE);
				double x = Cytoscape.getDesktop().getX()
						+ Cytoscape.getDesktop().getWidth() / 3;
				double y = Cytoscape.getDesktop().getY()
						+ Cytoscape.getDesktop().getHeight() / 5;
				gp.setLocation((int) x, (int) y);

				gp.pack();
				gp.setVisible(true);

			} catch (Exception e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e1
						.toString());
			}
		}

		/**
		 * DOCUMENT ME!
		 * 
		 * @return DOCUMENT ME!
		 */
		public boolean isInToolBar() {
			return true;
		}

		/**
		 * DOCUMENT ME!
		 * 
		 * @return DOCUMENT ME!
		 */
		public boolean isInMenuBar() {
			return true;
		}

		@Override
		public void windowActivated(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowClosed(WindowEvent arg0) {
			// TODO Auto-generated method stub
			if (!gp.createNewGraph) {
				return;
			}

			useAutomaticLoading = !gp.withAnnotation;
			// Cytoscape.createNewSession();

			String date = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy")
					.format(new Date());
			// historyNetwork = Cytoscape.createNetwork(
			// "Navigate History Provenance", true);
			// currentNavState = Cytoscape.getCyNode("Navigation Root@" + date,
			// true);
			// historyNetwork.addNode(currentNavState);

			CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();
			CyAttributes cyEdgeAttrs = Cytoscape.getEdgeAttributes();
			// cyNodeAttrs.setAttribute(currentNavState.getIdentifier(),
			// "node_label", currentNavState.getIdentifier());
			// cyNodeAttrs.setAttribute(currentNavState.getIdentifier(),
			// "NodeType", "ARTIFACT");
			// cyNodeAttrs.setAttribute(currentNavState.getIdentifier(), "Time",
			// date);

			// //////////////////////
			// SelectEventListener sls = new MyNodeSelectEventListener();
			// cyNetwork.addSelectEventListener(sls);

			JFileChooser fileChooser = new JFileChooser();

			ExtensionFileFilter filter = new ExtensionFileFilter();
			filter.addExtension("xml");
			filter.setDescription("xml files");
			fileChooser.setFileFilter(filter);

			// if set to null, will be displayed in the middle of window
			int returnVal = fileChooser.showOpenDialog(Cytoscape.getDesktop());
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				String filePath = fileChooser.getSelectedFile()
						.getAbsolutePath();
				// System.out.println("You chose to open this file: " +
				// filePath);

				filename = filePath;
			} else {
				return;
			}

			// create a network without a view; boolean indicate whether to
			// create the view at the same time
			CyNetwork cyNetwork = Cytoscape.createNetwork(
					"network:" + filename, true);

			try {

				File xmlFile = new File(filename);
				OpmGraphDocument doc = OpmGraphDocument.Factory.parse(xmlFile);

				{
					GraphBuilder gbuilder = new GraphBuilder();
					gbuilder.build(doc, cyNetwork, cyNodeAttrs, cyEdgeAttrs);
				}
			} catch (Exception ex) {
				JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
						"Exception!" + ex.getMessage());
				ex.printStackTrace();

			}

			// /////////////////////////////////
			// //////////////////////////////

			if (cyNetwork.getNodeCount() == 0) {
				JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
						"There is no node!");
				return;
			}

			// Inform others via property change event.
			Cytoscape.firePropertyChange(Cytoscape.ATTRIBUTES_CHANGED, null,
					null);

			// JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
			// "Graph created from file: " + filename);

			// ///////////////////////////
			// ///////////////////////////

			CyNetworkView networkView = Cytoscape.getCurrentNetworkView();
			// networkView.applyLayout(new HierarchicalLayoutAlgorithm());
			// networkView.applyLayout(new CircularLayoutAlgorithm());
			GroupAttributesLayout gal = new GroupAttributesLayout();
			gal.setLayoutAttribute("NodeType");
			networkView.applyLayout(gal);

			// CyLayoutAlgorithm layout = new AttributeCircleLayout();
			// layout.setLayoutAttribute("timestep");
			// networkView.applyLayout(layout);

			// get the VisualMappingManager and CalculatorCatalog
			VisualMappingManager manager = Cytoscape.getVisualMappingManager();
			CalculatorCatalog catalog = manager.getCalculatorCatalog();

			// check to see if a visual style with this name already exists
			VisualStyle vs = catalog.getVisualStyle(vsName);
			if (vs == null) {
				// if not, create it and add it to the catalog
				vs = createVisualStyle(cyNetwork);
				catalog.addVisualStyle(vs);
			}

			networkView.setVisualStyle(vs.getName()); // not strictly necessary
			// Cytoscape.getNetworkView(
			// OPM_visualization.historyNetwork.getIdentifier())
			// .setVisualStyle(vs.getName());

			// actually apply the visual style
			manager.setVisualStyle(vs);
			networkView.redrawGraph(true, true);
			// Cytoscape.getNetworkView(
			// OPM_visualization.historyNetwork.getIdentifier())
			// .redrawGraph(true, true);

			// ///////////////////////////////////
			// //////////////////////////////////
			if (Cytoscape.getCurrentNetworkView().getTitle() == null
					|| Cytoscape.getCurrentNetworkView().getTitle()
							.equalsIgnoreCase("null")) {
				JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
						"No network view!");
				return;
			}

			{
				registerListenerForCurrentView();
				// registerListenerForHistoryNetwork();
				// new UpdatePopupListenerOnNetworkPanel().update();
			}
		}

		@Override
		public void windowClosing(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowDeactivated(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowDeiconified(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowIconified(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void windowOpened(WindowEvent arg0) {
			// TODO Auto-generated method stub

		}
	}

	public static VisualStyle createVisualStyle(CyNetwork network) {

		NodeAppearanceCalculator nodeAppCalc = new NodeAppearanceCalculator();
		EdgeAppearanceCalculator edgeAppCalc = new EdgeAppearanceCalculator();
		GlobalAppearanceCalculator globalAppCalc = new GlobalAppearanceCalculator();

		globalAppCalc.setDefaultBackgroundColor(new Color(153, 153, 153));

		// Passthrough Mapping - set node label
		PassThroughMapping pm1 = new PassThroughMapping(new String(),
				"node_label");

		BasicCalculator nlc = new BasicCalculator(
				"Example Node Label Calculator", pm1,
				VisualPropertyType.NODE_LABEL);

		nodeAppCalc.setCalculator(nlc);

		// Discrete Mapping - set node shapes
		DiscreteMapping disMapping = new DiscreteMapping(NodeShape.RECT,
				ObjectMapping.NODE_MAPPING);
		disMapping.setControllingAttributeName("NodeType", network, false);
		disMapping.putMapValue("PROCESS", NodeShape.ROUND_RECT);
		disMapping.putMapValue("ARTIFACT", NodeShape.ELLIPSE);
		disMapping.putMapValue("SUBNETWORK", NodeShape.OCTAGON);
		disMapping.putMapValue("AGENT", NodeShape.OCTAGON);

		Calculator shapeCalculator = new BasicCalculator(
				"Example Node Shape Calculator", disMapping,
				VisualPropertyType.NODE_SHAPE);
		nodeAppCalc.setCalculator(shapeCalculator);

		// Discrete Mapping - Set node color
		final Color NODE_COLOR = new Color(10, 10, 10);

		DiscreteMapping nodeColor = new DiscreteMapping(NODE_COLOR, "NodeType",
				ObjectMapping.NODE_MAPPING);

		nodeColor.putMapValue("PROCESS", new Color(50, 255, 50));
		nodeColor.putMapValue("ARTIFACT", new Color(255, 50, 255));
		nodeColor.putMapValue("SUBNETWORK", new Color(255, 255, 255));
		nodeColor.putMapValue("AGENT", new Color(255, 50, 50));

		Calculator nodeColorCalc = new BasicCalculator("EdgeColorMapping",
				nodeColor, VisualPropertyType.NODE_FILL_COLOR);

		nodeAppCalc.setCalculator(nodeColorCalc);

		// set edge label
		PassThroughMapping pm_e = new PassThroughMapping(new String(),
				"interaction");

		BasicCalculator edc = new BasicCalculator(
				"Example Edge Label Calculator", pm_e,
				VisualPropertyType.EDGE_LABEL);

		edgeAppCalc.setCalculator(edc);

		// Discrete Mapping - Set edge color
		final Color EDGE_COLOR = new Color(10, 10, 10);

		DiscreteMapping edgeColor = new DiscreteMapping(EDGE_COLOR,
				"interaction", ObjectMapping.EDGE_MAPPING);

		edgeColor.putMapValue("used", new Color(100, 255, 100));
		edgeColor.putMapValue("wasTriggeredBy", Color.YELLOW);
		edgeColor.putMapValue("wasGeneratedBy", new Color(204, 204, 204));
		edgeColor.putMapValue("wasDerivedFrom", new Color(0, 200, 255));
		edgeColor.putMapValue("wasControlledBy", Color.WHITE);
		edgeColor.putMapValue("wasExecutedOn", Color.magenta);
		edgeColor.putMapValue("wasConnectedTo", Color.lightGray);

		Calculator edgeColorCalc = new BasicCalculator("EdgeColorMapping",
				edgeColor, VisualPropertyType.EDGE_COLOR);

		edgeAppCalc.setCalculator(edgeColorCalc);

		// Discrete Mapping - Set edge target arrow shape
		DiscreteMapping arrowMapping = new DiscreteMapping(ArrowShape.NONE,
				ObjectMapping.EDGE_MAPPING);
		arrowMapping.setControllingAttributeName("interaction", network, false);
		arrowMapping.putMapValue("wasTriggeredBy", ArrowShape.ARROW);
		arrowMapping.putMapValue("wasGeneratedBy", ArrowShape.CIRCLE);
		arrowMapping.putMapValue("wasDerivedFrom", ArrowShape.CIRCLE);
		arrowMapping.putMapValue("used", ArrowShape.DELTA);
		arrowMapping.putMapValue("wasControlledBy", ArrowShape.DIAMOND);
		arrowMapping.putMapValue("wasExecutedOn", ArrowShape.ARROW);
		arrowMapping.putMapValue("wasConnectedTo", ArrowShape.ARROW);

		Calculator edgeArrowCalculator = new BasicCalculator(
				"Example Edge Arrow Shape Calculator", arrowMapping,
				VisualPropertyType.EDGE_TGTARROW_SHAPE);
		edgeAppCalc.setCalculator(edgeArrowCalculator);

		// Create the visual style
		VisualStyle visualStyle = new VisualStyle(vsName, nodeAppCalc,
				edgeAppCalc, globalAppCalc);

		return visualStyle;
	}

	public static void createVisStyleForCurrentView() {
		CyNetwork cyNetwork = Cytoscape.getCurrentNetwork();
		CyNetworkView networkView = Cytoscape.getCurrentNetworkView();
		// get the VisualMappingManager and CalculatorCatalog
		VisualMappingManager manager = Cytoscape.getVisualMappingManager();
		CalculatorCatalog catalog = manager.getCalculatorCatalog();

		// check to see if a visual style with this name already exists
		VisualStyle vs = catalog.getVisualStyle(vsName);
		if (vs == null) {
			// if not, create it and add it to the catalog
			vs = OPM_visualization.createVisualStyle(cyNetwork);
			catalog.addVisualStyle(vs);
		}

		networkView.setVisualStyle(vs.getName()); // not strictly necessary
		// Cytoscape.getNetworkView(
		// OPM_visualization.historyNetwork.getIdentifier())
		// .setVisualStyle(vs.getName());

		// actually apply the visual style
		manager.setVisualStyle(vs);
		networkView.redrawGraph(true, true);
	}

	public static void registerListenerForCurrentView() {
		MyNodeContextMenuListener l = new MyNodeContextMenuListener();
		Cytoscape.getCurrentNetworkView().addNodeContextMenuListener(l);
		// Cytoscape.getNetworkView(
		// OPM_visualization.historyNetwork.getIdentifier())
		// .addNodeContextMenuListener(l);

		Cytoscape.getCurrentNetworkView().getComponent().addMouseListener(
				new NodeAttributeViewListener());
		Cytoscape.getCurrentNetworkView().getComponent().addMouseListener(
				new EdgeExpendAction());
		Cytoscape.getCurrentNetworkView().getComponent().addMouseListener(
				new EdgeAttributeViewListener());

		if (useAutomaticLoading)
			Cytoscape.getCurrentNetworkView().addGraphViewChangeListener(
					new AutomaticalLoadingEventListener());

		// Define MouseListener to show attributes
		// MouseListener mouseListener = new NodeAttributeViewListener();
		// MouseListener mouseListener1 = new EdgeExpendAction();
		// MouseListener mouseListener2 = new EdgeAttributeViewListener();

		// CytoscapeDesktop desktop = Cytoscape.getDesktop();
		// desktop.addMouseListener(mouseListener);

		// remove the build-in double click listener
		MouseListener[] ml = Cytoscape.getCurrentNetworkView().getComponent()
				.getMouseListeners();
		for (int i = 0; i < ml.length; i++) {
			// System.out.println(ml[i].toString());
			if (ml[i].toString().contains("PaletteNetworkEdit")) {
				Cytoscape.getCurrentNetworkView().getComponent()
						.removeMouseListener(ml[i]);

				Cytoscape.getCurrentNetworkView().getComponent()
						.addMouseListener(
								new FilteredPaletteNetworkEditEventHandler(
										ml[i]));
			}
		}

		// MouseListener[] ml1 = Cytoscape.getNetworkView(
		// OPM_visualization.historyNetwork.getIdentifier())
		// .getComponent().getMouseListeners();
		// for (int i = 0; i < ml1.length; i++) {
		// // System.out.println(ml[i].toString());
		// if (ml1[i].toString().contains("PaletteNetworkEdit"))
		// Cytoscape.getNetworkView(
		// OPM_visualization.historyNetwork.getIdentifier())
		// .getComponent().removeMouseListener(ml1[i]);
		// }

		new UpdatePopupListenerOnNetworkPanel().update();
	}

	public static void registerListenerForHistoryNetwork() {

		MouseListener mouseListener2 = new HistoryGraphNodeListener();
		// Cytoscape.getNetworkView(
		// OPM_visualization.historyNetwork.getIdentifier())
		// .getComponent().addMouseListener(mouseListener2);
		// JOptionPane.showMessageDialog(Cytoscape.getDesktop(),"done.");
		//
		NetworkModificationListener nl = new NetworkModificationListener();
		Cytoscape.getNodeAttributes().getMultiHashMap().addDataListener(
				new AttributeModificationListener());
		Cytoscape.getCurrentNetworkView().addGraphViewChangeListener(
				new NetworkViewModificationListener());
		// Cytoscape.getCurrentNetwork().addCyNetworkListener(new
		// NetworkModificationListener());
		// HistoryUndoableEditListener hle = new HistoryUndoableEditListener();
		// CyUndo.getUndoableEditSupport().addUndoableEditListener(hle);
	}
}
