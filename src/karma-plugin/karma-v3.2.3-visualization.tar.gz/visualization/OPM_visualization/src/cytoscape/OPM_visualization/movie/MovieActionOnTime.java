package cytoscape.OPM_visualization.movie;

import giny.model.Edge;
import giny.model.Node;
import giny.view.NodeView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.data.CyAttributes;
import cytoscape.view.CyNetworkView;

/**
 * @author Peng
 */

/*
 * First hide all the nodes, and then show each node by the order of the "Time" attribute
 * */
public class MovieActionOnTime extends Movie {
	NodeView nodeView;

	public MovieActionOnTime(NodeView pNodeView) {
		nodeView = pNodeView;
	}

	public void actionPerformed(ActionEvent e) {
		Thread t = new Thread(new Movie());
		t.start();
	}

	class Movie implements Runnable {

		@Override
		public void run() {
			// TODO Auto-generated method stub
			CyNetwork network = Cytoscape.getCurrentNetwork();
			CyNetworkView networkView = Cytoscape.getCurrentNetworkView();
			CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();

			List<Node> nodes = network.nodesList();
			List<Node> visable_nodes = new LinkedList<Node>();

			Map<String, List<Integer>> nodes_step = new HashMap<String, List<Integer>>();

			Iterator<Node> itr_nodes = nodes.iterator();

			while (itr_nodes.hasNext()) {
				Node temp = itr_nodes.next();
				String time = cyNodeAttrs.getStringAttribute(
						temp.getIdentifier(), "Time");

				if (time == null || time.equals("")) {
					visable_nodes.add(temp);
					continue;
				}
				
				NodeView nv = networkView.getNodeView(temp);
				networkView.hideGraphObject(nv);
				
				
				if (nodes_step.containsKey(time)) {
					List<Integer> ls = nodes_step.get(time);
					ls.add(temp.getRootGraphIndex());
				} else {
					List<Integer> ls = new LinkedList<Integer>();
					ls.add(temp.getRootGraphIndex());
					nodes_step.put(time, ls);
				}

			}

			networkView.redrawGraph(true, true);
			
			try {
				Thread.sleep(timeInterval);

				Object[] itr_key_obj = nodes_step.keySet().toArray();
				String[] itr_key = new String[itr_key_obj.length];
				
				for(int i = 0;i<itr_key_obj.length;i++){
					itr_key[i] = (String) itr_key_obj[i];
				}
				
				Arrays.sort(itr_key);
				for (int i = 0; i <  itr_key.length; i++) {
					String key = itr_key[i];
					List<Integer> ls = nodes_step.get(key);
					Iterator<Integer> itr_index = ls.iterator();
					while (itr_index.hasNext()) {
						int index = itr_index.next();
						networkView.showGraphObject(networkView
								.getNodeView(index));
						visable_nodes.add(network.getNode(index));
						List<Edge> edges_list = network
								.getConnectingEdges(visable_nodes);

						Iterator<Edge> itr_edge = edges_list.iterator();
						while (itr_edge.hasNext()) {
							Edge edge = itr_edge.next();
							networkView.showGraphObject(networkView
									.getEdgeView(edge));
						}
					}
					networkView.redrawGraph(true, true);
					Thread.sleep(timeInterval);

				}
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}
}