package cytoscape.OPM_visualization.actionListener;

import giny.model.Edge;
import giny.model.Node;
import giny.view.NodeView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.List;

import javax.swing.JOptionPane;

import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.data.CyAttributes;
import cytoscape.data.Semantics;

public class NodeLabelExtractor implements ActionListener {
	public static boolean enabled = false;
	private static String[] nodel_label_conversions = null;
	
	NodeView nodeView;

	public NodeLabelExtractor(NodeView pNodeView) {
		nodeView = pNodeView;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		try {
			String labels_conversion = JOptionPane.showInputDialog(Cytoscape
					.getDesktop(), "Enter the short labels.");

			if (labels_conversion != null)
				nodel_label_conversions = labels_conversion.split(",");
		} catch (Exception e) {
			JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e.toString());
		}

		enabled = true;
		CyNetwork network = Cytoscape.getCurrentNetwork();
		CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();

		List<Node> nodes = network.nodesList();
		Iterator<Node> itr_nodes = nodes.iterator();
		while (itr_nodes.hasNext()) {
			Node temp = itr_nodes.next();

			String type = cyNodeAttrs.getStringAttribute(temp.getIdentifier(),
					"NodeType");
			// if (type.contains("ARTIFACT")) {
			String node_label = cyNodeAttrs.getStringAttribute(temp
					.getIdentifier(), "node_label");

			// if (node_label.contains("SeaIce25km")) {
			// node_label = "SeaIce25km";
			// } else if (node_label.contains("BrightnessTemperatures")) {
			// node_label = "BrightnessTemperatures";
			// }

			for (int i = 0; i < nodel_label_conversions.length; i++) {
				String[] coversion_rule = nodel_label_conversions[i]
						.split("->");
				if (coversion_rule.length == 1
						&& node_label.contains(coversion_rule[0])) {
					node_label = coversion_rule[0];
				}

				if (coversion_rule.length == 2
						&& node_label.contains(coversion_rule[0])) {
					node_label = coversion_rule[1];
				}
			}

			cyNodeAttrs.setAttribute(temp.getIdentifier(), "node_label",
					node_label);
			// }

		}

		Cytoscape.getCurrentNetworkView().redrawGraph(true, true);
		Cytoscape.getCurrentNetworkView().updateView();
	}
	
	public static String labelConvert(String former_label){
		for (int i = 0; i < nodel_label_conversions.length; i++) {
			String[] coversion_rule = nodel_label_conversions[i]
					.split("->");
			if (coversion_rule.length == 1
					&& former_label.contains(coversion_rule[0])) {
				return coversion_rule[0];
			}

			if (coversion_rule.length == 2
					&& former_label.contains(coversion_rule[0])) {
				return coversion_rule[1];
			}
		}
		
		return former_label;
	}
}
