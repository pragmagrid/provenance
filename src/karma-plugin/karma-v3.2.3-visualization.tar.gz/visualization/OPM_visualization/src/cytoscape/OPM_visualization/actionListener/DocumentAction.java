package cytoscape.OPM_visualization.actionListener;

import giny.model.Edge;
import giny.model.Node;
import giny.view.NodeView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.xb.xsdschema.AnnotationDocument.Annotation;
import org.dataandsearch.www.karma.query.opmext._2012._03.WasConnectedTo;
import org.dataandsearch.www.karma.query.opmext._2012._03.WasExecutedOn;
import org.freehep.swing.ExtensionFileFilter;
import org.openprovenance.model.v1_1_a.*;
import org.openprovenance.model.v1_1_a.Process;

import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.data.CyAttributes;
import cytoscape.view.CyNetworkView;

/**
 * @author Peng
 */

/*
 * The implementation for the action of saving current graph as an OPM xml
 */
public class DocumentAction implements ActionListener {
	NodeView nodeView;
	public static String filename;

	public DocumentAction(NodeView pNodeView) {
		nodeView = pNodeView;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		JFileChooser fileChooser = new JFileChooser();

		ExtensionFileFilter filter = new ExtensionFileFilter();
		filter.addExtension("xml");
		filter.setDescription("xml files");
		fileChooser.setFileFilter(filter);

		// if set to null, will be displayed in the middle of window
		int returnVal = fileChooser.showOpenDialog(Cytoscape.getDesktop());
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			String filePath = fileChooser.getSelectedFile().getAbsolutePath();
			// System.out.println("You chose to open this file: " +
			// filePath);

			filename = filePath;
		} else {
			return;
		}

		try {
			if (!filename.contains(".xml"))
				filename = filename + ".xml";

			File saveFile = new File(filename);

			CyNetwork network = Cytoscape.getCurrentNetwork();
			CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();
			CyAttributes cyEdgeAttrs = Cytoscape.getEdgeAttributes();

			List<Node> nodes = network.nodesList();
			List<Edge> edges = network.edgesList();

			String[] attr_name = cyNodeAttrs.getAttributeNames();

			// create a new graph instance
			OpmGraphDocument opm = OpmGraphDocument.Factory.newInstance();
			OPMGraph graph = opm.addNewOpmGraph();

			AccountRef[] accounts = new AccountRef[1];
			accounts[0] = AccountRef.Factory.newInstance();

			Processes processes = graph.addNewProcesses();
			Artifacts arts = graph.addNewArtifacts();
			Agents agents = graph.addNewAgents();

			Iterator<Node> itr_nodes = nodes.iterator();
			while (itr_nodes.hasNext()) {
				Node temp = itr_nodes.next();
				String type = cyNodeAttrs.getStringAttribute(temp
						.getIdentifier(), "NodeType");
				if (type.contains("PROCESS")) {
					Process process = processes.addNewProcess();
					process.setId(temp.getIdentifier());

					String account = cyNodeAttrs.getStringAttribute(temp
							.getIdentifier(), "Account");
					if (account != null) {
						accounts[0].setRef(account);
						process.setAccountArray(accounts);
					}

					EmbeddedAnnotation[] annotations = new EmbeddedAnnotation[1];
					annotations[0] = EmbeddedAnnotation.Factory.newInstance();

					int annotationNumber = 0;

					for (int i = 0; i < attr_name.length; i++) {
						if (attr_name[i].contains("node_label")
								|| attr_name[i].contains("nested_network")
								|| cyNodeAttrs.getAttribute(temp
										.getIdentifier(), attr_name[i]) == null)
							continue;

						annotationNumber++;

						Property pro = annotations[0].addNewProperty();
						String timestep = cyNodeAttrs.getStringAttribute(temp
								.getIdentifier(), attr_name[i]);

						if (timestep != null) {
							pro.setValue(XmlObject.Factory.parse("<value>"
									+ cyNodeAttrs.getAttribute(temp
											.getIdentifier(), attr_name[i])
									+ "</value>"));

							pro.setUri(accounts[0].getRef() + "/"
									+ process.getId() + "/" + attr_name[i]);
						}
					}

					if (annotationNumber > 0) {
						process.setAnnotationArray(annotations);
					}
				} else if (type.contains("ARTIFACT")) {
					Artifact art = arts.addNewArtifact();
					art.setId(temp.getIdentifier());

					String account = cyNodeAttrs.getStringAttribute(temp
							.getIdentifier(), "Account");
					if (account != null) {
						accounts[0].setRef(account);
						art.setAccountArray(accounts);
					}

					EmbeddedAnnotation[] annotations = new EmbeddedAnnotation[1];
					annotations[0] = EmbeddedAnnotation.Factory.newInstance();

					int annotationNumber = 0;

					for (int i = 0; i < attr_name.length; i++) {
						if (attr_name[i].contains("node_label")
								|| attr_name[i].contains("nested_network")
								|| cyNodeAttrs.getAttribute(temp
										.getIdentifier(), attr_name[i]) == null)
							continue;

						annotationNumber++;

						Property pro = annotations[0].addNewProperty();
						String attribute = cyNodeAttrs.getStringAttribute(temp
								.getIdentifier(), attr_name[i]);

						if (attribute != null) {
							pro.setValue(XmlObject.Factory
									.parse("<value><![CDATA[" + attribute
											+ "]]></value>"));

							// try {
							// pro.setValue(XmlObject.Factory.parse("<value>"
							// + attribute + "</value>"));
							// } catch (XmlException e) {
							// pro.setValue(XmlObject.Factory
							// .parse("<value><![CDATA[" + attribute
							// + "]]></value>"));
							// }

							pro.setUri(accounts[0].getRef() + "/" + art.getId()
									+ "/" + attr_name[i]);
						}
					}

					if (annotationNumber > 0) {
						art.setAnnotationArray(annotations);
					}
				} else if (type.contains("AGENT")) {
					Agent agent = agents.addNewAgent();
					agent.setId(temp.getIdentifier());

					String account = cyNodeAttrs.getStringAttribute(temp
							.getIdentifier(), "Account");
					if (account != null) {
						accounts[0].setRef(account);
						agent.setAccountArray(accounts);
					}

					EmbeddedAnnotation[] annotations = new EmbeddedAnnotation[1];
					annotations[0] = EmbeddedAnnotation.Factory.newInstance();

					int annotationNumber = 0;

					for (int i = 0; i < attr_name.length; i++) {
						if (attr_name[i].contains("node_label")
								|| attr_name[i].contains("nested_network")
								|| cyNodeAttrs.getAttribute(temp
										.getIdentifier(), attr_name[i]) == null)
							continue;

						annotationNumber++;

						Property pro = annotations[0].addNewProperty();
						String timestep = cyNodeAttrs.getStringAttribute(temp
								.getIdentifier(), attr_name[i]);

						if (timestep != null) {
							pro.setValue(XmlObject.Factory.parse("<"
									+ attr_name[i]
									+ ">"
									+ cyNodeAttrs.getAttribute(temp
											.getIdentifier(), attr_name[i])
									+ "</" + attr_name[i] + ">"));

							pro.setUri(accounts[0].getRef() + "/"
									+ agent.getId() + "/" + attr_name[i]);
						}
					}
					if (annotationNumber > 0) {
						agent.setAnnotationArray(annotations);
					}
				} else if (type.contains("SUBNETWORK")) {
					Artifact art = arts.addNewArtifact();
					art.setId(temp.getIdentifier());

					String account = cyNodeAttrs.getStringAttribute(temp
							.getIdentifier(), "Account");
					if (account != null) {
						accounts[0].setRef(account);
						art.setAccountArray(accounts);
					}

					EmbeddedAnnotation[] annotations = new EmbeddedAnnotation[1];
					annotations[0] = EmbeddedAnnotation.Factory.newInstance();

					int annotationNumber = 0;

					for (int i = 0; i < attr_name.length; i++) {
						if (attr_name[i].contains("node_label")
								|| attr_name[i].contains("nested_network")
								|| cyNodeAttrs.getAttribute(temp
										.getIdentifier(), attr_name[i]) == null)
							continue;

						annotationNumber++;

						Property pro = annotations[0].addNewProperty();
						String timestep = cyNodeAttrs.getStringAttribute(temp
								.getIdentifier(), attr_name[i]);

						if (timestep != null) {
							pro.setValue(XmlObject.Factory.parse("<"
									+ attr_name[i]
									+ ">"
									+ cyNodeAttrs.getAttribute(temp
											.getIdentifier(), attr_name[i])
									+ "</" + attr_name[i] + ">"));

							pro.setUri(accounts[0].getRef() + "/" + art.getId()
									+ "/" + attr_name[i]);
						}
					}
					if (annotationNumber > 0) {
						art.setAnnotationArray(annotations);
					}
				}
			}

			// attr_name = cyEdgeAttrs.getAttributeNames();

			CausalDependencies causalDependencies = graph
					.addNewCausalDependencies();
			ArtifactRef artRef = ArtifactRef.Factory.newInstance();
			ProcessRef proRef = ProcessRef.Factory.newInstance();
			AgentRef agentRef = AgentRef.Factory.newInstance();

			Iterator<Edge> itr_edges = edges.iterator();
			while (itr_edges.hasNext()) {
				Edge temp = itr_edges.next();
				String type = cyEdgeAttrs.getStringAttribute(temp
						.getIdentifier(), "interaction");
				if (type.contains("used")) {
					Used used = causalDependencies.addNewUsed();

					accounts[0].setRef(cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "AccountRef"));
					used.setAccountArray(accounts);

					artRef.setRef(temp.getTarget().getIdentifier());
					used.setCause(artRef);

					proRef.setRef(temp.getSource().getIdentifier());
					used.setEffect(proRef);

					String noEarlierThan = cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "NoEarlierThan");
					String noLaterThan = cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "NoLaterThan");

					if (noEarlierThan != null) {
						OTime time = used.addNewTime();
						Date date = new SimpleDateFormat(
								"EEE MMM dd HH:mm:ss z yyyy")
								.parse(noEarlierThan);
						Calendar cal = Calendar.getInstance();

						cal.setTime(date);
						time.setNoEarlierThan(cal);
					}

					if (noLaterThan != null) {
						OTime time = used.addNewTime();
						Date date = new SimpleDateFormat(
								"EEE MMM dd HH:mm:ss z yyyy")
								.parse(noLaterThan);
						Calendar cal = Calendar.getInstance();

						cal.setTime(date);
						time.setNoLaterThan(cal);
					}

				} else if (type.contains("wasControlledBy")) {
					WasControlledBy wasControlledBy = causalDependencies
							.addNewWasControlledBy();

					accounts[0].setRef(cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "AccountRef"));
					wasControlledBy.setAccountArray(accounts);

					agentRef.setRef(temp.getTarget().getIdentifier());
					wasControlledBy.setCause(agentRef);
					proRef.setRef(temp.getSource().getIdentifier());
					wasControlledBy.setEffect(proRef);
				} else if (type.contains("wasDerivedFrom")) {
					WasDerivedFrom wasDerivedFrom = causalDependencies
							.addNewWasDerivedFrom();

					accounts[0].setRef(cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "AccountRef"));
					wasDerivedFrom.setAccountArray(accounts);

					artRef.setRef(temp.getTarget().getIdentifier());
					wasDerivedFrom.setCause(artRef);
					artRef.setRef(temp.getSource().getIdentifier());
					wasDerivedFrom.setEffect(artRef);

					String noEarlierThan = cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "NoEarlierThan");
					String noLaterThan = cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "NoLaterThan");

					if (noEarlierThan != null) {
						OTime time = wasDerivedFrom.addNewTime();
						Date date = new SimpleDateFormat(
								"EEE MMM dd HH:mm:ss z yyyy")
								.parse(noEarlierThan);
						Calendar cal = Calendar.getInstance();

						cal.setTime(date);
						time.setNoEarlierThan(cal);
					}

					if (noLaterThan != null) {
						OTime time = wasDerivedFrom.addNewTime();
						Date date = new SimpleDateFormat(
								"EEE MMM dd HH:mm:ss z yyyy")
								.parse(noLaterThan);
						Calendar cal = Calendar.getInstance();

						cal.setTime(date);
						time.setNoLaterThan(cal);
					}
				} else if (type.contains("wasGeneratedBy")) {
					WasGeneratedBy wasGeneratedBy = causalDependencies
							.addNewWasGeneratedBy();

					accounts[0].setRef(cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "AccountRef"));
					wasGeneratedBy.setAccountArray(accounts);

					proRef.setRef(temp.getTarget().getIdentifier());
					wasGeneratedBy.setCause(proRef);
					artRef.setRef(temp.getSource().getIdentifier());
					wasGeneratedBy.setEffect(artRef);

					String noEarlierThan = cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "NoEarlierThan");
					String noLaterThan = cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "NoLaterThan");

					if (noEarlierThan != null) {
						OTime time = wasGeneratedBy.addNewTime();
						Date date = new SimpleDateFormat(
								"EEE MMM dd HH:mm:ss z yyyy")
								.parse(noEarlierThan);
						Calendar cal = Calendar.getInstance();

						cal.setTime(date);
						time.setNoEarlierThan(cal);
					}

					if (noLaterThan != null) {
						OTime time = wasGeneratedBy.addNewTime();
						Date date = new SimpleDateFormat(
								"EEE MMM dd HH:mm:ss z yyyy")
								.parse(noLaterThan);
						Calendar cal = Calendar.getInstance();

						cal.setTime(date);
						time.setNoLaterThan(cal);
					}

				} else if (type.contains("wasTriggeredBy")) {
					WasTriggeredBy wasTriggeredBy = causalDependencies
							.addNewWasTriggeredBy();

					accounts[0].setRef(cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "AccountRef"));
					wasTriggeredBy.setAccountArray(accounts);

					proRef.setRef(temp.getTarget().getIdentifier());
					wasTriggeredBy.setCause(proRef);
					proRef.setRef(temp.getSource().getIdentifier());
					wasTriggeredBy.setEffect(proRef);

					String noEarlierThan = cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "NoEarlierThan");
					String noLaterThan = cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "NoLaterThan");

					if (noEarlierThan != null) {
						OTime time = wasTriggeredBy.addNewTime();
						Date date = new SimpleDateFormat(
								"EEE MMM dd HH:mm:ss z yyyy")
								.parse(noEarlierThan);
						Calendar cal = Calendar.getInstance();

						cal.setTime(date);
						time.setNoEarlierThan(cal);
					}

					if (noLaterThan != null) {
						OTime time = wasTriggeredBy.addNewTime();
						Date date = new SimpleDateFormat(
								"EEE MMM dd HH:mm:ss z yyyy")
								.parse(noLaterThan);
						Calendar cal = Calendar.getInstance();

						cal.setTime(date);
						time.setNoLaterThan(cal);
					}
				} else if (type.contains("wasExecutedOn")) {
					WasExecutedOn wasExecutedOn = causalDependencies
							.addNewWasExecutedOn();

					accounts[0].setRef(cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "AccountRef"));
					wasExecutedOn.setAccountArray(accounts);

					proRef.setRef(temp.getTarget().getIdentifier());
					wasExecutedOn.setCause(proRef);
					proRef.setRef(temp.getSource().getIdentifier());
					wasExecutedOn.setEffect(proRef);

					String noEarlierThan = cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "NoEarlierThan");
					String noLaterThan = cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "NoLaterThan");

					if (noEarlierThan != null) {
						OTime time = wasExecutedOn.addNewTime();
						Date date = new SimpleDateFormat(
								"EEE MMM dd HH:mm:ss z yyyy")
								.parse(noEarlierThan);
						Calendar cal = Calendar.getInstance();

						cal.setTime(date);
						time.setNoEarlierThan(cal);
					}

					if (noLaterThan != null) {
						OTime time = wasExecutedOn.addNewTime();
						Date date = new SimpleDateFormat(
								"EEE MMM dd HH:mm:ss z yyyy")
								.parse(noLaterThan);
						Calendar cal = Calendar.getInstance();

						cal.setTime(date);
						time.setNoLaterThan(cal);
					}
				} else if (type.contains("wasConnectedTo")) {
					WasConnectedTo wasConnectedTo = causalDependencies
							.addNewWasConnectedTo();

					accounts[0].setRef(cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "AccountRef"));
					wasConnectedTo.setAccountArray(accounts);

					proRef.setRef(temp.getTarget().getIdentifier());
					wasConnectedTo.setCause(proRef);
					proRef.setRef(temp.getSource().getIdentifier());
					wasConnectedTo.setEffect(proRef);

					String noEarlierThan = cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "NoEarlierThan");
					String noLaterThan = cyEdgeAttrs.getStringAttribute(temp
							.getIdentifier(), "NoLaterThan");

					if (noEarlierThan != null) {
						OTime time = wasConnectedTo.addNewTime();
						Date date = new SimpleDateFormat(
								"EEE MMM dd HH:mm:ss z yyyy")
								.parse(noEarlierThan);
						Calendar cal = Calendar.getInstance();

						cal.setTime(date);
						time.setNoEarlierThan(cal);
					}

					if (noLaterThan != null) {
						OTime time = wasConnectedTo.addNewTime();
						Date date = new SimpleDateFormat(
								"EEE MMM dd HH:mm:ss z yyyy")
								.parse(noLaterThan);
						Calendar cal = Calendar.getInstance();

						cal.setTime(date);
						time.setNoLaterThan(cal);
					}
				}
			}

			FileWriter fw = new FileWriter(saveFile);
			fw.append(opm.xmlText());
			fw.flush();
			fw.close();

			JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
					"File saved to" + filename);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
			// e.toString());
			e.printStackTrace();
			JOptionPane
					.showMessageDialog(Cytoscape.getDesktop(),
							"Failed: The graph's structure should comply with OPM v1.1");
		}

	}
}
