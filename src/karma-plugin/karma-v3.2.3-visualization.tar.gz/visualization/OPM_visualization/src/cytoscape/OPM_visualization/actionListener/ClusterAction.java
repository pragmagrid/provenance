package cytoscape.OPM_visualization.actionListener;

import giny.model.Edge;
import giny.model.Node;
import giny.view.NodeView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

import csplugins.layout.algorithms.GroupAttributesLayout;
import csplugins.layout.algorithms.circularLayout.CircularLayoutAlgorithm;
import csplugins.layout.algorithms.hierarchicalLayout.HierarchicalLayoutAlgorithm;
import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.OPM_visualization.OPM_visualization;
import cytoscape.OPM_visualization.eventListener.MyNodeContextMenuListener;
import cytoscape.data.CyAttributes;
import cytoscape.data.Semantics;
import cytoscape.view.CyNetworkView;
import cytoscape.view.InternalFrameComponent;
import cytoscape.view.NetworkViewManager;
import ding.view.NodeContextMenuListener;

/**
 * @author Peng
 */

/*
 * Cluster all the children of the selected node, which has node degree one
 * (That means that node only connected to the selected node, which is very
 * likely to be an artifact)
 */
public class ClusterAction implements ActionListener {
	NodeView nodeView;

	public ClusterAction(NodeView pNodeView) {
		nodeView = pNodeView;
	}

	public void actionPerformed(ActionEvent e) {
		String new_time = null;

		CyNetwork network = Cytoscape.getCurrentNetwork();
		List<Node> neighbor = network.neighborsList(nodeView.getNode());

		CyAttributes cyNodeAttributes = Cytoscape.getNodeAttributes();
		CyAttributes cyEdgeAttributes = Cytoscape.getEdgeAttributes();
		// if there is no neighbor
		if (neighbor == null) {
			return;
		}

		// the abstract node
		Node new_node = null;
		// collect all the nodes to be clustered
		List<Integer> nodes = new LinkedList<Integer>();

		// add the current node into sub network
		nodes.add(nodeView.getNode().getRootGraphIndex());

		Iterator<Node> itr_n = neighbor.iterator();
		while (itr_n.hasNext()) {
			Node tmp_node = itr_n.next();
			if (network.getDegree(tmp_node.getRootGraphIndex()) == 1) {
				// the size should be 1
				int[] old_edges = network.getAdjacentEdgeIndicesArray(tmp_node
						.getRootGraphIndex(), true, true, true);
				Edge old_edge = network.getEdge(old_edges[0]);

				// add the old node into the sub network
				nodes.add(tmp_node.getRootGraphIndex());

				String objectType = cyNodeAttributes.getStringAttribute(
						tmp_node.getIdentifier(), "objectType");
				if (objectType == null)
					objectType = "";

				new_node = Cytoscape.getCyNode("SubGraph:"
						+ nodeView.getNode().getIdentifier(), true);

				cyNodeAttributes.setAttribute(new_node.getIdentifier(),
						"NodeType", "SUBNETWORK");

				cyNodeAttributes.setAttribute(new_node.getIdentifier(),
						"objectType", objectType);

				cyNodeAttributes.setAttribute(new_node.getIdentifier(),
						"node_label", "SubGraph");

				network.addNode(new_node);

				/*
				 * add an abstract edge here
				 */

				Edge new_edge;

				if (old_edge.getSource().equals(tmp_node)) {
					new_edge = Cytoscape.getCyEdge(new_node,
							nodeView.getNode(), Semantics.INTERACTION,
							cyEdgeAttributes.getAttribute(old_edge
									.getIdentifier(), "interaction"), true,
							true);
				} else {
					new_edge = Cytoscape.getCyEdge(nodeView.getNode(),
							new_node, Semantics.INTERACTION, cyEdgeAttributes
									.getAttribute(old_edge.getIdentifier(),
											"interaction"), true, true);
				}

				cyEdgeAttributes.setAttribute(new_edge.getIdentifier(),
						"NoEarlierThan", cyEdgeAttributes.getStringAttribute(
								old_edge.getIdentifier(), "NoEarlierThan"));

				cyEdgeAttributes.setAttribute(new_edge.getIdentifier(),
						"NoLaterThan", cyEdgeAttributes.getStringAttribute(
								old_edge.getIdentifier(), "NoLaterThan"));

				if (new_time == null
						|| new_time.compareTo(cyEdgeAttributes
								.getStringAttribute(old_edge.getIdentifier(),
										"NoEarlierThan")) > 0) {
					new_time = cyEdgeAttributes.getStringAttribute(old_edge
							.getIdentifier(), "NoEarlierThan");
				}

				network.addEdge(new_edge);

			}
		}

		cyNodeAttributes.setAttribute(new_node.getIdentifier(), "Time",
				new_time);

		// create the sub network
		int[] node_array = new int[nodes.size()];
		for (int i = 0; i < node_array.length; i++) {
			node_array[i] = nodes.get(i);
		}
		int[] edges_array = network.getConnectingEdgeIndicesArray(node_array);
		CyNetwork new_network = Cytoscape.createNetwork(node_array,
				edges_array, new_node.getIdentifier(), network);
		CyNetworkView new_networkView = Cytoscape
				.createNetworkView(new_network);

		GroupAttributesLayout gal = new GroupAttributesLayout();
		gal.setLayoutAttribute("NodeType");
		// new_networkView.applyLayout(new CircularLayoutAlgorithm());
		new_networkView.applyLayout(gal);

		// attach the new network to abstract node
		new_node.setNestedNetwork(new_network);

//		MouseListener mouseListener = new NodeAttributeViewListener();
//		new_networkView.getComponent().addMouseListener(mouseListener);

		for (int i = 1; i < node_array.length; i++) {
			network.removeNode(node_array[i], false);
		}

		// put the previous network under view

		NetworkViewManager nm = Cytoscape.getDesktop().getNetworkViewManager();
		CyNetworkView nv = Cytoscape.getNetworkView(network.getIdentifier());

		nodeView.setSelected(false);
		nv.getNodeView(new_node).select();

//		MyNodeContextMenuListener l = new MyNodeContextMenuListener();
//		new_networkView.addNodeContextMenuListener(l);
		
		OPM_visualization.registerListenerForCurrentView();
		
		try {
			nm.getInternalFrame(nv).show();
			nm.getInternalFrame(nv).setSelected(true);

		} catch (Exception e1) {
			JOptionPane
					.showMessageDialog(Cytoscape.getDesktop(), e1.toString());
		}
	}
}
