package cytoscape.OPM_visualization.actionListener;

import giny.model.Node;
import giny.view.NodeView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Set;
import javax.swing.JOptionPane;
import cytoscape.Cytoscape;
import cytoscape.OPM_visualization.util.DetailLoader;

public class LoadDetailAction implements ActionListener {
	NodeView nodeView;

	public LoadDetailAction(NodeView pNodeView) {
		nodeView = pNodeView;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		// new UndoAction().actionPerformed(null);
		try {

			Set<Node> nodes = Cytoscape.getCurrentNetwork().getSelectedNodes();

			DetailLoader dl = new DetailLoader(nodes);
			Thread t = new Thread(dl);
			t.start();

		} catch (Exception e) {
			JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e.toString());
		}
	}
}
