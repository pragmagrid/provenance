package cytoscape.OPM_visualization.actionListener;

import giny.model.Node;
import giny.view.EdgeView;
import giny.view.NodeView;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.data.CyAttributes;
import cytoscape.visual.ArrowShape;
import cytoscape.visual.CalculatorCatalog;
import cytoscape.visual.EdgeAppearanceCalculator;
import cytoscape.visual.GlobalAppearanceCalculator;
import cytoscape.visual.NodeAppearanceCalculator;
import cytoscape.visual.NodeShape;
import cytoscape.visual.VisualMappingManager;
import cytoscape.visual.VisualPropertyType;
import cytoscape.visual.VisualStyle;
import cytoscape.visual.calculators.BasicCalculator;
import cytoscape.visual.calculators.Calculator;
import cytoscape.visual.mappings.DiscreteMapping;
import cytoscape.visual.mappings.ObjectMapping;
import cytoscape.visual.mappings.PassThroughMapping;

public class WiMAX_ORBIT_Action implements ActionListener {
	private static Map<String, Color> NodeColor;

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();
		CyAttributes cyEdgeAttrs = Cytoscape.getEdgeAttributes();
		// Iterator<Node> it = network.nodesIterator();
		Iterator<NodeView> iter = Cytoscape.getCurrentNetworkView()
				.getNodeViewsIterator();
		Node node = null;
		NodeView nodeView = null;
		Set<Integer> hasTravelled = new HashSet<Integer>();

		// this hash map is used to map color to different VisRole
		NodeColor = new HashMap<String, Color>();

		while (iter.hasNext()) {
			nodeView = iter.next();
			node = nodeView.getNode();

			if (hasTravelled.contains(node.getRootGraphIndex()))
				continue;
			else
				hasTravelled.add(node.getRootGraphIndex());

			/*
			 * Mark different nodes
			 */
			String process_serviceID = cyNodeAttrs.getStringAttribute(node
					.getIdentifier(), "process-serviceID");

			if (process_serviceID != null) {
				String[] index = process_serviceID.split("\\s");

				// mark attacker/normal nodes
				if (index.length > 1 && index[1].contains("Sender")) {

					String sender_ipAddress = cyNodeAttrs.getStringAttribute(
							node.getIdentifier(), "ipAddress");
					if (sender_ipAddress != null) {
						// mark packet with source ip
						CyNetwork network = Cytoscape.getCurrentNetwork();

						int[] incoming_edges = network
								.getAdjacentEdgeIndicesArray(node
										.getRootGraphIndex(), false, true,
										false);
						for (int edge : incoming_edges) {
							cyNodeAttrs.setAttribute(network.getEdge(edge)
									.getSource().getIdentifier(), "VisRole",
									"from " + sender_ipAddress);
							hasTravelled.add(network.getEdge(edge).getSource()
									.getRootGraphIndex());
							NodeColor.put("from " + sender_ipAddress,
									Color.WHITE);
						}
					}

					// mark normal nodes
					String nodeType = cyNodeAttrs.getStringAttribute(node
							.getIdentifier(), "NodeType");
					cyNodeAttrs.setAttribute(node.getIdentifier(), "VisRole",
							nodeType);

				} else if (index.length > 1 && index[1].equals("Receiver")) {

					// mark packet with source ip
					CyNetwork network = Cytoscape.getCurrentNetwork();

					int[] incoming_edges = network.getAdjacentEdgeIndicesArray(
							node.getRootGraphIndex(), false, true, false);
					for (int edge : incoming_edges) {
						String sender_ipAddress = cyNodeAttrs
								.getStringAttribute(network.getEdge(edge)
										.getSource().getIdentifier(),
										"src_host");
						cyNodeAttrs.setAttribute(network.getEdge(edge)
								.getSource().getIdentifier(), "VisRole",
								"from " + sender_ipAddress);
						hasTravelled.add(network.getEdge(edge).getSource()
								.getRootGraphIndex());
						NodeColor.put("from " + sender_ipAddress, Color.WHITE);
					}

					// mark normal nodes
					String nodeType = cyNodeAttrs.getStringAttribute(node
							.getIdentifier(), "NodeType");
					cyNodeAttrs.setAttribute(node.getIdentifier(), "VisRole",
							nodeType);
				} else {
					// all other nodes
					String nodeType = cyNodeAttrs.getStringAttribute(node
							.getIdentifier(), "NodeType");
					cyNodeAttrs.setAttribute(node.getIdentifier(), "VisRole",
							nodeType);
				}
				
			} else {
				// nodes do not have process-id
				String nodeType = cyNodeAttrs.getStringAttribute(node
						.getIdentifier(), "NodeType");
				cyNodeAttrs.setAttribute(node.getIdentifier(), "VisRole",
						nodeType);
			}

		}

		// get the VisualMappingManager and CalculatorCatalog
		VisualMappingManager manager = Cytoscape.getVisualMappingManager();
		CalculatorCatalog catalog = manager.getCalculatorCatalog();

		// check to see if a visual style with this name already exists
		VisualStyle vs = catalog.getVisualStyle("WiMAXORBIT");
		if (vs == null) {
			// if not, create it and add it to the catalog
			vs = createVisualStyle(Cytoscape.getCurrentNetwork(), "WiMAXORBIT");
			catalog.addVisualStyle(vs);
		} else {
			catalog.removeVisualStyle("WiMAXORBIT");
			vs = createVisualStyle(Cytoscape.getCurrentNetwork(), "WiMAXORBIT");
			catalog.addVisualStyle(vs);
		}

		manager.setVisualStyle(vs);
		Cytoscape.getCurrentNetworkView().redrawGraph(true, true);
	}

	public boolean isInt(String s) {
		try {
			Integer.parseInt(s);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	VisualStyle createVisualStyle(CyNetwork network, String vsName) {

		NodeAppearanceCalculator nodeAppCalc = new NodeAppearanceCalculator();
		EdgeAppearanceCalculator edgeAppCalc = new EdgeAppearanceCalculator();
		GlobalAppearanceCalculator globalAppCalc = new GlobalAppearanceCalculator();

		globalAppCalc.setDefaultBackgroundColor(new Color(153, 153, 153));

		// Passthrough Mapping - set node label
		PassThroughMapping pm1 = new PassThroughMapping(new String(),
				"node_label");

		BasicCalculator nlc = new BasicCalculator(
				"Example Node Label Calculator", pm1,
				VisualPropertyType.NODE_LABEL);

		nodeAppCalc.setCalculator(nlc);

		// Discrete Mapping - set node shapes
		DiscreteMapping disMapping = new DiscreteMapping(NodeShape.RECT,
				ObjectMapping.NODE_MAPPING);
		disMapping.setControllingAttributeName("NodeType", network, false);
		disMapping.putMapValue("PROCESS", NodeShape.ROUND_RECT);
		disMapping.putMapValue("ARTIFACT", NodeShape.ELLIPSE);
		disMapping.putMapValue("SUBNETWORK", NodeShape.OCTAGON);
		disMapping.putMapValue("AGENT", NodeShape.OCTAGON);

		Calculator shapeCalculator = new BasicCalculator(
				"Example Node Shape Calculator", disMapping,
				VisualPropertyType.NODE_SHAPE);
		nodeAppCalc.setCalculator(shapeCalculator);

		// Discrete Mapping - Set node color
		final Color NODE_COLOR = new Color(10, 10, 10);

		DiscreteMapping nodeColor = new DiscreteMapping(NODE_COLOR, "VisRole",
				ObjectMapping.NODE_MAPPING);

		/*
		 * Create rainbow colors
		 */
		final float increment = 1f / NodeColor.keySet().size();

		float hue = 0;

		for (String key : NodeColor.keySet()) {
			hue = hue + increment;
			NodeColor.put(key, new Color(Color.HSBtoRGB(hue, 1f, 1f)));
		}

		NodeColor.put("PROCESS", new Color(50, 255, 50));
		NodeColor.put("ARTIFACT", new Color(255, 50, 255));
		NodeColor.put("SUBNETWORK", new Color(255, 255, 255));
		NodeColor.put("AGENT", new Color(255, 50, 50));

		for (String key : NodeColor.keySet()) {
			nodeColor.putMapValue(key, NodeColor.get(key));
		}

		Calculator nodeColorCalc = new BasicCalculator("EdgeColorMapping",
				nodeColor, VisualPropertyType.NODE_FILL_COLOR);

		nodeAppCalc.setCalculator(nodeColorCalc);

		// set edge label
		PassThroughMapping pm_e = new PassThroughMapping(new String(),
				"interaction");

		BasicCalculator edc = new BasicCalculator(
				"Example Edge Label Calculator", pm_e,
				VisualPropertyType.EDGE_LABEL);

		edgeAppCalc.setCalculator(edc);

		// Discrete Mapping - Set edge color
		final Color EDGE_COLOR = new Color(10, 10, 10);

		DiscreteMapping edgeColor = new DiscreteMapping(EDGE_COLOR, "VisRole",
				ObjectMapping.EDGE_MAPPING);

		edgeColor.putMapValue("used", new Color(100, 255, 100));
		edgeColor.putMapValue("wasTriggeredBy", Color.YELLOW);
		edgeColor.putMapValue("wasGeneratedBy", new Color(204, 204, 204));
		edgeColor.putMapValue("wasDerivedFrom", new Color(0, 200, 255));

		Calculator edgeColorCalc = new BasicCalculator("EdgeColorMapping",
				edgeColor, VisualPropertyType.EDGE_COLOR);

		edgeAppCalc.setCalculator(edgeColorCalc);

		// Discrete Mapping - Set edge target arrow shape
		DiscreteMapping arrowMapping = new DiscreteMapping(ArrowShape.NONE,
				ObjectMapping.EDGE_MAPPING);
		arrowMapping.setControllingAttributeName("interaction", network, false);
		arrowMapping.putMapValue("wasTriggeredBy", ArrowShape.ARROW);
		arrowMapping.putMapValue("wasGeneratedBy", ArrowShape.CIRCLE);
		arrowMapping.putMapValue("wasDerivedFrom", ArrowShape.CIRCLE);
		arrowMapping.putMapValue("used", ArrowShape.DELTA);
		arrowMapping.putMapValue("wasControlledBy", ArrowShape.DIAMOND);

		Calculator edgeArrowCalculator = new BasicCalculator(
				"Example Edge Arrow Shape Calculator", arrowMapping,
				VisualPropertyType.EDGE_TGTARROW_SHAPE);
		edgeAppCalc.setCalculator(edgeArrowCalculator);

		// Create the visual style
		VisualStyle visualStyle = new VisualStyle(vsName, nodeAppCalc,
				edgeAppCalc, globalAppCalc);

		return visualStyle;
	}
}
