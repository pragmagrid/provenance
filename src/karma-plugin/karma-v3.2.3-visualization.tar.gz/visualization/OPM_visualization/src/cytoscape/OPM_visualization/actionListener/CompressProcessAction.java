package cytoscape.OPM_visualization.actionListener;

import giny.model.Edge;
import giny.model.Node;
import giny.view.NodeView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.List;

import javax.swing.JOptionPane;

import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.data.CyAttributes;
import cytoscape.data.Semantics;
import cytoscape.util.undo.UndoAction;

public class CompressProcessAction implements ActionListener {
	NodeView nodeView;
	public static String filename;

	public CompressProcessAction(NodeView pNodeView) {
		nodeView = pNodeView;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
//		new UndoAction().actionPerformed(null);

		CyNetwork network = Cytoscape.getCurrentNetwork();
		CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();
		CyAttributes cyEdgeAttrs = Cytoscape.getEdgeAttributes();

		List<Node> nodes = network.nodesList();
		Iterator<Node> itr_nodes = nodes.iterator();
		while (itr_nodes.hasNext()) {
			Node temp = itr_nodes.next();

			String type = cyNodeAttrs.getStringAttribute(temp.getIdentifier(),
					"NodeType");
			if (type.contains("ARTIFACT")) {
				int[] edges = network.getAdjacentEdgeIndicesArray(temp
						.getRootGraphIndex(), false, false, true);
				for (int i = 0; i < edges.length; i++) {
					Edge edge = network.getEdge(edges[i]);

					if (!cyEdgeAttrs.getStringAttribute(edge.getIdentifier(),
							"interaction").equalsIgnoreCase("wasGeneratedBy"))
						continue;

					Node node = edge.getTarget();
					int[] second_edges = network.getAdjacentEdgeIndicesArray(
							node.getRootGraphIndex(), false, false, true);
					boolean isCompressed = false;
					for (int j = 0; j < second_edges.length; j++) {
						Edge second_edge = network.getEdge(second_edges[j]);

						if (!cyEdgeAttrs.getStringAttribute(
								second_edge.getIdentifier(), "interaction")
								.equalsIgnoreCase("used"))
							continue;
						
						Node second_node = second_edge.getTarget();
						
						Edge new_edge = Cytoscape.getCyEdge(temp, second_node,
								Semantics.INTERACTION, "wasDerivedFrom", true);
						network.addEdge(new_edge);
						isCompressed = true;
					}
					
					if(isCompressed){
						network.hideNode(node.getRootGraphIndex());
					}
				}
			}

		}
		
		Cytoscape.getCurrentNetworkView().redrawGraph(true, true);
	}
}
