package cytoscape.OPM_visualization.eventListener;

import java.util.LinkedList;
import java.util.List;

import javax.swing.JOptionPane;

import cytoscape.Cytoscape;
import cytoscape.OPM_visualization.util.DetailLoader;

import giny.model.Node;
import giny.view.GraphViewChangeEvent;
import giny.view.GraphViewChangeListener;

public class AutomaticalLoadingEventListener implements GraphViewChangeListener {

	@Override
	public void graphViewChanged(GraphViewChangeEvent arg0) {
		// TODO Auto-generated method stub
		if (arg0.isNodesSelectedType()) {
			List<Node> nodes = new LinkedList<Node>();
			Node[] nodes_array = arg0.getSelectedNodes();
			for (Node node : nodes_array)
				nodes.add(node);

			DetailLoader dl = null;
			try {
				dl = new DetailLoader(nodes);
				Thread t = new Thread(dl);
				t.start();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e
						.toString());
			}

		}
	}
}
