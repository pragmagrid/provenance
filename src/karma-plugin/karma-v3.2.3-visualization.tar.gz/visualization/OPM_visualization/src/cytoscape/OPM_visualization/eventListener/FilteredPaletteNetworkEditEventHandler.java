package cytoscape.OPM_visualization.eventListener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class FilteredPaletteNetworkEditEventHandler implements MouseListener {

	private final MouseListener me;

	public FilteredPaletteNetworkEditEventHandler(MouseListener me) {
		this.me = me;
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		if (arg0.getClickCount() != 2)
			me.mouseClicked(arg0);
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		if (arg0.getClickCount() != 2)
			me.mouseEntered(arg0);
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		if (arg0.getClickCount() != 2)
			me.mouseEntered(arg0);
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		if (arg0.getClickCount() != 2)
			me.mousePressed(arg0);
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		if (arg0.getClickCount() != 2)
			me.mouseReleased(arg0);
	}

}
