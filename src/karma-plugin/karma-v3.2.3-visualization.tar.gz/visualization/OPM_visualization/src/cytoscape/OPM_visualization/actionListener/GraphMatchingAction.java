package cytoscape.OPM_visualization.actionListener;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.OPM_visualization.eventListener.MatchedNodesAttributeViewListener;
import cytoscape.OPM_visualization.eventListener.NodeAttributeViewListener;
import cytoscape.data.CyAttributes;
import cytoscape.visual.ArrowShape;
import cytoscape.visual.CalculatorCatalog;
import cytoscape.visual.EdgeAppearanceCalculator;
import cytoscape.visual.GlobalAppearanceCalculator;
import cytoscape.visual.NodeAppearanceCalculator;
import cytoscape.visual.NodeShape;
import cytoscape.visual.VisualMappingManager;
import cytoscape.visual.VisualPropertyType;
import cytoscape.visual.VisualStyle;
import cytoscape.visual.calculators.BasicCalculator;
import cytoscape.visual.calculators.Calculator;
import cytoscape.visual.mappings.DiscreteMapping;
import cytoscape.visual.mappings.ObjectMapping;
import cytoscape.visual.mappings.PassThroughMapping;
import cytoscape.visual.ui.MappingKeyFactory;

public class GraphMatchingAction implements ActionListener {
	// minimal attendance required
	double THRESHOLD = 0.5;
	final static String vsName = "DCA subgraph matching";

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		final List<CyNetwork> selected = Cytoscape.getSelectedNetworks();

		if (selected == null || selected.size() != 2)
			return;

		CyNetwork network_1 = selected.get(0);
		CyNetwork network_2 = selected.get(1);

		int[] nodes_1 = network_1.getNodeIndicesArray();
		int[] nodes_2 = network_2.getNodeIndicesArray();

		// comparing against larger set of nodes
		int[] nodes_lg, nodes_sm;
		CyNetwork network_lg, network_sm;
		if (nodes_1.length > nodes_2.length) {
			nodes_lg = nodes_1;
			nodes_sm = nodes_2;

			network_lg = network_1;
			network_sm = network_2;
		} else {
			nodes_lg = nodes_2;
			nodes_sm = nodes_1;

			network_lg = network_2;
			network_sm = network_1;
		}

		/* create adjacency matrix */
		int[][] adjacencyMatrix_1 = new int[nodes_lg.length][nodes_lg.length];
		int[][] adjacencyMatrix_2 = new int[nodes_sm.length][nodes_sm.length];

		for (int i = 0; i < nodes_lg.length; i++) {
			for (int j = 0; j < nodes_lg.length; j++) {
				if (network_lg.isNeighbor(nodes_lg[i], nodes_lg[j])) {
					adjacencyMatrix_1[i][j] = 1;
				} else
					adjacencyMatrix_1[i][j] = 0;
			}
		}

		for (int i = 0; i < nodes_sm.length; i++) {
			for (int j = 0; j < nodes_sm.length; j++) {
				if (network_sm.isNeighbor(nodes_sm[i], nodes_sm[j])) {
					adjacencyMatrix_2[i][j] = 1;
				} else
					adjacencyMatrix_2[i][j] = 0;
			}
		}

		/* create layers of connectivity matix */
		int N = nodes_lg.length;
		int Vmax = N / 4;

		int[][][] connectivityMatrixs_1 = new int[Vmax][nodes_lg.length][nodes_lg.length];
		int[][][] connectivityMatrixs_2 = new int[Vmax][nodes_sm.length][nodes_sm.length];

		connectivityMatrixs_1[0] = adjacencyMatrix_1;
		connectivityMatrixs_2[0] = adjacencyMatrix_2;
		for (int i = 1; i < Vmax; i++) {
			connectivityMatrixs_1[i] = multiply(connectivityMatrixs_1[i - 1],
					connectivityMatrixs_1[i - 1]);
			connectivityMatrixs_2[i] = multiply(connectivityMatrixs_2[i - 1],
					connectivityMatrixs_2[i - 1]);
		}

		// double[][][] normalizedConnectivityMatrixs_1 = new
		// double[Vmax][nodes_lg.length][nodes_lg.length];
		// double[][][] normalizedConnectivityMatrixs_2 = new
		// double[Vmax][nodes_sm.length][nodes_sm.length];

		// for (int i = 0; i < connectivityMatrixs_1.length; i++) {
		// int minimalConnectivity_1 = Integer.MAX_VALUE;
		//
		// for (int j = 0; j < connectivityMatrixs_1[i].length; j++) {
		// for (int k = 0; k < connectivityMatrixs_1[i][j].length; k++) {
		// if (minimalConnectivity_1 > connectivityMatrixs_1[i][j][k])
		// minimalConnectivity_1 = connectivityMatrixs_1[i][j][k];
		// }
		// }
		//
		// for (int j = 0; j < connectivityMatrixs_1[i].length; j++) {
		// for (int k = 0; k < connectivityMatrixs_1[i][j].length; k++) {
		// normalizedConnectivityMatrixs_1[i][j][k] = 1.0
		// * connectivityMatrixs_1[i][j][k]
		// / minimalConnectivity_1;
		// }
		// }
		// }

		// for (int i = 0; i < connectivityMatrixs_2.length; i++) {
		// int minimalConnectivity_2 = Integer.MAX_VALUE;
		//
		// for (int j = 0; j < connectivityMatrixs_2[i].length; j++) {
		// for (int k = 0; k < connectivityMatrixs_2[i][j].length; k++) {
		// if (minimalConnectivity_2 > connectivityMatrixs_2[i][j][k])
		// minimalConnectivity_2 = connectivityMatrixs_2[i][j][k];
		// }
		// }
		//
		// for (int j = 0; j < connectivityMatrixs_2[i].length; j++) {
		// for (int k = 0; k < connectivityMatrixs_2[i][j].length; k++) {
		// normalizedConnectivityMatrixs_2[i][j][k] = 1.0
		// * connectivityMatrixs_2[i][j][k]
		// / minimalConnectivity_2;
		// }
		// }
		// }

		Map<Integer, Integer> reverse_map_lg = new HashMap<Integer, Integer>();
		Map<Integer, Integer> reverse_map_sm = new HashMap<Integer, Integer>();

		for (int i = 0; i < nodes_lg.length; i++) {
			reverse_map_lg.put(nodes_lg[i], i);
		}

		for (int i = 0; i < nodes_sm.length; i++) {
			reverse_map_sm.put(nodes_sm[i], i);
		}

		// Compare each pair of nodes in each graph
		double[][] attendanceRating = new double[nodes_lg.length][nodes_sm.length];
		for (int i = 0; i < nodes_lg.length; i++) {
			for (int j = 0; j < nodes_sm.length; j++) {

				// compare incoming edges of current nodes
				int[] in_edges_1 = network_lg.getAdjacentEdgeIndicesArray(
						nodes_lg[i], false, true, false);
				int[] in_edges_2 = network_sm.getAdjacentEdgeIndicesArray(
						nodes_sm[j], false, true, false);

				int toNode_index_1, toNode_index_2;
				// matching against the larger set of edges
				int[] in_edges_lg, in_edges_sm;
				CyNetwork network_edge_lg, network_edge_sm;
				Map<Integer, Integer> in_reverse_map_lg, in_reverse_map_sm;
				int[][][] normalizedConnectivityMatrixs_edge_lg, normalizedConnectivityMatrixs_edge_sm;
				if (in_edges_1.length > in_edges_2.length) {
					in_edges_lg = in_edges_1;
					in_edges_sm = in_edges_2;
					in_reverse_map_lg = reverse_map_lg;
					in_reverse_map_sm = reverse_map_sm;

					toNode_index_1 = reverse_map_lg.get(nodes_lg[i]);
					toNode_index_2 = reverse_map_sm.get(nodes_sm[j]);

					network_edge_lg = network_lg;
					network_edge_sm = network_sm;

					normalizedConnectivityMatrixs_edge_lg = connectivityMatrixs_1;
					normalizedConnectivityMatrixs_edge_sm = connectivityMatrixs_2;
				} else {
					in_edges_lg = in_edges_2;
					in_edges_sm = in_edges_1;
					in_reverse_map_lg = reverse_map_sm;
					in_reverse_map_sm = reverse_map_lg;

					toNode_index_1 = reverse_map_sm.get(nodes_sm[j]);
					toNode_index_2 = reverse_map_lg.get(nodes_lg[i]);

					network_edge_lg = network_sm;
					network_edge_sm = network_lg;

					normalizedConnectivityMatrixs_edge_lg = connectivityMatrixs_2;
					normalizedConnectivityMatrixs_edge_sm = connectivityMatrixs_1;
				}

				double[] in_bestMatchingEdgeSimilarity = new double[in_edges_lg.length];
				for (int k = 0; k < in_edges_lg.length; k++) {
					if (k >= in_edges_sm.length)
						in_bestMatchingEdgeSimilarity[k] = 0;
					else
						for (int l = 0; l < in_edges_sm.length; l++) {
							int fromNode_1 = network_edge_lg
									.getEdgeSourceIndex(in_edges_lg[k]);
							int fromNode_2 = network_edge_sm
									.getEdgeSourceIndex(in_edges_sm[l]);

							int tmp_fromNode_index_1 = in_reverse_map_lg
									.get(fromNode_1);
							int tmp_fromNode_index_2 = in_reverse_map_sm
									.get(fromNode_2);

							// compare connectivity of
							// node<fromNode_index_1,toNode_index_1> and
							// node<fromNode_index_2,toNode_index_2>
							double comparedSignature = 0;
							for (int v = 0; v < Vmax; v++) {
								double diff = normalizedConnectivityMatrixs_edge_lg[v][tmp_fromNode_index_1][toNode_index_1]
										- normalizedConnectivityMatrixs_edge_sm[v][tmp_fromNode_index_2][toNode_index_2];
								comparedSignature += 1.0 / (1.0 + Math
										.abs(diff));
							}

							comparedSignature /= Vmax;

							// no need to compare connectivity of
							// node<toNode_index_1,toNode_index_1>

							// compare edge properties
							CyAttributes cyEdgeAttributes = Cytoscape
									.getEdgeAttributes();
							String[] edge_attr_name = cyEdgeAttributes
									.getAttributeNames();

							double similarity_edge = 0;
							for (String name : edge_attr_name) {
								Object obj_attr_1 = cyEdgeAttributes
										.getAttribute(
												network_edge_lg.getEdge(
														in_edges_lg[k])
														.getIdentifier(), name);
								Object obj_attr_2 = cyEdgeAttributes
										.getAttribute(
												network_edge_sm.getEdge(
														in_edges_sm[l])
														.getIdentifier(), name);
								if (obj_attr_1 == null && obj_attr_2 == null)
									similarity_edge++;
								else if (obj_attr_1 == null
										|| obj_attr_2 == null)
									continue;
								else {
									int diff = obj_attr_1.toString().compareTo(
											obj_attr_2.toString());
									similarity_edge += 1.0 / (1.0 + Math
											.abs(diff));
								}
								// else if (obj_attr_1.toString().equals(
								// obj_attr_2.toString()))
								// similarity_edge++;
							}
							similarity_edge /= edge_attr_name.length;

							// compare node properties between fromNode_1 and
							// fromNode_2
							CyAttributes cyNodeAttributes = Cytoscape
									.getNodeAttributes();
							String[] node_attr_name = cyNodeAttributes
									.getAttributeNames();
							double similarity_node = 0;

							for (String name : node_attr_name) {
								Object obj_attr_1 = cyNodeAttributes
										.getAttribute(network_edge_lg.getNode(
												fromNode_1).getIdentifier(),
												name);
								Object obj_attr_2 = cyNodeAttributes
										.getAttribute(network_edge_sm.getNode(
												fromNode_2).getIdentifier(),
												name);
								if (obj_attr_1 == null && obj_attr_2 == null)
									similarity_node++;
								else if (obj_attr_1 == null
										|| obj_attr_2 == null)
									continue;
								else {
									int diff = obj_attr_1.toString().compareTo(
											obj_attr_2.toString());
									similarity_node += 1.0 / (1.0 + Math
											.abs(diff));
								}
								// else if (obj_attr_1.toString().equals(
								// obj_attr_2.toString()))
								// similarity_node++;
							}
							similarity_node /= node_attr_name.length;

							// combine results using IOP (Independent Opinion
							// Pole)
							double similarity = comparedSignature
									* similarity_edge * similarity_node;

							// Save comparison of best matching edges and
							// adjacent
							// nodes
							if (in_bestMatchingEdgeSimilarity[k] < similarity)
								in_bestMatchingEdgeSimilarity[k] = similarity;
						}
				}

				// compare outgoing edges of current nodes
				int[] out_edges_1 = network_lg.getAdjacentEdgeIndicesArray(
						nodes_lg[i], false, false, true);
				int[] out_edges_2 = network_sm.getAdjacentEdgeIndicesArray(
						nodes_sm[j], false, false, true);

				// matching against the larger set of edges
				int fromNode_index_1, fromNode_index_2;
				int[] out_edges_lg, out_edges_sm;
				Map<Integer, Integer> out_reverse_map_lg, out_reverse_map_sm;
				if (out_edges_1.length > out_edges_2.length) {
					out_edges_lg = out_edges_1;
					out_edges_sm = out_edges_2;
					out_reverse_map_lg = reverse_map_lg;
					out_reverse_map_sm = reverse_map_sm;

					network_edge_lg = network_lg;
					network_edge_sm = network_sm;

					fromNode_index_1 = reverse_map_lg.get(nodes_lg[i]);
					fromNode_index_2 = reverse_map_sm.get(nodes_sm[j]);

					normalizedConnectivityMatrixs_edge_lg = connectivityMatrixs_1;
					normalizedConnectivityMatrixs_edge_sm = connectivityMatrixs_2;
				} else {
					out_edges_lg = out_edges_2;
					out_edges_sm = out_edges_1;
					out_reverse_map_lg = reverse_map_sm;
					out_reverse_map_sm = reverse_map_lg;

					network_edge_lg = network_sm;
					network_edge_sm = network_lg;

					fromNode_index_1 = reverse_map_sm.get(nodes_sm[j]);
					fromNode_index_2 = reverse_map_lg.get(nodes_lg[i]);

					normalizedConnectivityMatrixs_edge_lg = connectivityMatrixs_2;
					normalizedConnectivityMatrixs_edge_sm = connectivityMatrixs_1;
				}

				double[] out_bestMatchingEdgeSimilarity = new double[out_edges_lg.length];
				for (int k = 0; k < out_edges_lg.length; k++) {
					if (k >= out_edges_sm.length)
						out_bestMatchingEdgeSimilarity[k] = 0;
					else
						for (int l = 0; l < out_edges_sm.length; l++) {
							int toNode_1 = network_edge_lg
									.getEdgeTargetIndex(out_edges_lg[k]);
							int toNode_2 = network_edge_sm
									.getEdgeTargetIndex(out_edges_sm[l]);

							int tmp_toNode_index_1 = out_reverse_map_lg
									.get(toNode_1);
							int tmp_toNode_index_2 = out_reverse_map_sm
									.get(toNode_2);

							// compare connectivity of
							// node<fromNode_index_1,toNode_index_1> and
							// node<fromNode_index_2,toNode_index_2>
							double comparedSignature = 0;
							for (int v = 0; v < Vmax; v++) {
								double diff = normalizedConnectivityMatrixs_edge_lg[v][fromNode_index_1][tmp_toNode_index_1]
										- normalizedConnectivityMatrixs_edge_sm[v][fromNode_index_2][tmp_toNode_index_2];
								comparedSignature += 1.0 / (1.0 + Math
										.abs(diff));

								// System.out
								// .println("normalizedConnectivityMatrixs_edge_lg[v][fromNode_index_1][tmp_toNode_index_1]:"
								// +
								// normalizedConnectivityMatrixs_edge_lg[v][fromNode_index_1][tmp_toNode_index_1]);
								// System.out
								// .println("normalizedConnectivityMatrixs_edge_sm[v][fromNode_index_2][tmp_toNode_index_2]"
								// +
								// normalizedConnectivityMatrixs_edge_sm[v][fromNode_index_2][tmp_toNode_index_2]);
								// System.out.println("diff:" + diff);
							}

							comparedSignature /= Vmax;
							// System.out.println("Vmax:" + Vmax);
							// System.out.println("comparedSignature:"
							// + comparedSignature);

							// no need to compare connectivity of
							// node<toNode_index_1,toNode_index_1>

							// compare edge properties
							CyAttributes cyEdgeAttributes = Cytoscape
									.getEdgeAttributes();
							String[] edge_attr_name = cyEdgeAttributes
									.getAttributeNames();

							double similarity_edge = 0;
							for (String name : edge_attr_name) {
								Object obj_attr_1 = cyEdgeAttributes
										.getAttribute(network_edge_lg.getEdge(
												out_edges_lg[k])
												.getIdentifier(), name);
								Object obj_attr_2 = cyEdgeAttributes
										.getAttribute(network_edge_sm.getEdge(
												out_edges_sm[l])
												.getIdentifier(), name);

								if (obj_attr_1 == null && obj_attr_2 == null)
									similarity_edge++;
								else if (obj_attr_1 == null
										|| obj_attr_2 == null)
									continue;
								else {
									int diff = obj_attr_1.toString().compareTo(
											obj_attr_2.toString());
									similarity_edge += 1.0 / (1.0 + Math
											.abs(diff));
								}
								// else if (obj_attr_1.toString().equals(
								// obj_attr_2.toString()))
								// similarity_edge++;
							}
							similarity_edge /= edge_attr_name.length;

							// compare node properties between fromNode_1 and
							// fromNode_2
							CyAttributes cyNodeAttributes = Cytoscape
									.getNodeAttributes();
							String[] node_attr_name = cyNodeAttributes
									.getAttributeNames();
							double similarity_node = 0;

							for (String name : node_attr_name) {
								Object obj_attr_1 = cyNodeAttributes
										.getAttribute(network_edge_lg.getNode(
												toNode_1).getIdentifier(), name);
								Object obj_attr_2 = cyNodeAttributes
										.getAttribute(network_edge_sm.getNode(
												toNode_2).getIdentifier(), name);

								if (obj_attr_1 == null && obj_attr_2 == null)
									similarity_node++;
								else if (obj_attr_1 == null
										|| obj_attr_2 == null)
									continue;
								else {
									int diff = obj_attr_1.toString().compareTo(
											obj_attr_2.toString());
									similarity_node += 1.0 / (1.0 + Math
											.abs(diff));
								}
								// else if (obj_attr_1.toString().equals(
								// obj_attr_2.toString()))
								// similarity_node++;
							}
							similarity_node /= node_attr_name.length;

							// combine results using IOP (Independent Opinion
							// Pole)

							double similarity = comparedSignature
									* similarity_edge * similarity_node;

							// Save comparison of best matching edges and
							// adjacent
							// nodes
							if (out_bestMatchingEdgeSimilarity[k] < similarity)
								out_bestMatchingEdgeSimilarity[k] = similarity;
						}
				}

				/* Compare current nodes */
				/* No need to Compare connectivity */

				/* Compare node properties */
				CyAttributes cyNodeAttributes = Cytoscape.getNodeAttributes();
				String[] node_attr_name = cyNodeAttributes.getAttributeNames();
				double similarity_node = 0;

				for (String name : node_attr_name) {
					Object obj_attr_1 = cyNodeAttributes.getAttribute(
							network_lg.getNode(nodes_lg[i]).getIdentifier(),
							name);
					Object obj_attr_2 = cyNodeAttributes.getAttribute(
							network_sm.getNode(nodes_sm[j]).getIdentifier(),
							name);

					if (obj_attr_1 == null && obj_attr_2 == null)
						similarity_node++;
					else if (obj_attr_1 == null || obj_attr_2 == null)
						continue;
					else {
						int diff = obj_attr_1.toString().compareTo(
								obj_attr_2.toString());
						similarity_node += 1.0 / (1.0 + Math.abs(diff));
					}
					// else if (obj_attr_1.toString()
					// .equals(obj_attr_2.toString()))
					// similarity_node++;
				}
				similarity_node /= node_attr_name.length;

				/*
				 * Find similarity of current nodes Combine (3a) (2a) and (2b)
				 * to form attendance rating, using TE
				 */
				similarity_node = 1 - similarity_node;
				for (int k = 0; k < in_bestMatchingEdgeSimilarity.length; k++) {
					similarity_node *= Math.pow(
							(1 - in_bestMatchingEdgeSimilarity[k]), 10);
				}

				for (int k = 0; k < out_bestMatchingEdgeSimilarity.length; k++) {
					similarity_node *= Math.pow(
							(1 - out_bestMatchingEdgeSimilarity[k]), 10);
				}

				attendanceRating[i][j] = 1 - similarity_node;

				/*
				 * Find similarity of current nodes Combine (3a) (2a) and (2b)
				 * to form attendance rating, using a weighted linear
				 * combination of the individual probability forecasts, which is
				 * often referred to as a linear opinion pool
				 */
				// double neighborhood_similarity = 0;
				// for (int k = 0; k < in_bestMatchingEdgeSimilarity.length;
				// k++) {
				// neighborhood_similarity += in_bestMatchingEdgeSimilarity[k]
				// / in_bestMatchingEdgeSimilarity.length;
				// }
				//
				// for (int k = 0; k < out_bestMatchingEdgeSimilarity.length;
				// k++) {
				// neighborhood_similarity += out_bestMatchingEdgeSimilarity[k]
				// / out_bestMatchingEdgeSimilarity.length;
				// }
				//
				// double alpha = 0.5, beta = 0.5;
				// attendanceRating[i][j] = alpha * similarity_node + beta
				// * neighborhood_similarity;
			}
		}

		/*
		 * Form matching subgraphs 12 5) Find peaks of attendance ratings to de
		 * ne mapping from all n to n ik 12 12
		 * 
		 * 6) Form subgraphs g and g using node pairs n and n with attendance
		 * ratings above threshold T ik 1 1212
		 * 
		 * 7) Use node-to-node mapping to reorder nodes in g such that n maps to
		 * n1, n maps to n , etc
		 */

		/*
		 * Set the sub-graph number
		 */
		CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();
		for (int node_1 : nodes_lg) {
			cyNodeAttrs.setAttribute(
					network_lg.getNode(node_1).getIdentifier(),
					"sub-graph-match", 1);
		}

		for (int node_2 : nodes_sm) {
			cyNodeAttrs.setAttribute(
					network_sm.getNode(node_2).getIdentifier(),
					"sub-graph-match", 2);
		}

		// keep track of already matched nodes
		Set<Integer> total_lg_matched_nodes = new HashSet<Integer>();
		Set<Integer> total_sm_matched_nodes = new HashSet<Integer>();
		int subgraphIndex = 3;

		while (true) {
			// find the peak attendance node's pair
			double peak = 0;
			int index_1 = 0, index_2 = 0;
			for (int i = 0; i < attendanceRating.length; i++) {
				if (!total_lg_matched_nodes.contains(nodes_lg[i]))
					for (int j = 0; j < attendanceRating[i].length; j++) {
						if (!total_sm_matched_nodes.contains(nodes_sm[j])
								&& attendanceRating[i][j] > peak) {
							peak = attendanceRating[i][j];
							index_1 = i;
							index_2 = j;
						}
					}
			}

			System.out.println("peak attendance:" + peak);
			Map<Integer, Integer> current_matched_nodes_pair = new HashMap<Integer, Integer>();
			if (peak > THRESHOLD) {
				current_matched_nodes_pair.put(nodes_lg[index_1],
						nodes_sm[index_2]);
				total_lg_matched_nodes.add(nodes_lg[index_1]);
				total_sm_matched_nodes.add(nodes_sm[index_2]);
			} else
				break;

			// go through all the neighbors of each node, extend the subgraph
			// with
			// the largest attendance
			while (true) {
				Iterator<Integer> itr = current_matched_nodes_pair.keySet()
						.iterator();

				double best_attendance = 0;
				int best_extension_neighbor_1 = 0, best_extension_neighbor_2 = 0;

				while (itr.hasNext()) {
					int node_1 = itr.next();
					int node_2 = current_matched_nodes_pair.get(node_1);

					int[] neighbors_1 = network_lg.neighborsArray(node_1);
					int[] neighbors_2 = network_sm.neighborsArray(node_2);

					for (int neighbor_1 : neighbors_1) {
						if (total_lg_matched_nodes.contains(neighbor_1))
							continue;

						for (int neighbor_2 : neighbors_2) {
							if (total_sm_matched_nodes.contains(neighbor_2))
								continue;

							int neighbor_index_1 = reverse_map_lg
									.get(neighbor_1);
							int neighbor_index_2 = reverse_map_sm
									.get(neighbor_2);
							if (attendanceRating[neighbor_index_1][neighbor_index_2] > best_attendance) {
								best_attendance = attendanceRating[neighbor_index_1][neighbor_index_2];
								best_extension_neighbor_1 = neighbor_1;
								best_extension_neighbor_2 = neighbor_2;
							}
						}
					}

				}

				if (best_attendance > THRESHOLD) {
					current_matched_nodes_pair.put(best_extension_neighbor_1,
							best_extension_neighbor_2);
					total_lg_matched_nodes.add(best_extension_neighbor_1);
					total_sm_matched_nodes.add(best_extension_neighbor_2);
				} else
					break;
			}

			Iterator<Integer> itr = current_matched_nodes_pair.keySet()
					.iterator();
			int index = 3;
			while (itr.hasNext()) {
				int node_1 = itr.next();
				int node_2 = current_matched_nodes_pair.get(node_1);

				System.out.println("matched:" + node_1 + "->" + node_2);
				cyNodeAttrs.setAttribute(network_lg.getNode(node_1)
						.getIdentifier(), "sub-graph-match", subgraphIndex);
				cyNodeAttrs.setAttribute(network_lg.getNode(node_1)
						.getIdentifier(), "matching-graph-id", network_sm
						.getIdentifier());
				cyNodeAttrs.setAttribute(network_lg.getNode(node_1)
						.getIdentifier(), "matching-node-id", node_2);

				cyNodeAttrs.setAttribute(network_sm.getNode(node_2)
						.getIdentifier(), "sub-graph-match", subgraphIndex);
				cyNodeAttrs.setAttribute(network_sm.getNode(node_2)
						.getIdentifier(), "matching-graph-id", network_lg
						.getIdentifier());
				cyNodeAttrs.setAttribute(network_sm.getNode(node_2)
						.getIdentifier(), "matching-node-id", node_1);

				index++;
			}

			subgraphIndex++;
		}

		/*
		 * coloring the sub-graphs with different colors
		 */

		// get the VisualMappingManager and CalculatorCatalog
		VisualMappingManager manager = Cytoscape.getVisualMappingManager();
		CalculatorCatalog catalog = manager.getCalculatorCatalog();

		// check to see if a visual style with this name already exists
		VisualStyle vs = catalog.getVisualStyle(vsName);
		if (vs == null) {
			// if not, create it and add it to the catalog
			vs = createVisualStyle(network_lg, vsName);
			catalog.addVisualStyle(vs);
		} else {
			catalog.removeVisualStyle(vs.getName());
			vs = createVisualStyle(network_sm, vsName);
			catalog.addVisualStyle(vs);
		}

		Cytoscape.getNetworkView(network_lg.getIdentifier()).setVisualStyle(
				vs.getName());
		Cytoscape.getNetworkView(network_sm.getIdentifier()).setVisualStyle(
				vs.getName());

		// actually apply the visual style
		manager.setVisualStyle(vs);
		Cytoscape.getNetworkView(network_lg.getIdentifier()).redrawGraph(true,
				true);
		Cytoscape.getNetworkView(network_sm.getIdentifier()).redrawGraph(true,
				true);

		// add comparing attribute view panel
		MouseListener[] ml = Cytoscape.getCurrentNetworkView().getComponent()
				.getMouseListeners();
		for (int i = 0; i < ml.length; i++) {
			System.out.println(ml[i].toString());
			if (ml[i].toString().contains("NodeAttributeViewListener"))
				Cytoscape.getCurrentNetworkView().getComponent()
						.removeMouseListener(ml[i]);
			else if (ml[i].toString().contains(
					"MatchedNodesAttributeViewListener"))
				Cytoscape.getCurrentNetworkView().getComponent()
						.removeMouseListener(ml[i]);
		}

		Cytoscape.getCurrentNetworkView().getComponent().addMouseListener(
				new MatchedNodesAttributeViewListener());
	}

	public static int[][] multiply(int a[][], int b[][]) {
		// Remember RC, Row-Column.
		int aRows = a.length, aColumns = a[0].length, bRows = b.length, bColumns = b[0].length;
		if (aColumns != bRows) {
			throw new IllegalArgumentException("A:Rows: " + aColumns
					+ " did not match B:Columns " + bRows + ".");
		}

		int[][] resultant = new int[aRows][bColumns];
		for (int i = 0; i < aRows; i++) { // aRow
			for (int j = 0; j < bColumns; j++) { // bColumn
				for (int k = 0; k < aColumns; k++) { // aColumn
					resultant[i][j] += a[i][k] * b[k][j];
				}
			}
		}
		return resultant;
	}

	VisualStyle createVisualStyle(CyNetwork network, String vsName) {

		NodeAppearanceCalculator nodeAppCalc = new NodeAppearanceCalculator();
		EdgeAppearanceCalculator edgeAppCalc = new EdgeAppearanceCalculator();
		GlobalAppearanceCalculator globalAppCalc = new GlobalAppearanceCalculator();

		globalAppCalc.setDefaultBackgroundColor(new Color(153, 153, 153));

		// Passthrough Mapping - set node label
		PassThroughMapping pm1 = new PassThroughMapping(new String(),
				"node_label");

		BasicCalculator nlc = new BasicCalculator(
				"Example Node Label Calculator", pm1,
				VisualPropertyType.NODE_LABEL);

		nodeAppCalc.setCalculator(nlc);

		// Discrete Mapping - set node shapes
		DiscreteMapping disMapping = new DiscreteMapping(NodeShape.RECT,
				ObjectMapping.NODE_MAPPING);
		disMapping.setControllingAttributeName("NodeType", network, false);
		disMapping.putMapValue("PROCESS", NodeShape.ROUND_RECT);
		disMapping.putMapValue("ARTIFACT", NodeShape.ELLIPSE);
		disMapping.putMapValue("SUBNETWORK", NodeShape.OCTAGON);
		disMapping.putMapValue("AGENT", NodeShape.OCTAGON);

		Calculator shapeCalculator = new BasicCalculator(
				"Example Node Shape Calculator", disMapping,
				VisualPropertyType.NODE_SHAPE);
		nodeAppCalc.setCalculator(shapeCalculator);

		final Color NODE_COLOR = new Color(0, 0, 0);
		DiscreteMapping nodeColor = new DiscreteMapping(NODE_COLOR,
				"sub-graph-match", ObjectMapping.NODE_MAPPING);

		final Set<Object> attrSet = MappingKeyFactory.getKeySet(nodeColor
				.getControllingAttributeName(), Cytoscape.getNodeAttributes(),
				nodeColor, true);

		final Map valueMap = new HashMap();
		/*
		 * Create rainbow colors
		 */
		final float increment = 1f / ((Number) attrSet.size()).floatValue();

		float hue = 0;

		for (Object key : attrSet) {
			hue = hue + increment;
			valueMap.put(key, new Color(Color.HSBtoRGB(hue, 1f, 1f)));
		}

		nodeColor.putAll(valueMap);

		Calculator nodeColorCalc = new BasicCalculator("NodeColorMapping",
				nodeColor, VisualPropertyType.NODE_FILL_COLOR);

		nodeAppCalc.setCalculator(nodeColorCalc);

		// set edge label
		PassThroughMapping pm_e = new PassThroughMapping(new String(),
				"interaction");

		BasicCalculator edc = new BasicCalculator(
				"Example Edge Label Calculator", pm_e,
				VisualPropertyType.EDGE_LABEL);

		edgeAppCalc.setCalculator(edc);

		// Discrete Mapping - Set edge color
		final Color EDGE_COLOR = new Color(10, 10, 10);

		DiscreteMapping edgeColor = new DiscreteMapping(EDGE_COLOR,
				"interaction", ObjectMapping.EDGE_MAPPING);

		edgeColor.putMapValue("used", new Color(100, 255, 100));
		edgeColor.putMapValue("wasTriggeredBy", Color.YELLOW);
		edgeColor.putMapValue("wasGeneratedBy", new Color(204, 204, 204));
		edgeColor.putMapValue("wasDerivedFrom", new Color(0, 200, 255));
		edgeColor.putMapValue("wasControlledBy", Color.WHITE);

		Calculator edgeColorCalc = new BasicCalculator("EdgeColorMapping",
				edgeColor, VisualPropertyType.EDGE_COLOR);

		edgeAppCalc.setCalculator(edgeColorCalc);

		// Discrete Mapping - Set edge target arrow shape
		DiscreteMapping arrowMapping = new DiscreteMapping(ArrowShape.NONE,
				ObjectMapping.EDGE_MAPPING);
		arrowMapping.setControllingAttributeName("interaction", network, false);
		arrowMapping.putMapValue("wasTriggeredBy", ArrowShape.ARROW);
		arrowMapping.putMapValue("wasGeneratedBy", ArrowShape.CIRCLE);
		arrowMapping.putMapValue("wasDerivedFrom", ArrowShape.CIRCLE);
		arrowMapping.putMapValue("used", ArrowShape.DELTA);
		arrowMapping.putMapValue("wasControlledBy", ArrowShape.DIAMOND);

		Calculator edgeArrowCalculator = new BasicCalculator(
				"Example Edge Arrow Shape Calculator", arrowMapping,
				VisualPropertyType.EDGE_TGTARROW_SHAPE);
		edgeAppCalc.setCalculator(edgeArrowCalculator);

		// Create the visual style
		VisualStyle visualStyle = new VisualStyle(vsName, nodeAppCalc,
				edgeAppCalc, globalAppCalc);

		return visualStyle;
	}

	public static void main(String args[]) {
		int[][] array = new int[2][2];
		int[] a2 = { 2, 2 };
		array[1] = a2;

		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				System.out.println(array[i][j]);
			}
		}
	}
}
