package cytoscape.OPM_visualization.actionListener;

/*
 * This code contains a hard coded appendix of "seaice".
 * */
import giny.model.Node;
import giny.view.NodeView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Reader;
import java.io.StringReader;
import java.util.Iterator;
import java.util.Set;

import javax.swing.JOptionPane;

import org.jdom.input.SAXBuilder;
import org.openprovenance.model.v1_1_a.OpmGraphDocument;

import csplugins.layout.JGraphLayoutWrapper;
import csplugins.layout.algorithms.GroupAttributesLayout;
import csplugins.layout.algorithms.hierarchicalLayout.HierarchicalLayoutAlgorithm;

import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.OPM_visualization.GraphConfigPanel;
import cytoscape.OPM_visualization.OPM_visualization;
import cytoscape.OPM_visualization.query.KarmaAxis2Query;
import cytoscape.OPM_visualization.query.RabbitmqQuery;
import cytoscape.OPM_visualization.util.ConfigurationReader;
import cytoscape.OPM_visualization.util.GraphBuilder;
import cytoscape.data.CyAttributes;
import cytoscape.layout.AbstractLayout;
import cytoscape.view.CyNetworkView;

public class GetAssociatedWorkflowGraph implements ActionListener {
	NodeView nodeView;

	static String filename;
	// static private ConfigurationReader conf_reader;

	// static String serviceURL;
	// static String pathToConfigFile = "/plugins/config/karmaQueryConfig.txt";

	static int method = -1;

	public GetAssociatedWorkflowGraph(NodeView pNodeView) {
		nodeView = pNodeView;
		// conf_reader = ConfigurationReader.getInstance();
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		// new UndoAction().actionPerformed(null);
		try {

			Set<Node> nodes = Cytoscape.getCurrentNetwork().getSelectedNodes();

			AssociateWorkflowGraphLoader al = new AssociateWorkflowGraphLoader(
					nodes);
			Thread t = new Thread(al);
			t.start();

		} catch (Exception e) {
			JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e.toString());
			e.printStackTrace();
		}
	}
}

class AssociateWorkflowGraphLoader implements Runnable {
	Set<Node> nodes;

	public AssociateWorkflowGraphLoader(Set<Node> nodes) {
		this.nodes = nodes;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		Iterator<Node> itr_nodes = nodes.iterator();

		SAXBuilder builder = new SAXBuilder();

		try {
			while (itr_nodes.hasNext()) {
				Node temp = itr_nodes.next();

				CyAttributes formerCyNodeAttrs = Cytoscape.getNodeAttributes();
				CyAttributes formerCyEdgeAttrs = Cytoscape.getEdgeAttributes();
				String nodeType = formerCyNodeAttrs.getStringAttribute(temp
						.getIdentifier(), "NodeType");
				if (nodeType.contains("ARTIFACT")) {

					int[] out_edges = Cytoscape.getCurrentNetwork()
							.getRootGraph().getAdjacentEdgeIndicesArray(
									temp.getRootGraphIndex(), false, false,
									true);

					String workflow_id = null;
					for (int out_edge : out_edges) {
						if (formerCyEdgeAttrs.getStringAttribute(
								Cytoscape.getCurrentNetwork().getRootGraph()
										.getEdge(out_edge).getIdentifier(),
								"interaction").equalsIgnoreCase(
								"wasGeneratedBy")) {
							workflow_id = formerCyNodeAttrs.getStringAttribute(
									Cytoscape.getCurrentNetwork()
											.getRootGraph().getEdge(out_edge)
											.getTarget().getIdentifier(),
									"process-workflowID");
							break;
						}
					}

					if (workflow_id == null)
						break;

					// String workflow_uri = artifact_uri.substring(0,
					// artifact_uri.lastIndexOf("/")+1)+"seaice";

					// Cytoscape.createNewSession();
					CyNetwork network = Cytoscape.createNetwork(workflow_id,
							true);
					CyNetworkView new_networkView = Cytoscape
							.getNetworkView(network.getIdentifier());
					CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();
					CyAttributes cyEdgeAttrs = Cytoscape.getEdgeAttributes();

					String graph_response = null;

					KarmaAxis2Query axis2Client = null;
					RabbitmqQuery rqClient = null;

					ConfigurationReader conf_reader = ConfigurationReader
							.getInstance();

					/*
					 * use the method configured in configuration panel Or try
					 * to use the Axis2 by default
					 */
					if (GraphConfigPanel.useRabbitmq) {
						rqClient = new RabbitmqQuery();
						if (rqClient != null) {
							graph_response = rqClient
									.getWorkflowGraphWithAnnotation(workflow_id);
						}
					} else {
						axis2Client = new KarmaAxis2Query(
								conf_reader.serviceURL);
						if (axis2Client != null) {
							graph_response = axis2Client
									.getWorkflowGraphWithAnnotation(workflow_id);
						} else {
							return;
						}
					}

					// axis2Tester = new KarmaAxis2Query(ConfigurationReader
					// .getInstance().serviceURL);

					// System.out.println("#####################\n"
					// + graph_response);

					String graph;
					/*
					 * Re-organize the result xml into a opm xml
					 */
					int start = graph_response.lastIndexOf("<v1:opmGraph");
					int end = graph_response.lastIndexOf("<");

					if (start == -1 || end == -1) {
						graph = graph_response;

						JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
								"An invalid OPM graph returned");
					} else
						graph = graph_response.substring(start, end);

					Reader reader = new StringReader(graph);

					OpmGraphDocument doc = OpmGraphDocument.Factory
							.parse(reader);

					GraphBuilder gbuilder = new GraphBuilder();
					gbuilder.build(doc, network, cyNodeAttrs, cyEdgeAttrs);

					// GroupAttributesLayout gal = new GroupAttributesLayout();
					// gal.setLayoutAttribute("NodeType");
					// HierarchicalLayoutAlgorithm hl = new
					// HierarchicalLayoutAlgorithm();
					// new_networkView.applyLayout(hl);

					GroupAttributesLayout gal = new GroupAttributesLayout();
					gal.setLayoutAttribute("NodeType");
					new_networkView.applyLayout(gal);

					AbstractLayout rtl = new JGraphLayoutWrapper(
							JGraphLayoutWrapper.RADIAL_TREE);
					
					rtl.doLayout(new_networkView);
					// new_networkView.applyLayout(rtl,node_ids,edges);

					// MyNodeContextMenuListener l = new
					// MyNodeContextMenuListener();
					// new_networkView.addNodeContextMenuListener(l);

					OPM_visualization.registerListenerForCurrentView();
				}

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e.toString());
		}
		Cytoscape.getCurrentNetworkView().redrawGraph(true, true);
	}
}
