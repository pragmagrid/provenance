package cytoscape.OPM_visualization;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.tree.TreePath;

import cytoscape.CyNetwork;
import cytoscape.Cytoscape;
import cytoscape.OPM_visualization.actionListener.ComparingTwoNetworkAction;
import cytoscape.OPM_visualization.actionListener.GraphMatchingAction;
import cytoscape.OPM_visualization.actionListener.WiMAX_ORBIT_Action;
import cytoscape.OPM_visualization.actionListener.WiMaxDosVisAction;
import cytoscape.actions.ApplyVisualStyleAction;
import cytoscape.actions.CreateNetworkViewAction;
import cytoscape.logger.CyLogger;
import cytoscape.util.CyNetworkNaming;
import cytoscape.util.swing.JTreeTable;
import cytoscape.view.CyNetworkView;

public class UpdatePopupListenerOnNetworkPanel {
	final static String COMPARING_TWO_NETWORK = "Network comparison";
	final static String COMPARING_TWO_NETWORK_ext = "DCA comparison";
	final static String CREATE_WIMAX_DOS_VIS = "Create WiMAX DoS Vis";
	final static String CREATE_WIMAX_ORBIT_VIS = "Create WiMAX ORBIT Vis";

	JTreeTable treeTable = Cytoscape.getDesktop().getNetworkPanel()
			.getTreeTable();

	private JPopupMenu popup;
	private PopupActionListener popupActionListener;

	private JMenuItem createViewItem;
	private JMenuItem destroyViewItem;
	private JMenuItem destroyNetworkItem;
	private JMenuItem editNetworkTitle;
	private JMenuItem applyVisualStyleMenu;

	private JMenuItem comparingTwoNetwork;
	private JMenuItem DCA_comparing;
	private JMenuItem create_WiMAX_DoS_vis;
	private JMenuItem create_WiMAX_ORBIT_vis;

	public void update() {
		MouseListener[] mls = treeTable.getMouseListeners();

		for (MouseListener ml : mls) {
			// System.out.println(ml.toString());
			if (ml.toString().contains("PopupListener"))
				treeTable.removeMouseListener(ml);
		}

		// this mouse listener listens for the right-click event and will show
		// the pop-up
		// window when that occurrs
		treeTable.addMouseListener(new PopupListener());

		// create and populate the popup window
		popup = new JPopupMenu();
		editNetworkTitle = new JMenuItem(PopupActionListener.EDIT_TITLE);
		createViewItem = new JMenuItem(PopupActionListener.CREATE_VIEW);
		destroyViewItem = new JMenuItem(PopupActionListener.DESTROY_VIEW);
		destroyNetworkItem = new JMenuItem(PopupActionListener.DESTROY_NETWORK);
		applyVisualStyleMenu = new JMenu(PopupActionListener.APPLY_VISUAL_STYLE);

		comparingTwoNetwork = new JMenuItem(
				UpdatePopupListenerOnNetworkPanel.COMPARING_TWO_NETWORK);
		DCA_comparing = new JMenuItem(
				UpdatePopupListenerOnNetworkPanel.COMPARING_TWO_NETWORK_ext);
		create_WiMAX_DoS_vis = new JMenuItem(
				UpdatePopupListenerOnNetworkPanel.CREATE_WIMAX_DOS_VIS);
		create_WiMAX_ORBIT_vis = new JMenuItem(
				UpdatePopupListenerOnNetworkPanel.CREATE_WIMAX_ORBIT_VIS);

		// action listener which performs the tasks associated with the popup
		// listener
		popupActionListener = new PopupActionListener();
		editNetworkTitle.addActionListener(popupActionListener);
		createViewItem.addActionListener(popupActionListener);
		destroyViewItem.addActionListener(popupActionListener);
		destroyNetworkItem.addActionListener(popupActionListener);
		applyVisualStyleMenu.addActionListener(popupActionListener);
		comparingTwoNetwork.addActionListener(new ComparingTwoNetworkAction());
		DCA_comparing.addActionListener(new GraphMatchingAction());
		create_WiMAX_DoS_vis.addActionListener(new WiMaxDosVisAction());
		create_WiMAX_ORBIT_vis.addActionListener(new WiMAX_ORBIT_Action());

		popup.add(editNetworkTitle);
		popup.add(createViewItem);
		popup.add(destroyViewItem);
		popup.add(destroyNetworkItem);
		popup.addSeparator();
		popup.add(applyVisualStyleMenu);
		popup.add(create_WiMAX_DoS_vis);
		popup.add(create_WiMAX_ORBIT_vis);
		popup.addSeparator();
		popup.add(comparingTwoNetwork);
		popup.add(DCA_comparing);

		final Set<String> vsNames = new TreeSet<String>(Cytoscape
				.getVisualMappingManager().getCalculatorCatalog()
				.getVisualStyleNames());
		for (String name : vsNames) {
			final JMenuItem styleMenu = new JMenuItem(name);
			styleMenu.setAction(new ApplyVisualStyleAction(name));
			applyVisualStyleMenu.add(styleMenu);
		}
	}

	/**
	 * This class listens to mouse events from the TreeTable, if the mouse event
	 * is one that is canonically associated with a popup menu (ie, a right
	 * click) it will pop up the menu with option for destroying view, creating
	 * view, and destroying network (this is platform specific apparently)
	 */
	protected class PopupListener extends MouseAdapter {
		/**
		 * Don't know why you need both of these, but this is how they did it in
		 * the example
		 */
		public void mousePressed(MouseEvent e) {
			maybeShowPopup(e);
		}

		/*
		 * On windows, popup is triggered by this method, not the above one
		 */
		public void mouseReleased(MouseEvent e) {
			maybeShowPopup(e);
		}

		/**
		 * if the mouse press is of the correct type, this function will maybe
		 * display the popup
		 */
		private void maybeShowPopup(MouseEvent e) {
			// check for the popup type
			if (e.isPopupTrigger()) {
				// get the row where the mouse-click originated
				// final int[] selected = treeTable.getSelectedRows();

				final List<CyNetwork> selected = Cytoscape
						.getSelectedNetworks();

				if (selected != null && selected.size() != 0) {
					boolean enableViewRelatedMenu = false;
					final int selectedItemCount = selected.size();
					CyNetwork cyNetwork = null;
					final JTree tree = treeTable.getTree();
					for (int i = 0; i < selectedItemCount; i++) {

						// final TreePath treePath = tree
						// .getPathForRow(selected[i]);
						// final String networkID = treePath
						// .getLastPathComponent().toString();
						final String networkID = selected.get(i)
								.getIdentifier();
						// (String) ((NetworkTreeNode)
						// treePath.getLastPathComponent())
						// .getNetworkID();
						// System.out.println(treePath.getLastPathComponent()
						// .toString());

						cyNetwork = Cytoscape.getNetwork(networkID);
						if (Cytoscape.viewExists(networkID)) {
							enableViewRelatedMenu = true;
						}
					}

					// Edit title command will be enabled only when ONE network
					// is selected.
					if (selectedItemCount == 1) {
						editNetworkTitle.setEnabled(true);
						popupActionListener.setActiveNetwork(cyNetwork);
						comparingTwoNetwork.setEnabled(false);
						DCA_comparing.setEnabled(false);
					} else {
						editNetworkTitle.setEnabled(false);

						if (selectedItemCount == 2) {
							comparingTwoNetwork.setEnabled(true);
							DCA_comparing.setEnabled(true);
						} else {
							comparingTwoNetwork.setEnabled(false);
							DCA_comparing.setEnabled(false);
						}
					}

					if (enableViewRelatedMenu) {
						// At least one selected network has a view.
						createViewItem.setEnabled(true);
						destroyViewItem.setEnabled(true);
						applyVisualStyleMenu.setEnabled(true);
						create_WiMAX_DoS_vis.setEnabled(true);
						create_WiMAX_ORBIT_vis.setEnabled(true);
					} else {
						// None of the selected networks has view.
						createViewItem.setEnabled(true);
						destroyViewItem.setEnabled(false);
						applyVisualStyleMenu.setEnabled(false);
						create_WiMAX_DoS_vis.setEnabled(false);
						create_WiMAX_ORBIT_vis.setEnabled(true);
					}

					popup.show(e.getComponent(), e.getX(), e.getY());
				}
			}
		}
	}
}

/**
 * This class listens for actions from the popup menu, it is responsible for
 * performing actions related to destroying and creating views, and destroying
 * the network.
 */
class PopupActionListener implements ActionListener {
	/**
	 * Constants for JMenuItem labels
	 */
	public static final String DESTROY_VIEW = "Destroy View";

	/**
	 *
	 */
	public static final String CREATE_VIEW = "Create View";

	/**
	 *
	 */
	public static final String DESTROY_NETWORK = "Destroy Network";

	/**
	 *
	 */
	public static final String EDIT_TITLE = "Edit Network Title";

	public static final String APPLY_VISUAL_STYLE = "Apply Visual Style";

	/**
	 * This is the network which originated the mouse-click event (more
	 * appropriately, the network associated with the ID associated with the row
	 * associated with the JTable that originated the popup event
	 */
	protected CyNetwork cyNetwork;

	/**
	 * Based on the action event, destroy or create a view, or destroy a network
	 */
	public void actionPerformed(ActionEvent ae) {
		final String label = ((JMenuItem) ae.getSource()).getText();

		if (DESTROY_VIEW.equals(label)) {
			final List<CyNetwork> selected = Cytoscape.getSelectedNetworks();
			for (final CyNetwork network : selected) {
				final CyNetworkView targetView = Cytoscape
						.getNetworkView(network.getIdentifier());
				if (targetView != Cytoscape.getNullNetworkView()) {
					Cytoscape.destroyNetworkView(targetView);
				}
			}
		} else if (CREATE_VIEW.equals(label)) {
			final List<CyNetwork> selected = Cytoscape.getSelectedNetworks();

			for (CyNetwork network : selected) {
				if (!Cytoscape.viewExists(network.getIdentifier()))
					CreateNetworkViewAction
							.createViewFromCurrentNetwork(network);
			}
		} else if (DESTROY_NETWORK.equals(label)) {
			final List<CyNetwork> selected = Cytoscape.getSelectedNetworks();
			for (CyNetwork network : selected)
				Cytoscape.destroyNetwork(network);
		} else if (EDIT_TITLE.equals(label)) {
			CyNetworkNaming.editNetworkTitle(cyNetwork);
			Cytoscape.getDesktop().getNetworkPanel().updateTitle(cyNetwork);
		} else if (UpdatePopupListenerOnNetworkPanel.COMPARING_TWO_NETWORK
				.equals(label)) {
			JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
					"Comparing networks");

		} else if (UpdatePopupListenerOnNetworkPanel.COMPARING_TWO_NETWORK_ext
				.equals(label)) {
			JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
					"DCA comparison");

		} else if (UpdatePopupListenerOnNetworkPanel.CREATE_WIMAX_DOS_VIS
				.equals(label)) {
			JOptionPane.showMessageDialog(Cytoscape.getDesktop(),
					"create WiMaxDoS Vis");

		} else {
			CyLogger.getLogger().warn("Unexpected network panel popup option");
		}
	}

	/**
	 * Right before the popup menu is displayed, this function is called so we
	 * know which network the user is clicking on to call for the popup menu
	 */
	public void setActiveNetwork(final CyNetwork cyNetwork) {
		this.cyNetwork = cyNetwork;
	}
}
