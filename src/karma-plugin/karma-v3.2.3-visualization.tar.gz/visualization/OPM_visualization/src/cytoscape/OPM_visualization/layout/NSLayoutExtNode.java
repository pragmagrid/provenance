package cytoscape.OPM_visualization.layout;

import giny.model.Node;
import giny.view.NodeView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import cytoscape.Cytoscape;
import cytoscape.data.CyAttributes;
import cytoscape.layout.AbstractLayout;

public class NSLayoutExtNode extends AbstractLayout {
	static final double aug_scale = 10;

	@Override
	public void construct() {
		// TODO Auto-generated method stub
		CyAttributes cyNodeAttrs = Cytoscape.getNodeAttributes();

		Iterator<NodeView> iter = networkView.getNodeViewsIterator();

		Map<Integer, Boolean> isTravelled = new HashMap<Integer, Boolean>();
		Node node = null;
		NodeView nodeView = null;

		// layout the mobile nodes
		while (iter.hasNext()) {
			if (canceled)
				return;

			nodeView = iter.next();
			node = nodeView.getNode();

			String x_coor = cyNodeAttrs.getStringAttribute(
					node.getIdentifier(), "X_");
			String y_coor = cyNodeAttrs.getStringAttribute(
					node.getIdentifier(), "Y_");
			String activeTime = cyNodeAttrs.getStringAttribute(node
					.getIdentifier(), "active time");
			String num_packets_sent_interval = cyNodeAttrs.getStringAttribute(
					node.getIdentifier(), "num_packets_sent_interval");
			String num_packets_drop_interval = cyNodeAttrs.getStringAttribute(
					node.getIdentifier(), "num_packets_drop_interval");
			String avg_travel_time_interval = cyNodeAttrs.getStringAttribute(
					node.getIdentifier(), "avg_travel_time_interval");
			String avg_queuing_time_interval = cyNodeAttrs.getStringAttribute(
					node.getIdentifier(), "avg_queuing_time_interval");

			// only travel through node that has X_ and Y_
			if (x_coor != null && y_coor != null) {
				double x = Double.parseDouble(x_coor);
				double y = Double.parseDouble(y_coor);

				nodeView.setXPosition(x * aug_scale);
				nodeView.setYPosition(y * aug_scale);

				isTravelled.put(new Integer(node.getRootGraphIndex()), true);

				// get the maximum length to align all the lines to the same
				// scale
				int max_length_packets = 0, max_length_time = 0;
				if (num_packets_sent_interval != null
						&& !num_packets_sent_interval.equals("")) {
					int length = num_packets_sent_interval.split(",").length;
					if (max_length_packets < length)
						max_length_packets = length;

				}
				if (num_packets_drop_interval != null
						&& !num_packets_drop_interval.equals("")) {
					int length = num_packets_drop_interval.split(",").length;
					if (max_length_packets < length)
						max_length_packets = length;

				}

				if (avg_travel_time_interval != null
						&& !avg_travel_time_interval.equals("")) {
					int length = avg_travel_time_interval.split(",").length;
					if (max_length_time < length)
						max_length_time = length;
				}
				if (avg_queuing_time_interval != null
						&& !avg_queuing_time_interval.equals("")) {
					int length = avg_queuing_time_interval.split(",").length;
					if (max_length_time < length)
						max_length_time = length;
				}

				if (max_length_packets != 0) {
					// use google chart request format
					String prefix_packet_send_drop = "http://chart.apis.google.com/chart?cht=lxy&chxt=x,y&chs=500x500"
							+ "&chco=FF0000,00FF00&chma=10,10,10,10&chds=a&chtt=packet%20send%26drop";
					String x_axis_1 = null, x_axis_2 = null;
					String y_axis_1 = null, y_axis_2 = null;
					if (num_packets_sent_interval != null
							&& !num_packets_sent_interval.equals("")) {
						String[] num_packets_sent_interval_array = num_packets_sent_interval
								.split(",");

						StringBuffer sb1 = new StringBuffer();
						StringBuffer sb2 = new StringBuffer();
						for (int i = 0; i < max_length_packets; i += 2) {
							if (i >= num_packets_sent_interval_array.length) {
								sb2.append(",");
								sb2.append("0");
								continue;
							}

							double time_label = Double
									.parseDouble(num_packets_sent_interval_array[i]);
							time_label = time_label * 5;

							if (i != 0) {
								sb1.append(",");
								sb2.append(",");
							}

							sb1.append(time_label);
							sb2.append(num_packets_sent_interval_array[i + 1]);
						}

						x_axis_1 = sb1.toString();
						y_axis_1 = sb2.toString();
					}

					if (num_packets_drop_interval != null
							&& !num_packets_drop_interval.equals("")) {
						String[] num_packets_drop_interval_array = num_packets_drop_interval
								.split(",");

						StringBuffer sb1 = new StringBuffer();
						StringBuffer sb2 = new StringBuffer();
						for (int i = 0; i < max_length_packets; i += 2) {
							if (i >= num_packets_drop_interval_array.length) {
								sb2.append(",");
								sb2.append("0");
								continue;
							}

							double time_label = Double
									.parseDouble(num_packets_drop_interval_array[i]);
							time_label = time_label * 5;

							if (i != 0) {
								sb1.append(",");
								sb2.append(",");
							}

							sb1.append(time_label);
							sb2.append(num_packets_drop_interval_array[i + 1]);
						}

						x_axis_2 = sb1.toString();
						y_axis_2 = sb2.toString();
					}

					if (x_axis_2 == null) {
						x_axis_2 = x_axis_1;
					} else if (x_axis_1 == null) {
						x_axis_1 = x_axis_2;
					} else if (x_axis_1.length() > x_axis_2.length()) {
						x_axis_2 = x_axis_1;
					} else {
						x_axis_1 = x_axis_2;
					}

					if (y_axis_1 == null) {
						StringBuffer sb = new StringBuffer();
						sb.append("0");
						for (int index = 1; index < max_length_packets; index += 2) {
							sb.append(",");
							sb.append("0");
						}
						y_axis_1 = sb.toString();
					}

					if (y_axis_2 == null) {
						StringBuffer sb = new StringBuffer();
						sb.append("0");
						for (int index = 1; index < max_length_packets; index += 2) {
							sb.append(",");
							sb.append("0");
						}
						y_axis_2 = sb.toString();
					}

					cyNodeAttrs.setAttribute(node.getIdentifier(), "graph-url-drop&send",
							prefix_packet_send_drop + "&chd=t:" + x_axis_1
									+ "|" + y_axis_1 + "|" + x_axis_2 + "|"
									+ y_axis_2);
				}
				
				// currently, we only choose either send/drop or travel&queuing
				if (max_length_time != 0) {
					String prefix_packet_queue_transfer = "http://chart.apis.google.com/chart?cht=lxy&chxt=x,y&chs=500x500"
							+ "&chco=FF0000,00FF00&chma=10,10,10,10&chds=a&chtt=packet%20queuing%26transfer";
					String x_axis_1 = null, x_axis_2 = null, y_axis_1 = null, y_axis_2 = null;
					if (avg_travel_time_interval != null
							&& !avg_travel_time_interval.equals("")) {
						String[] avg_travel_time_interval_array = avg_travel_time_interval
								.split(",");

						StringBuffer sb1 = new StringBuffer();
						StringBuffer sb2 = new StringBuffer();
						for (int i = 0; i < max_length_time; i += 2) {
							if (i >= avg_travel_time_interval_array.length) {
								sb2.append(",");
								sb2.append("0");
								continue;
							}

							double time_label = Double
									.parseDouble(avg_travel_time_interval_array[i]);
							time_label = time_label * 5;

							if (i != 0) {
								sb1.append(",");
								sb2.append(",");
							}

							sb1.append(time_label);
							sb2.append(avg_travel_time_interval_array[i + 1]);
						}

						x_axis_1 = sb1.toString();
						y_axis_1 = sb2.toString();
					}

					if (avg_queuing_time_interval != null
							&& !avg_queuing_time_interval.equals("")) {
						String[] avg_queuing_time_interval_array = avg_queuing_time_interval
								.split(",");

						StringBuffer sb1 = new StringBuffer();
						StringBuffer sb2 = new StringBuffer();
						for (int i = 0; i < max_length_time; i += 2) {
							if (i >= avg_queuing_time_interval_array.length) {
								sb2.append(",");
								sb2.append("0");
								continue;
							}

							double time_label = Double
									.parseDouble(avg_queuing_time_interval_array[i]);
							time_label = time_label * 5;

							if (i != 0) {
								sb1.append(",");
								sb2.append(",");
							}

							sb1.append(time_label);
							sb2.append(avg_queuing_time_interval_array[i + 1]);

						}

						x_axis_2 = sb1.toString();
						y_axis_2 = sb2.toString();
					}

					if (x_axis_2 == null) {
						x_axis_2 = x_axis_1;
					} else if (x_axis_1 == null) {
						x_axis_1 = x_axis_2;
					} else if (x_axis_1.length() > x_axis_2.length()) {
						x_axis_2 = x_axis_1;
					} else {
						x_axis_1 = x_axis_2;
					}

					if (y_axis_1 == null) {
						StringBuffer sb = new StringBuffer();
						sb.append("0");
						for (int index = 1; index < max_length_time; index += 2) {
							sb.append(",");
							sb.append("0");
						}
						y_axis_1 = sb.toString();
					}

					if (y_axis_2 == null) {
						StringBuffer sb = new StringBuffer();
						sb.append("0");
						for (int index = 1; index < max_length_time; index += 2) {
							sb.append(",");
							sb.append("0");
						}
						y_axis_2 = sb.toString();
					}

					cyNodeAttrs.setAttribute(node.getIdentifier(), "graph-url-queuing&transfer",
							prefix_packet_queue_transfer + "&chd=t:" + x_axis_1
									+ "|" + y_axis_1 + "|" + x_axis_2 + "|"
									+ y_axis_2);
				}

			} else
				isTravelled.put(new Integer(node.getRootGraphIndex()), false);
		}

		Map<Integer, Double> node_margin = new HashMap<Integer, Double>();
		Map<Integer, Integer> num_artifacts = new HashMap<Integer, Integer>();

		// relay the processes and remove all artifacts generated
		iter = networkView.getNodeViewsIterator();
		int maxNumOfArtifacts = 0;
		while (iter.hasNext()) {
			if (canceled)
				return;

			nodeView = iter.next();
			node = nodeView.getNode();

			if (!isTravelled.get(node.getRootGraphIndex()))
				continue;

			double x = nodeView.getXPosition();
			double y = nodeView.getYPosition();
			double margin = Double.MAX_VALUE;

			Iterator<NodeView> tmp_iter = networkView.getNodeViewsIterator();
			while (tmp_iter.hasNext()) {
				NodeView tmpNodeView = tmp_iter.next();
				if (tmpNodeView.getNode().getIdentifier().equals(
						node.getIdentifier()))
					continue;
				if (!isTravelled.get(tmpNodeView.getNode().getRootGraphIndex()))
					continue;

				double tmp_x = tmpNodeView.getXPosition();
				double tmp_y = tmpNodeView.getYPosition();

				double dis = Math.sqrt((x - tmp_x) * (x - tmp_x) + (y - tmp_y)
						* (y - tmp_y));
				if (margin > dis)
					margin = dis;
			}

			node_margin.put(node.getRootGraphIndex(), margin);

			int[] incoming_edges = network.getAdjacentEdgeIndicesArray(node
					.getRootGraphIndex(), false, true, false);
			CyAttributes edge_attribute = Cytoscape.getEdgeAttributes();
			int numOfArtifacts = 0, numOfProcesses = 0;
			List<Integer> ls_process = new ArrayList<Integer>();
			for (int edge : incoming_edges) {
				if (edge_attribute.getStringAttribute(
						network.getEdge(edge).getIdentifier(), "interaction")
						.equalsIgnoreCase("wasTriggeredBy")) {

					int source_node = network.getEdgeSourceIndex(edge);
					if (isTravelled.get(source_node))
						continue;
					else {
						isTravelled.put(source_node, true);
						numOfProcesses++;
						ls_process.add(source_node);
						// choose to hide the process node as well
						networkView.hideGraphObject(networkView
								.getNodeView(source_node));
					}
				} else if (edge_attribute.getStringAttribute(
						network.getEdge(edge).getIdentifier(), "interaction")
						.equalsIgnoreCase("wasGeneratedBy")) {

					int source_node = network.getEdgeSourceIndex(edge);
					if (isTravelled.get(source_node))
						continue;
					else {
						isTravelled.put(source_node, true);
						numOfArtifacts++;
						networkView.hideGraphObject(networkView
								.getNodeView(source_node));
					}
				}

			}

			// relay the processes around the node
			// double radius = margin / 2;
			// double phi = (2 * Math.PI) / ls_process.size();
			// for (int i = 0; i < ls_process.size(); i++) {
			// networkView.getNodeView(ls_process.get(i)).setXPosition(
			// x + radius * Math.sin(phi * i));
			// networkView.getNodeView(ls_process.get(i)).setYPosition(
			// y + radius * Math.cos(phi * i));
			// }

			if (numOfArtifacts > maxNumOfArtifacts)
				maxNumOfArtifacts = numOfArtifacts;

			num_artifacts.put(node.getRootGraphIndex(), numOfArtifacts);
		}

		// calculate the size of node
		Iterator<Integer> itr = node_margin.keySet().iterator();
		while (itr.hasNext()) {
			if (canceled)
				return;

			int node_id = itr.next();

			double radius = node_margin.get(node_id).doubleValue();
			radius = radius / 2 * 0.8;

			double height = networkView.getNodeView(node_id).getHeight();
			double width = networkView.getNodeView(node_id).getWidth();
			if (num_artifacts.get(node_id) != 0) {
				networkView.getNodeView(node_id).setHeight(
						height + (radius - height) * num_artifacts.get(node_id)
								/ maxNumOfArtifacts);
				networkView.getNodeView(node_id).setWidth(
						width + (radius - width) * num_artifacts.get(node_id)
								/ maxNumOfArtifacts);
			}
		}

	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "NS Layout Ext1";
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "NS Layout Ext1";
	}
}
