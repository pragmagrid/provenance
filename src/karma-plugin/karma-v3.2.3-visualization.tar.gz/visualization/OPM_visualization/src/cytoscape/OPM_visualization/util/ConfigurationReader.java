/**
 * 
 */
package cytoscape.OPM_visualization.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.swing.JOptionPane;

import cytoscape.Cytoscape;

/**
 * @author peng Use java property reader to read the configuration
 */
public class ConfigurationReader {
	static String MessageConfigPath = "/plugins/config/karmaQueryConfig.txt";

	public static String serviceURL;
	public static String username;
	public static String password;
	public static String hostname;
	public static String hostport;
	public static String virtualhost;
	public static String exchangename;
	public static String queuename;
	public static String routingkey;

	private static ConfigurationReader instance = null;
	private static Properties properties;

	private ConfigurationReader(InputStream input) {
		try {
			properties = new Properties();
			properties.load(input);
		} catch (IOException e) {
			System.err.println("ERROR: Unable to load properties file ");
			e.printStackTrace(System.err);
			System.exit(-1);
		}
	}
	
	public static ConfigurationReader getInstance(){
		initialize();
		return instance;
	}

	public String getProperty(String propertyName) {
		return properties.getProperty(propertyName);
	}

	public static void store() {
		String proFilePath = System.getProperty("user.dir") + MessageConfigPath;
		BufferedOutputStream output;
		try {
			output = new BufferedOutputStream(new FileOutputStream(proFilePath));
			properties.setProperty("axis2.serviceURL", serviceURL);
			properties.setProperty("messaging.username", username);
			properties.setProperty("messaging.password", password);
			properties.setProperty("messaging.hostname", hostname);
			properties.setProperty("messaging.hostport", hostport);
			properties.setProperty("messaging.virtualhost", virtualhost);
			properties.setProperty("messaging.exchangename", exchangename);
			properties.setProperty("messaging.queuename", queuename);
			properties.setProperty("messaging.routingkey", routingkey);
			
			properties
					.store(
							output,
							"Properties for using Karma Query Plugin\n@author: Peng Chen (chenpeng@indiana.edu)\nInformation to use Axis Service and RabbitMQ messaging system");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void initialize() {
		if (instance != null)
			return;

		String proFilePath1 = System.getProperty("user.dir")
				+ MessageConfigPath;
		BufferedInputStream input;
		try {
			input = new BufferedInputStream(new FileInputStream(proFilePath1));

			instance = new ConfigurationReader(input);

			instance.serviceURL = instance.getProperty("axis2.serviceURL");
			instance.username = instance.getProperty("messaging.username");
			instance.password = instance.getProperty("messaging.password");
			instance.hostname = instance.getProperty("messaging.hostname");
			instance.hostport = instance.getProperty("messaging.hostport");
			instance.virtualhost = instance
					.getProperty("messaging.virtualhost");
			instance.exchangename = instance
					.getProperty("messaging.exchangename");
			instance.queuename = instance.getProperty("messaging.queuename");
			instance.routingkey = instance.getProperty("messaging.routingkey");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(Cytoscape.getDesktop(), e.toString());
		}
	}
}
