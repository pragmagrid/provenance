package cytoscape.OPM_visualization.eventListener;

import cytoscape.data.attr.MultiHashMapListener;

public class AttributeModificationListener implements MultiHashMapListener{

	@Override
	public void allAttributeValuesRemoved(String arg0, String arg1) {
		// TODO Auto-generated method stub
		System.out.println("allAttributeValuesRemoved");
	}

	@Override
	public void attributeValueAssigned(String arg0, String arg1, Object[] arg2,
			Object arg3, Object arg4) {
		// TODO Auto-generated method stub
		System.out.println("attributeValueAssigned");
	}

	@Override
	public void attributeValueRemoved(String arg0, String arg1, Object[] arg2,
			Object arg3) {
		// TODO Auto-generated method stub
		System.out.println("attributeValueRemoved");
	}

}
