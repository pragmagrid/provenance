# RabbitMQ STOMP adapter

The STOMP adapter is included in the RabbitMQ distribution.  To enable
it, use <href="http://www.rabbitmq.com/man/rabbitmq-plugins.1.man.html">rabbitmq-plugins</a>:

    rabbitmq-plugins enable rabbitmq_stomp

Binaries for previous versions of the STOMP adapter can be obtained
from
<http://www.rabbitmq.com/plugins.html#rabbitmq-stomp>.

Full usage instructions can be found at
<http://www.rabbitmq.com/stomp.html>.
